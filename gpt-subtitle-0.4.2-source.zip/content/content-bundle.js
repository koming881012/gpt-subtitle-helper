(() => {
  // shared/constants.js
  var DEFAULT_MODEL = "gpt-5.6-luna";
  var PROMPT_VERSION = "prompt-v2-progressive-sentences";
  var FAST_PROMPT_VERSION = "prompt-v3-fast-timed";
  var translationVersion = (meta) => meta.platform === "primevideo" || meta.videoId?.startsWith("prime:") ? `${PROMPT_VERSION}-prime-timed-v1` : FAST_PROMPT_VERSION;
  var TRANSLATION_CONFIG = Object.freeze({ fullTextChars: 24e3, fullTextCues: 350, maxTranscriptChars: 12e5, chunkSize: 120, chunkChars: 16e3, contextCues: 12, maxRetries: 4, timeoutMs: 24e4 });
  var DEFAULT_STYLE = Object.freeze({ zhSize: 30, enSize: 23, zhColor: "#ffffff", enColor: "#eeeeee", font: 'system-ui, "PingFang TC", "Microsoft JhengHei", sans-serif', outline: 2, background: false, opacity: 50, zhWeight: 600, enWeight: 500, lineHeight: 1.3, width: 80, bottom: 9, top: 7 });
  var DEFAULT_SETTINGS = Object.freeze({ model: DEFAULT_MODEL, terminologyModel: "gpt-6-astra", terminologyEnabled: false, reasoningEffort: "medium", autoTranslate: true, pauseForSubtitles: true, targetLanguage: "zh-TW", style: DEFAULT_STYLE });
  var MODES = Object.freeze({ zh: "繁體中文", en: "英文", "both-zh": "中英雙語（中文在上）", "both-en": "中英雙語（英文在上）", "split-en": "上下分開（英文在上）", "split-zh": "上下分開（中文在上）" });
  var ACTIVE_STATUSES = ["fetching", "analyzing", "translating", "assembling"];

  // shared/messages.js
  var MSG = Object.freeze({ STATE: "GET_STATE", START: "START_JOB", RESUME: "RESUME_JOB", CANCEL: "CANCEL_JOB", LOOKUP: "LOOKUP_CACHE", PREF: "SET_VIDEO_PREF", SETTINGS: "GET_SETTINGS", SAVE: "SAVE_SETTINGS", CONNECT: "CONNECT_COMPANION", AUTH_STATUS: "AUTH_STATUS", SIGN_IN: "SIGN_IN_CHATGPT", SIGN_OUT: "SIGN_OUT_CHATGPT", LOCAL_PAGE: "OPEN_LOCAL_PAGE", MODELS: "LIST_MODELS", SELECT_ACCOUNT: "SELECT_ACCOUNT", TEST: "TEST_CONNECTION", STATS: "CACHE_STATS", CLEAR: "CLEAR_CACHE", OPTIONS: "OPEN_OPTIONS", FETCH: "FETCH_CAPTIONS", DIAG: "GET_DIAGNOSTICS", UPDATE: "JOB_UPDATE", INVALIDATE: "CACHE_INVALIDATED", SETTINGS_CHANGED: "SETTINGS_CHANGED", PREF_CHANGED: "PREF_CHANGED", LIST_JOBS: "LIST_JOBS", CONTENT_STATE: "CONTENT_STATE", CONTENT_START: "CONTENT_START", CONTENT_PREF: "CONTENT_PREF", EXPORT: "EXPORT_SUBTITLE", IMPORT_FILE: "IMPORT_SUBTITLE_FILE", SAVE_FILE: "SAVE_SUBTITLE_FILE", RUN: "OFFSCREEN_RUN", ABORT: "OFFSCREEN_ABORT", CHECKPOINT: "WORKER_CHECKPOINT", PING: "OFFSCREEN_PING", RECOVER: "RECOVER_JOBS", PRIORITY: "PRIORITIZE_PLAYHEAD" });
  async function send(type, payload = {}) {
    const r = await chrome.runtime.sendMessage({ type, ...payload });
    if (!r?.ok) throw new Error(r?.error || "擴充功能無法回應，請重新整理頁面。");
    return r.data;
  }

  // shared/platforms.js
  function platformFromUrl(value) {
    try {
      const u = new URL(value);
      if (u.protocol !== "https:") return null;
      if (u.hostname === "www.youtube.com") return "youtube";
      if (["www.primevideo.com", "primevideo.com"].includes(u.hostname)) return "primevideo";
    } catch {
    }
    return null;
  }
  function primeTitleId(value) {
    try {
      const u = new URL(value);
      if (platformFromUrl(value) !== "primevideo") return null;
      const query = u.searchParams.get("gti") || u.searchParams.get("asin");
      if (/^[A-Z0-9]{10,32}$/i.test(query || "")) return query.toUpperCase();
      const path = u.pathname.match(/\/(?:detail|dp)\/(?:[^/]+\/)?([A-Z0-9]{10,32})(?:\/|$)/i);
      return path ? path[1].toUpperCase() : null;
    } catch {
      return null;
    }
  }
  function validatePrimeCaptionUrl(value) {
    const u = new URL(value);
    if (u.protocol !== "https:" || u.username || u.password || u.port || !/(?:^|\.)(?:aiv-cdn\.net|pv-cdn\.net|aiv-delivery\.net|cloudfront\.net|media-amazon\.com|amazonvideo\.com|primevideo\.com)$/.test(u.hostname)) throw new Error("Prime Video 字幕來源不受支援。");
    return u;
  }

  // shared/utils.js
  function videoIdFromUrl(url) {
    try {
      const u = new URL(url);
      if (platformFromUrl(url) === "primevideo") {
        const id = primeTitleId(url);
        return id ? `prime:${id}` : null;
      }
      return u.origin === "https://www.youtube.com" && u.pathname === "/watch" && /^[\w-]{11}$/.test(u.searchParams.get("v") || "") ? u.searchParams.get("v") : null;
    } catch {
      return null;
    }
  }
  function trackId(track) {
    return [track.languageCode, track.vssId || track.name, track.kind || "manual"].join(":");
  }
  function cacheKey(meta, track, settings) {
    const parts = [meta.platform || (meta.videoId?.startsWith("prime:") ? "primevideo" : "youtube"), meta.videoId, track.languageCode, trackId(track), settings.targetLanguage, settings.model, settings.reasoningEffort, meta.promptVersion];
    if (meta.promptVersion !== "prompt-v1") parts.push(settings.terminologyModel || "gpt-6-astra");
    return JSON.stringify(parts);
  }
  function publicTrack(t) {
    return t ? { languageCode: t.languageCode, name: t.name, kind: t.kind || "manual", vssId: t.vssId, sourceTrackId: trackId(t) } : null;
  }
  function log(...args) {
    console.info("[YouTubeGPT]", ...args);
  }

  // content/youtube-detector.js
  var currentVideoId = () => videoIdFromUrl(location.href);
  function findVideoElement() {
    return document.querySelector("#movie_player video.html5-main-video") || document.querySelector(".html5-video-player video") || document.querySelector("ytd-player video");
  }
  function findPlayer(video = findVideoElement()) {
    return video?.closest("#movie_player, .html5-video-player") || null;
  }
  function watchNavigation(callback) {
    let last = location.href, scheduled = false;
    const check = () => {
      if (scheduled) return;
      scheduled = true;
      queueMicrotask(() => {
        scheduled = false;
        callback(currentVideoId());
      });
    };
    const events = ["yt-navigate-finish", "yt-page-data-updated", "popstate"];
    events.forEach((e) => window.addEventListener(e, check));
    const reset = () => callback(null);
    window.addEventListener("yt-navigate-start", reset);
    const timer = setInterval(() => {
      if (last !== location.href) {
        last = location.href;
        check();
      }
    }, 750);
    check();
    return () => {
      clearInterval(timer);
      events.forEach((e) => window.removeEventListener(e, check));
      window.removeEventListener("yt-navigate-start", reset);
    };
  }

  // content/platform-detector.js
  var isPrime = () => platformFromUrl(location.href) === "primevideo";
  function findVideoElement2() {
    if (!isPrime()) return findVideoElement();
    return Array.from(document.querySelectorAll('[id^="dv-web-player"] video, .atvwebplayersdk-player-container video')).filter((v) => Number.isFinite(v.duration) && v.duration > 0 && v.getBoundingClientRect().width > 0).sort((a, b) => b.getBoundingClientRect().width * b.getBoundingClientRect().height - a.getBoundingClientRect().width * a.getBoundingClientRect().height)[0] || null;
  }
  function currentVideoId2() {
    if (!isPrime()) return currentVideoId();
    if (!findVideoElement2() && !document.querySelector('[id^="dv-web-player"], .atvwebplayersdk-player-container')) return null;
    return document.documentElement.getAttribute("data-ytgpt-prime-video-id") || (primeTitleId(location.href) ? `prime:${primeTitleId(location.href)}` : null);
  }
  function findPlayer2(video = findVideoElement2()) {
    return isPrime() ? video?.closest('.atvwebplayersdk-player-container, [id^="dv-web-player"]') || null : findPlayer(video);
  }
  function watchNavigation2(callback) {
    if (!isPrime()) return watchNavigation(callback);
    let previous;
    const check = () => {
      const id = currentVideoId2();
      if (id !== previous) {
        previous = id;
        callback(id);
      } else if (id) callback(id);
    };
    const timer = setInterval(check, 1500);
    window.addEventListener("popstate", check);
    check();
    return () => {
      clearInterval(timer);
      window.removeEventListener("popstate", check);
    };
  }

  // content/caption-parser.js
  var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", "#39": "'" };
  function decodeEntities(s) {
    return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z][a-z0-9]+);/gi, (match, key) => {
      if (key[0] === "#") {
        const n = key[1]?.toLowerCase() === "x" ? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
        return n >= 0 && n <= 1114111 && !(n >= 55296 && n <= 57343) ? String.fromCodePoint(n) : match;
      }
      return ENTITIES[key.toLowerCase()] ?? match;
    });
  }
  function cleanText(s) {
    return decodeEntities(s).replace(/\r\n?/g, "\n").split("\n").map((line) => line.replace(/[\t\u00a0 ]+/g, " ").trim()).join("\n").trim();
  }
  function cue(start2, duration, text) {
    return { startMs: Number(start2), durationMs: Number(duration), endMs: Number(start2) + Number(duration), text: cleanText(text) };
  }
  function parseJSON3(data) {
    if (!Array.isArray(data?.events)) throw new Error("JSON3 缺少 events。");
    const out = [];
    for (const e of data.events) {
      if (!Array.isArray(e.segs)) continue;
      const text = e.segs.map((s) => s.utf8 || "").join("");
      out.push(cue(e.tStartMs, e.dDurationMs ?? 0, text));
    }
    return out;
  }
  function attrs(s) {
    return Object.fromEntries([...s.matchAll(/([\w]+)\s*=\s*["']([^"']*)["']/g)].map((m) => [m[1], m[2]]));
  }
  function parseXML(raw) {
    if (/<!DOCTYPE|<!ENTITY/i.test(raw)) throw new Error("不支援含 DTD 的字幕 XML。");
    if (!/<(?:transcript|timedtext)\b/i.test(raw)) throw new Error("不是字幕 XML。");
    const out = [];
    const tags = /<(text|p)\b([^>]*)>([\s\S]*?)<\/\1>/g;
    for (const m of raw.matchAll(tags)) {
      const a = attrs(m[2]);
      const body = m[3].replace(/<br\s*\/?\s*>/gi, "\n").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]*>/g, "");
      out.push(m[1] === "text" ? cue(Number(a.start) * 1e3, Number(a.dur) * 1e3, body) : cue(a.t, a.d ?? 0, body));
    }
    return out;
  }
  function validateCues(cues, durationSeconds = 0) {
    if (!cues.length) throw new Error("字幕取得失敗：沒有字幕段落。");
    let prev = -1, empty = 0, maxEnd = 0;
    for (const c of cues) {
      if (![c.startMs, c.durationMs, c.endMs].every(Number.isFinite) || c.startMs < prev || c.startMs < 0 || c.durationMs < 0 || c.endMs !== c.startMs + c.durationMs) throw new Error("字幕取得失敗：時間軸異常。");
      prev = c.startMs;
      maxEnd = Math.max(maxEnd, c.endMs);
      if (!c.text) empty++;
    }
    if (empty / cues.length > 0.25) throw new Error("字幕取得失敗：過多空白段落。");
    if (durationSeconds > 0 && maxEnd > durationSeconds * 1e3 + Math.max(1e4, durationSeconds * 100)) throw new Error("字幕取得失敗：字幕時間超出影片長度。");
    return { count: cues.length, maxEndMs: maxEnd, warnings: durationSeconds > 60 && maxEnd < durationSeconds * 1e3 * 0.5 ? ["最後字幕早於影片一半，可能是片尾無口白或來源不完整，請核對。"] : [] };
  }
  function parseCaptions(raw, durationSeconds = 0) {
    const text = String(raw).trim();
    const cues = text.startsWith("{") ? parseJSON3(JSON.parse(text)) : parseXML(text);
    validateCues(cues, durationSeconds);
    return cues.filter((c) => c.text).map((c, id) => ({ ...c, id }));
  }

  // content/prime-caption-parser.js
  function subtitleTime(value, { frameRate = 30, tickRate = 1 } = {}) {
    const text = String(value || "").trim(), clock = /^(\d+):(\d{2}):(\d{2})(?:\.(\d+)|:(\d{2})(?:\.(\d+))?)?$/.exec(text);
    if (clock) return Math.round((Number(clock[1]) * 3600 + Number(clock[2]) * 60 + Number(clock[3]) + (clock[4] ? Number(`0.${clock[4]}`) : clock[5] ? (Number(clock[5]) + Number(`0.${clock[6] || 0}`)) / frameRate : 0)) * 1e3);
    const short = /^(\d{1,2}):(\d{2})\.(\d+)$/.exec(text);
    if (short) return Math.round((Number(short[1]) * 60 + Number(short[2]) + Number(`0.${short[3]}`)) * 1e3);
    const offset = /^(\d+(?:\.\d+)?)(h|m|s|ms|f|t)$/.exec(text);
    if (offset) return Math.round(Number(offset[1]) * { h: 36e5, m: 6e4, s: 1e3, ms: 1, f: 1e3 / frameRate, t: 1e3 / tickRate }[offset[2]]);
    throw new Error(`Prime Video 字幕時間格式不受支援：${text.slice(0, 40)}`);
  }
  function textContent(value) {
    return cleanText(value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<br\b[^>]*\/?\s*>/gi, "\n").replace(/<[^>]+>/g, ""));
  }
  function parsePrimeCaptions(raw, duration = 0) {
    const text = String(raw).replace(/^\uFEFF/, "").trim();
    if (text.length > 1e7 || /<!DOCTYPE|<!ENTITY/i.test(text)) throw new Error("Prime Video 字幕資料不受支援。");
    const cues = [], push = (startMs, endMs, body) => {
      const value = textContent(body);
      if (value) cues.push({ startMs, endMs, durationMs: endMs - startMs, text: value });
    };
    if (/^WEBVTT(?:\s|$)/.test(text)) {
      for (const block of text.split(/\n\s*\n/)) {
        const lines = block.split(/\r?\n/), i = lines.findIndex((l) => l.includes("-->"));
        if (i < 0) continue;
        const match = /^\s*(\S+)\s+-->\s+(\S+)/.exec(lines[i]);
        if (match) push(subtitleTime(match[1]), subtitleTime(match[2]), lines.slice(i + 1).join("\n"));
      }
    } else if (/<(?:\w+:)?tt\b/i.test(text)) {
      const attributes = (value) => Object.fromEntries(Array.from(value.matchAll(/([\w:.-]+)\s*=\s*["']([^"']*)["']/g), (m) => [m[1].split(":").pop(), m[2]]));
      const root = attributes(text.match(/<(?:\w+:)?tt\b([^>]*)>/i)?.[1] || ""), multiplier = (root.frameRateMultiplier || "1 1").split(/\s+/).map(Number);
      const rates = { frameRate: Number(root.frameRate || 30) * multiplier[0] / multiplier[1], tickRate: Number(root.tickRate || 1) };
      for (const p of text.matchAll(/<(?:\w+:)?p\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?p\s*>/gi)) {
        const a = attributes(p[1]);
        if (!a.begin) throw new Error("Prime Video 字幕缺少片段起始時間。");
        const start2 = subtitleTime(a.begin, rates), end = a.end ? subtitleTime(a.end, rates) : a.dur ? start2 + subtitleTime(a.dur, rates) : NaN;
        push(start2, end, p[2]);
      }
    } else throw new Error("Prime Video 回傳非 TTML／WebVTT 字幕。");
    cues.sort((a, b) => a.startMs - b.startMs);
    validateCues(cues, duration);
    return cues.map((c, id) => ({ ...c, id }));
  }
  function primeCaptionSource(raw, duration) {
    const cues = parsePrimeCaptions(raw, duration);
    return { raw: JSON.stringify({ events: cues.map((c) => ({ tStartMs: c.startMs, dDurationMs: c.durationMs, segs: [{ utf8: c.text }] })) }), format: "primevideo-timed-captions", warnings: [] };
  }

  // content/caption-detector.js
  function isEnglish(t) {
    return /^en(?:-|$)/i.test(t?.languageCode || "");
  }
  function isAutoGenerated(t) {
    return t?.kind === "asr" || /^a\./.test(t?.vssId || "") || /auto[- ]?generated|自動產生|自動生成/i.test(t?.name || "");
  }
  function isAutoTranslated(t) {
    return Boolean(t?.isAutoTranslated) || /auto[- ]?translated|自動翻譯|自动翻译/i.test(t?.name || "") || /[?&]tlang=/i.test(t?.baseUrl || "");
  }
  function nativeChineseTracks(tracks = []) {
    return tracks.filter((t) => /^(?:zh|cmn|yue)(?:[-_]|$)/i.test(t?.languageCode || "") && !isAutoGenerated(t) && !t?.isAutoTranslated && !/auto[- ]?translated|自動翻譯|自动翻译/i.test(t?.name || "") && !/[?&]tlang=/i.test(t?.baseUrl || "") && !/forced/i.test(t?.kind || ""));
  }
  function englishTracks(tracks = []) {
    return tracks.filter((t) => isEnglish(t) && !isAutoTranslated(t)).map((t) => ({ ...t, sourceTrackId: trackId(t), autoGenerated: isAutoGenerated(t) })).sort((a, b) => {
      const rank = (t) => (isAutoGenerated(t) ? 10 : 0) + (t.languageCode === "en" ? 0 : t.languageCode.toLowerCase() === "en-us" ? 1 : 2);
      return rank(a) - rank(b);
    });
  }

  // content/caption-fetcher.js
  function validateCaptionUrl(value, videoId) {
    const u = new URL(value);
    if (u.origin !== "https://www.youtube.com" || u.pathname !== "/api/timedtext" || u.searchParams.get("v") !== videoId || !/^en(?:-|$)/i.test(u.searchParams.get("lang") || "") || u.searchParams.has("tlang")) throw new Error("字幕來源網址不符合目前英文影片。");
    return u;
  }
  async function fetchCaptionSource(track, videoId, signal, fetchImpl = fetch) {
    const base = validateCaptionUrl(track.baseUrl, videoId);
    let last = "";
    for (const fmt of [null, "json3", "srv3"]) {
      const url = new URL(base);
      if (fmt) url.searchParams.set("fmt", fmt);
      try {
        const r = await fetchImpl(url.href, { credentials: "include", signal, redirect: "error" });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const raw = await r.text();
        if (raw.length > 1e7) throw new Error("字幕來源過大，未送出翻譯。");
        if (!raw.trim() || !raw.trim().startsWith("{") && !/<(?:transcript|timedtext)\b/.test(raw)) throw new Error("YouTube 回傳空字幕或非字幕資料。");
        parseCaptions(raw);
        return { raw, format: fmt || "original" };
      } catch (e) {
        if (signal?.aborted) throw e;
        last = e.message;
      }
    }
    throw new Error(`字幕取得失敗：${last}`);
  }

  // content/transcript-source.js
  var normalize = (s) => String(s || "").replace(/\s+/g, " ").trim();
  var owners = /* @__PURE__ */ new WeakMap();
  var modernSelector = 'yt-section-list-renderer[data-target-id="PAmodern_transcript_view"][panel-content-visible]';
  function transcriptPanel(doc) {
    const visible = (e) => e && e.getClientRects().length && !e.closest('[hidden], [visibility="ENGAGEMENT_PANEL_VISIBILITY_HIDDEN"]');
    return Array.from(doc.querySelectorAll(`ytd-transcript-renderer[panel-content-visible], ${modernSelector}`)).find(visible) || null;
  }
  function transcriptRows(panel) {
    return Array.from(panel.querySelectorAll("ytd-transcript-segment-renderer, transcript-segment-view-model")).map((e) => ({ timestamp: normalize(e.querySelector(".segment-timestamp, .ytwTranscriptSegmentViewModelTimestamp")?.textContent), text: e.querySelector('.segment-text, [role="text"]')?.textContent || "" }));
  }
  function looksEnglish(rows) {
    const words = rows.map((r) => r.text).join(" ").slice(0, 5e3).toLowerCase().match(/[a-z]+/g) || [];
    const common = /* @__PURE__ */ new Set(["the", "and", "to", "of", "that", "is", "it", "you", "we", "this", "with", "for", "have", "are", "was", "from", "they", "will", "can", "your", "my", "but", "not", "so"]);
    return new Set(words.filter((w) => common.has(w))).size >= 6;
  }
  function transcriptSource(rows, durationSeconds) {
    if (!Array.isArray(rows) || !rows.length || rows.length > 2e4) throw new Error("YouTube 原生轉錄稿沒有完整字幕。");
    const starts = rows.map((row) => {
      const parts = normalize(row.timestamp).split(":");
      if (parts.length < 2 || parts.length > 3 || parts.some((p) => !/^\d+$/.test(p)) || parts.slice(1).some((p) => Number(p) >= 60)) throw new Error("YouTube 轉錄稿時間戳無法辨識。");
      return parts.reduce((seconds, p) => seconds * 60 + Number(p), 0) * 1e3;
    });
    const durationMs = Math.round(Number(durationSeconds) * 1e3);
    if (!Number.isFinite(durationMs) || durationMs <= 0) throw new Error("YouTube 影片長度尚未就緒，請稍候再試。");
    const events = rows.map((row, i) => ({ tStartMs: starts[i], dDurationMs: Math.max(0, (starts[i + 1] ?? Math.min(durationMs, starts[i] + 1e4)) - starts[i]), segs: [{ utf8: String(row.text || "").trim() }] }));
    const { warnings } = validateCues(events.map((e) => ({ startMs: e.tStartMs, durationMs: e.dDurationMs, endMs: e.tStartMs + e.dDurationMs, text: e.segs[0].utf8 })), durationSeconds);
    const raw = JSON.stringify({ events });
    if (raw.length > 1e7) throw new Error("字幕來源過大，未送出翻譯。");
    return { raw, format: "youtube-transcript-dom", warnings: ["使用 YouTube 原生轉錄稿：時間戳精度為秒，結束時間依下一段起點推算。", ...warnings] };
  }
  async function fetchTranscriptSource(track, meta, signal, { doc = document, videoId = () => new URL(location.href).searchParams.get("v") } = {}) {
    const guard = () => {
      signal?.throwIfAborted();
      if (videoId() !== meta.videoId) {
        const e = new Error("影片已切換，已停止取得字幕。");
        e.code = "VIDEO_CHANGED";
        throw e;
      }
    };
    const wait = () => new Promise((resolve, reject) => {
      const aborted = () => {
        clearTimeout(timer);
        reject(signal.reason || new DOMException("Aborted", "AbortError"));
      };
      const timer = setTimeout(() => {
        signal?.removeEventListener("abort", aborted);
        resolve();
      }, 250);
      signal?.addEventListener("abort", aborted, { once: true });
    });
    const panel = () => transcriptPanel(doc);
    const visible = (e) => e && e.getClientRects().length && !e.closest("[hidden]");
    const findButton = () => Array.from(doc.querySelectorAll('ytd-video-description-transcript-section-renderer button, ytd-video-description-transcript-section-renderer [role="button"], ytd-watch-metadata #description button, ytd-watch-metadata #description [role="button"]')).find((e) => visible(e) && /^(顯示轉錄稿|显示文字记录|显示转录稿|Show transcript)$/i.test(normalize(e.textContent || e.getAttribute?.("aria-label"))));
    const descriptionTab = () => Array.from(doc.querySelectorAll('yt-side-rail-view-model [role="tab"]')).find((e) => visible(e) && e.getAttribute("aria-selected") !== "true" && e.getAttribute("aria-disabled") !== "true" && /^(?:說明|说明|Description)(?:$|[，,])/i.test(normalize(e.getAttribute("aria-label") || e.textContent)));
    guard();
    const previous = owners.get(doc), switched = previous && previous.videoId !== meta.videoId;
    let openedAt = 0, openAttempts = 0;
    const open = (button) => {
      button.click();
      openedAt = Date.now();
      openAttempts++;
    };
    if (!panel() || switched) {
      const deadline2 = Date.now() + 25e3, expanded = /* @__PURE__ */ new WeakSet();
      while (!findButton() && (!panel() || switched) && Date.now() < deadline2) {
        guard();
        const inline = doc.querySelector("ytd-watch-metadata #description-inline-expander #expand, ytd-text-inline-expander#description-inline-expander #expand");
        const expand = visible(inline) ? inline : descriptionTab();
        if (expand && visible(expand) && !expanded.has(expand)) {
          expand.click();
          expanded.add(expand);
        }
        await wait();
      }
      const button = findButton();
      if (button) open(button);
      else if (!panel() || switched) {
        const e = new Error("YouTube 影片說明與轉錄稿入口尚未就緒。");
        e.code = "TRANSCRIPT_NOT_READY";
        throw e;
      }
    }
    const deadline = Date.now() + 2e4;
    let signature = "", stable = 0, selected = false;
    while (Date.now() < deadline) {
      guard();
      const p = panel();
      if (!p && openAttempts < 3 && Date.now() - openedAt >= 2e3) {
        const button = findButton();
        if (button) open(button);
      }
      if (p) {
        if (p.querySelector("#transcript-search-box-input, yt-search-input-view-model textarea, yt-search-input-view-model input")?.value) throw new Error("請清空 YouTube 轉錄稿搜尋欄，再產生中文字幕，以免只翻譯搜尋結果。");
        const label = normalize(p.querySelector("ytd-transcript-footer-renderer #label-text")?.textContent);
        const rows = transcriptRows(p), expected = normalize(track.name), modern = p.matches?.(modernSelector), singleEnglish = meta.captionTracks?.length === 1 && /^en(?:-|$)/i.test(meta.captionTracks[0].languageCode || "");
        const matches = label ? label === expected || !expected && /^(English|英文|英語|英语)(?:\s|$)/i.test(label) : modern && /^en(?:-|$)/i.test(track.languageCode || "") && (singleEnglish || looksEnglish(rows));
        if (modern && !label && rows.length && !matches) throw new Error("原生轉錄稿內容無法確認為英文，未送出翻譯。請在 YouTube 選擇英文字幕來源。");
        if (label && !matches && !selected) {
          selected = true;
          p.querySelector("ytd-transcript-footer-renderer #label")?.click();
          const choice = Array.from(p.querySelectorAll('ytd-transcript-footer-renderer [role="option"]')).find((e) => normalize(e.textContent) === expected);
          if (!choice) throw new Error("原生轉錄稿的語言與所選英文字幕不符，請在轉錄稿選擇相同的英文來源。");
          choice.click();
          signature = "";
          stable = 0;
        } else if (matches) {
          const next = JSON.stringify(rows);
          stable = next === signature ? stable + 1 : 0;
          signature = next;
          if (p.querySelector('[aria-busy="true"]')) {
            stable = 0;
            await wait();
            continue;
          }
          if (switched && next === previous.signature) {
            stable = 0;
            await wait();
            continue;
          }
          if (rows.length && stable >= 4) {
            guard();
            const source = transcriptSource(rows, meta.duration);
            if (modern && !label && !singleEnglish) source.warnings.push("新版轉錄稿未提供來源標籤；已檢查內容為英文，無法核對人工／自動來源軌。");
            owners.set(doc, { videoId: meta.videoId, signature: next });
            return source;
          }
        }
      }
      await wait();
    }
    const error = new Error("YouTube 轉錄稿暫未載入完成，尚未送出翻譯。請稍後按「產生繁中字幕」重試。");
    error.code = "TRANSCRIPT_NOT_READY";
    throw error;
  }

  // content/caption-source.js
  function delay(ms, signal) {
    return new Promise((resolve, reject) => {
      const abort = () => {
        clearTimeout(timer);
        reject(signal.reason);
      };
      const timer = setTimeout(() => {
        signal.removeEventListener("abort", abort);
        resolve();
      }, ms);
      signal.addEventListener("abort", abort, { once: true });
      if (signal.aborted) abort();
    });
  }
  async function fetchVideoCaptionSource(track, meta, signal, { player, download = fetchCaptionSource, transcript = fetchTranscriptSource, transcriptDelayMs = 750, playerTimeoutMs = 15e3, downloadTimeoutMs = 1e4, transcriptTimeoutMs = 4e4 } = {}) {
    signal?.throwIfAborted();
    return new Promise((resolve, reject) => {
      let settled = false, failed = 0;
      const controllers = [], timers = [], errors = {}, retryable = {};
      const cleanup2 = () => {
        signal?.removeEventListener("abort", abort);
        timers.forEach(clearTimeout);
        controllers.forEach((c) => c.abort());
      };
      const finish = (value, error) => {
        if (settled) return;
        settled = true;
        cleanup2();
        error ? reject(error) : resolve(value);
      };
      const abort = () => finish(null, signal.reason || new DOMException("Aborted", "AbortError"));
      signal?.addEventListener("abort", abort, { once: true });
      const sources = player ? ["player", "download", "transcript"] : ["transcript", "download"];
      for (const type of sources) {
        const controller = new AbortController();
        controllers.push(controller);
        timers.push(setTimeout(() => controller.abort(new DOMException("Timeout", "TimeoutError")), type === "player" ? playerTimeoutMs : type === "download" ? downloadTimeoutMs : transcriptTimeoutMs));
        Promise.resolve().then(async () => {
          if (settled) return;
          if (type === "transcript" && player) await delay(transcriptDelayMs, controller.signal);
          if (settled) return;
          return type === "player" ? player(track, meta, controller.signal) : type === "download" ? download(track, meta.videoId, controller.signal) : transcript(track, meta, controller.signal);
        }).then((value) => {
          if (!settled) {
            if (!value?.raw) throw new Error("字幕來源沒有文字。");
            if (type === "player") parseCaptions(value.raw, meta.duration);
            finish(value);
          }
        }).catch((e) => {
          if (settled) return;
          if (signal?.aborted || e.code === "VIDEO_CHANGED") {
            finish(null, e);
            return;
          }
          errors[type] = controller.signal.aborted ? "取得逾時" : e.message;
          retryable[type] = e.code === "TRANSCRIPT_NOT_READY" || controller.signal.aborted;
          if (++failed === sources.length) {
            const error = new Error(`取得英文字幕失敗。${player ? `播放器原文：${errors.player}；` : ""}原生轉錄稿：${errors.transcript}；字幕下載：${errors.download}`);
            if (retryable.transcript) error.code = "CAPTION_NOT_READY";
            finish(null, error);
          }
        });
      }
    });
  }

  // content/subtitle-renderer.js
  function subtitleLines(cues, mode) {
    const en = cues.map((c) => c.en ?? c.text).join("\n"), zh = cues.map((c) => c.zh || "").join("\n");
    const line = (lang, text) => ({ lang, text });
    if (mode === "zh") return { top: [], bottom: [line("zh", zh)] };
    if (mode === "en") return { top: [], bottom: [line("en", en)] };
    if (mode === "split-en") return { top: [line("en", en)], bottom: [line("zh", zh)] };
    if (mode === "split-zh") return { top: [line("zh", zh)], bottom: [line("en", en)] };
    return { top: [], bottom: mode === "both-zh" ? [line("zh", zh), line("en", en)] : [line("en", en), line("zh", zh)] };
  }
  var SubtitleRenderer = class {
    constructor(player, style = DEFAULT_STYLE, mode = "zh") {
      this.player = player;
      this.style = style;
      this.mode = mode;
      this.cues = [];
      this.enabled = false;
      this.root = document.createElement("div");
      this.root.id = "ytgpt-subtitle-overlay";
      this.root.style.cssText = "position:absolute;inset:0;pointer-events:none;z-index:60;overflow:hidden";
      this.top = document.createElement("div");
      this.bottom = document.createElement("div");
      for (const box of [this.top, this.bottom]) {
        box.className = "ytgpt-subtitle-box";
        box.style.cssText = "position:absolute;left:50%;transform:translateX(-50%);text-align:center;white-space:pre-line;overflow-wrap:anywhere;pointer-events:none";
        this.root.append(box);
      }
      player.append(this.root);
      this.applyStyle();
    }
    setEnabled(value) {
      this.enabled = value;
      this.root.hidden = !value;
      this.player.classList.toggle("ytgpt-enabled", value);
    }
    configure(style, mode) {
      const changed = JSON.stringify(this.style) !== JSON.stringify(style) || this.mode !== mode;
      this.style = style;
      this.mode = mode;
      if (changed) {
        this.renderKey = null;
        this.applyStyle();
        this.render(this.cues);
      }
    }
    applyStyle() {
      const s = this.style;
      for (const box of [this.top, this.bottom]) {
        box.style.width = `${s.width}%`;
        box.style.fontFamily = s.font;
        box.style.lineHeight = String(s.lineHeight);
      }
      this.top.style.top = `${s.top}%`;
      this.bottom.style.bottom = `${s.bottom}%`;
    }
    render(cues) {
      this.cues = cues;
      const key = JSON.stringify(cues.map((c) => [c.id, c.en, c.zh, c.text]));
      if (key === this.renderKey) return;
      this.renderKey = key;
      const lines = subtitleLines(cues, this.mode), s = this.style;
      for (const [box, list] of [[this.top, lines.top], [this.bottom, lines.bottom]]) {
        box.replaceChildren();
        for (const { lang, text } of list) {
          if (!text) continue;
          const line = document.createElement("div");
          line.className = `ytgpt-subtitle-${lang}`;
          line.textContent = text;
          line.style.cssText = `font-size:${lang === "zh" ? s.zhSize : s.enSize}px;font-weight:${lang === "zh" ? s.zhWeight : s.enWeight};color:${lang === "zh" ? s.zhColor : s.enColor};`;
          line.style.textShadow = s.outline ? `${s.outline}px 0 1px #000, -${s.outline}px 0 1px #000, 0 ${s.outline}px 1px #000, 0 -${s.outline}px 1px #000, 1px 1px 2px #000` : "none";
          line.style.background = s.background ? `rgba(0,0,0,${s.opacity / 100})` : "transparent";
          line.style.borderRadius = "4px";
          line.style.padding = s.background ? "2px 6px" : "0";
          box.append(line);
        }
      }
    }
    destroy() {
      this.player.classList.remove("ytgpt-enabled");
      this.root.remove();
    }
  };

  // shared/subtitle-timing.js
  var MAX_SUBTITLE_OFFSET_MS = 6e5;
  function normalizeSubtitleOffset(value = 0) {
    const offset = Number(value);
    if (!Number.isFinite(offset)) return 0;
    return Math.max(-MAX_SUBTITLE_OFFSET_MS, Math.min(MAX_SUBTITLE_OFFSET_MS, Math.round(offset / 100) * 100));
  }
  function subtitleTimeMs(videoTimeSeconds, offsetMs = 0) {
    return Number(videoTimeSeconds) * 1e3 - normalizeSubtitleOffset(offsetMs);
  }

  // content/subtitle-sync.js
  function createCueIndex(cues) {
    const maxEnds = [];
    let max = 0;
    for (const c of cues) {
      max = Math.max(max, c.endMs);
      maxEnds.push(max);
    }
    return { cues, maxEnds };
  }
  function activeCues(index, timeMs) {
    const { cues, maxEnds } = index;
    let lo = 0, hi = cues.length;
    while (lo < hi) {
      const mid = lo + hi >>> 1;
      if (cues[mid].startMs <= timeMs) lo = mid + 1;
      else hi = mid;
    }
    const result = [];
    for (let i = lo - 1; i >= 0 && maxEnds[i] > timeMs; i--) if (cues[i].startMs <= timeMs && timeMs < cues[i].endMs) result.push(cues[i]);
    return result.reverse();
  }
  var SubtitleSync = class {
    constructor(video, cues, render, isBlocked = () => false, readOffset = () => 0) {
      this.video = video;
      this.index = createCueIndex(cues);
      this.render = render;
      this.isBlocked = isBlocked;
      this.readOffset = readOffset;
      this.frame = 0;
      this.key = null;
      this.tick = this.tick.bind(this);
      this.update = this.update.bind(this);
      this.events = ["play", "pause", "seeked", "seeking", "ratechange", "timeupdate", "ended", "loadedmetadata"];
      this.events.forEach((e) => video.addEventListener(e, this.update));
      this.update();
    }
    update() {
      const cues = this.isBlocked() ? [] : activeCues(this.index, subtitleTimeMs(this.video.currentTime, this.readOffset()));
      const key = cues.map((c) => c.id).join(",");
      if (key !== this.key) {
        this.key = key;
        this.render(cues);
      }
      if (!this.video.paused && !this.frame) this.frame = requestAnimationFrame(this.tick);
    }
    tick() {
      this.frame = 0;
      this.update();
    }
    destroy() {
      cancelAnimationFrame(this.frame);
      this.events.forEach((e) => this.video.removeEventListener(e, this.update));
      this.render([]);
    }
  };

  // export/srt.js
  function timestamp(ms, separator = ",") {
    const value = Math.max(0, Math.round(ms));
    const hours = Math.floor(value / 36e5), minutes = Math.floor(value / 6e4) % 60, seconds = Math.floor(value / 1e3) % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}${separator}${String(value % 1e3).padStart(3, "0")}`;
  }
  function cueText(c, language) {
    return (language === "en" ? c.en : language === "bilingual" ? `${c.en}
${c.zh}` : c.zh).replace(/\r/g, "").replace(/\n\s*\n/g, "\n");
  }
  function toSRT(cues, language = "zh") {
    return cues.map((c, i) => `${i + 1}
${timestamp(c.startMs)} --> ${timestamp(c.endMs)}
${cueText(c, language)}
`).join("\n");
  }

  // export/vtt.js
  function toVTT(cues, language = "zh") {
    return "WEBVTT\n\n" + cues.map((c) => `${timestamp(c.startMs, ".")} --> ${timestamp(c.endMs, ".")}
${cueText(c, language).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}
`).join("\n");
  }

  // content/auto-translate.js
  function autoTranslationLanguageNotice(meta) {
    if (!meta || meta.platform === "primevideo" || meta.videoId?.startsWith("prime:")) return "";
    if (/^en(?:-|$)/i.test(meta.audioLanguage || "")) return "";
    return meta.audioLanguage ? `影片音訊判定為非英文（${meta.audioLanguage}），已略過自動翻譯。需要時可手動開始。` : "無法確認影片音訊是否為英文，已略過自動翻譯。確認字幕適合後，可手動開始。";
  }
  var AutoTranslationGate = class {
    constructor() {
      this.attempted = /* @__PURE__ */ new Set();
    }
    take(state2) {
      const { meta, track, cache, job, settings, pref, starting: starting2 } = state2;
      if (!settings?.autoTranslate || !settings.hasConnection || !meta || meta.isLive || autoTranslationLanguageNotice(meta) || nativeChineseTracks(meta.captionTracks).length || !track || cache && !cache.partial || ACTIVE_STATUSES.includes(job?.status) || starting2 || pref?.enabled === false) return false;
      const version = translationVersion(meta);
      const key = cacheKey({ ...meta, promptVersion: version }, track, settings);
      if (this.attempted.has(key)) return false;
      this.attempted.add(key);
      return true;
    }
  };

  // content/subtitle-buffer-controller.js
  function availableSubtitleSeconds(cache, playheadMs, durationMs = Infinity) {
    if (cache && !cache.partial) return Math.max(0, (durationMs - playheadMs) / 1e3);
    if (!cache?.sourceCues?.length) return 0;
    const translated = (cache.translatedCues || []).slice().sort((a, b) => a.startMs - b.startMs);
    let index = 0;
    for (const source of cache.sourceCues) {
      if (source.endMs <= playheadMs) continue;
      let cursor = Math.max(playheadMs, source.startMs);
      while (index < translated.length && translated[index].endMs <= cursor) index++;
      for (let n = index; n < translated.length && cursor < source.endMs; n++) {
        const c = translated[n];
        if (c.startMs > cursor + 50) break;
        cursor = Math.max(cursor, c.endMs);
      }
      if (cursor < source.endMs) return Math.max(0, (cursor - playheadMs) / 1e3);
    }
    return Math.max(0, (durationMs - playheadMs) / 1e3);
  }
  var SubtitleBufferController = class {
    constructor(video, readState, notify = () => {
    }, interactionTarget = null) {
      this.read = readState;
      this.notify = notify;
      this.held = false;
      this.pending = false;
      this.resumeFailures = 0;
      this.resumeError = null;
      this.lastResumeAt = 0;
      this.destroyed = false;
      this.intentSequence = 0;
      this.pause = () => {
      };
      this.play = () => {
        this.held = false;
        if (!this.pending) {
          this.resumeError = null;
          this.resumeFailures = 0;
        }
        this.check();
      };
      this.timeupdate = () => this.check();
      this.userIntent = (event) => {
        if (!event.isTrusted) return;
        const target = event.target;
        if (target?.closest?.('#ytgpt-control,input,textarea,select,[contenteditable="true"]')) return;
        const button = target?.closest?.('button,[role="button"]'), label = button?.getAttribute?.("aria-label") || button?.getAttribute?.("title") || button?.textContent || "";
        const key = event.type === "keydown" && !event.altKey && !event.ctrlKey && !event.metaKey && [" ", "Spacebar", "k", "K"].includes(event.key);
        if (key || /^(?:pause|暫停|暂停)(?:\b|\s|\(|$)/i.test(label.trim()) || target === this.video && !this.video.paused) {
          this.intentSequence++;
          this.held = false;
          this.resumeError = null;
          this.notify();
        }
      };
      this.replaceVideo(video, interactionTarget);
      this.timer = setInterval(() => this.check(), 500);
    }
    detach() {
      this.video?.removeEventListener("pause", this.pause);
      this.video?.removeEventListener("play", this.play);
      this.video?.removeEventListener("timeupdate", this.timeupdate);
      for (const type of ["pointerdown", "click", "keydown"]) this.interactionTarget?.removeEventListener(type, this.userIntent, true);
    }
    replaceVideo(video, interactionTarget = null) {
      this.detach();
      this.video = video;
      this.pending = false;
      this.resumeFailures = 0;
      this.resumeError = null;
      this.lastResumeAt = 0;
      this.interactionTarget = interactionTarget || video.parentElement || video;
      video.addEventListener("pause", this.pause);
      video.addEventListener("play", this.play);
      video.addEventListener("timeupdate", this.timeupdate);
      for (const type of ["pointerdown", "click", "keydown"]) this.interactionTarget.addEventListener(type, this.userIntent, true);
    }
    resume() {
      if (this.pending || this.resumeFailures >= 3 || Date.now() - this.lastResumeAt < 1e3) return;
      const video = this.video, intent = this.intentSequence;
      this.pending = true;
      this.lastResumeAt = Date.now();
      const failed = (error) => {
        if (this.destroyed || video !== this.video) return;
        this.pending = false;
        if (intent !== this.intentSequence) return;
        this.held = true;
        this.resumeFailures++;
        this.resumeError = error?.name === "NotAllowedError" ? "瀏覽器未允許自動續播，請按播放器的播放鍵。" : this.resumeFailures >= 3 ? "播放器未能自動續播，請按播放鍵繼續。" : null;
        if (error?.name === "NotAllowedError") this.resumeFailures = 3;
        this.notify();
      };
      try {
        Promise.resolve(video.play()).then(() => {
          if (this.destroyed || video !== this.video) return;
          this.pending = false;
          if (!video.paused) {
            this.held = false;
            this.resumeFailures = 0;
            this.resumeError = null;
          } else failed(new Error("Playback stayed paused"));
          this.notify();
        }, failed);
      } catch (error) {
        failed(error);
      }
    }
    check() {
      if (this.destroyed || this.video.isConnected === false || this.video.readyState === 0 || this.video.getBoundingClientRect?.().width === 0) return;
      const s = this.read(), busy = s.starting || ACTIVE_STATUSES.includes(s.job?.status), enabled = s.settings.pauseForSubtitles && s.pref?.enabled !== false && s.pref?.mode !== "en" && !s.meta?.isLive && !nativeChineseTracks(s.meta?.captionTracks).length;
      const seconds = availableSubtitleSeconds(s.cache, subtitleTimeMs(this.video.currentTime, s.pref?.subtitleOffsetMs), (s.meta?.duration || this.video.duration) * 1e3), threshold = (this.held ? 8 : 2) * (this.video.playbackRate || 1), needs = enabled && busy && seconds < threshold;
      if (needs && !this.video.paused) {
        this.held = true;
        this.resumeFailures = 0;
        this.resumeError = null;
        this.lastResumeAt = 0;
        this.video.pause();
        this.notify();
      } else if (this.held && !needs) {
        if (s.error || s.job?.status === "error" || this.video.ended) {
          this.held = false;
          this.resumeError = null;
          this.notify();
        } else if (this.video.paused) this.resume();
        else {
          this.held = false;
          this.notify();
        }
      }
    }
    destroy() {
      this.destroyed = true;
      clearInterval(this.timer);
      this.detach();
      this.held = false;
    }
  };

  // export/subtitle-file.js
  function subtitleBackup(cache, meta) {
    return JSON.stringify({ format: "ytgpt-subtitles", version: 1, videoId: meta.videoId, title: meta.title, duration: meta.duration, translatedCues: cache.translatedCues.map((c) => ({ startMs: c.startMs, endMs: c.endMs, en: c.en || "", zh: c.zh || "" })) }, null, 2);
  }

  // content/content-script.js
  var CHANNEL = "ytgpt-player-bridge-v1";
  var extensionVersion = chrome.runtime.getManifest().version;
  document.documentElement?.setAttribute("data-ytgpt-extension-version", extensionVersion);
  var state = { videoId: null, meta: null, tracks: [], track: null, job: null, cache: null, pref: { enabled: true, mode: "zh" }, settings: DEFAULT_SETTINGS, error: null };
  var epoch = 0;
  var startSequence = 0;
  var renderer = null;
  var sync = null;
  var control = null;
  var playerObserver = null;
  var playerTimer = null;
  var requestTimer = null;
  var fetchController = null;
  var starting = false;
  var refreshing = false;
  var priorityVideo = null;
  var bufferController = null;
  var lastPriority = 0;
  var prioritize = () => {
    if (state.job && ACTIVE_STATUSES.includes(state.job.status)) send(MSG.PRIORITY, { jobId: state.job.jobId, playheadMs: Math.max(0, subtitleTimeMs(priorityVideo?.currentTime || 0, state.pref.subtitleOffsetMs)) }).catch(() => {
    });
  };
  var trackPlayhead = () => {
    if (Date.now() - lastPriority > 3e3) {
      lastPriority = Date.now();
      prioritize();
    }
  };
  var requests = /* @__PURE__ */ new Map();
  var autoTranslation = new AutoTranslationGate();
  function maybeAutoTranslate() {
    if (contextAlive() && autoTranslation.take({ ...state, starting })) act(() => start({ automatic: true })).catch(() => {
    });
  }
  var contextExpired = false;
  var stopNavigation = null;
  function contextAlive() {
    if (contextExpired) return false;
    if (chrome.runtime.id) return true;
    contextExpired = true;
    epoch++;
    const host = control?.parentElement;
    cleanup();
    stopNavigation?.();
    for (const request of requests.values()) {
      clearTimeout(request.timer);
      request.resolve(null);
    }
    requests.clear();
    if (host?.isConnected) {
      const notice = document.createElement("p"), reload = document.createElement("button");
      notice.id = "ytgpt-reload-notice";
      notice.textContent = "字幕插件已更新，請重新整理此影片頁面。";
      reload.textContent = "重新整理影片";
      reload.addEventListener("click", () => location.reload());
      notice.append(reload);
      host.prepend(notice);
    }
    return false;
  }
  function bridge(type = "REQUEST", payload = {}, signal) {
    return new Promise((resolve, reject) => {
      const id = crypto.randomUUID(), cancel2 = () => {
        if (type === "YOUTUBE_SOURCE") window.postMessage({ channel: CHANNEL, type: "CANCEL_SOURCE", requestId: id }, location.origin);
      };
      const finish = (value, error) => {
        clearTimeout(timer);
        requests.delete(id);
        signal?.removeEventListener("abort", abort);
        error ? reject(error) : resolve(value);
      };
      const abort = () => {
        cancel2();
        finish(null, signal.reason || new DOMException("Aborted", "AbortError"));
      };
      const timer = setTimeout(() => {
        cancel2();
        finish(null, type === "REQUEST" ? null : new Error("播放器字幕讀取逾時，請重新整理影片後再試。"));
      }, type === "REQUEST" ? 1500 : type === "YOUTUBE_SOURCE" ? 15e3 : 35e3);
      requests.set(id, { resolve: (value) => finish(value), reject: (error) => finish(null, error), timer });
      signal?.addEventListener("abort", abort, { once: true });
      if (signal?.aborted) {
        abort();
        return;
      }
      window.postMessage({ channel: CHANNEL, type, requestId: id, ...payload }, location.origin);
    });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin || event.data?.channel !== CHANNEL || event.data.type !== "RESPONSE") return;
    const req = requests.get(event.data.requestId);
    if (req) {
      event.data.error ? req.reject(new Error(event.data.error)) : req.resolve(event.data.data);
    }
  });
  function cleanup() {
    sync?.destroy();
    renderer?.destroy();
    bufferController?.destroy();
    bufferController = null;
    control?.remove();
    playerObserver?.disconnect();
    clearInterval(playerTimer);
    clearTimeout(requestTimer);
    fetchController?.abort();
    sync = null;
    renderer = null;
    control = null;
    playerObserver = null;
    playerTimer = null;
    starting = false;
    startSequence++;
    priorityVideo?.removeEventListener("seeked", prioritize);
    priorityVideo?.removeEventListener("timeupdate", trackPlayhead);
    priorityVideo = null;
  }
  function snapshot() {
    return { platform: isPrime() ? "primevideo" : "youtube", videoId: state.videoId, title: state.meta?.title || "", tracks: state.tracks.map(publicTrack), track: publicTrack(state.track), job: state.job, hasCache: Boolean(state.cache && !state.cache.partial), hasPlayable: Boolean(state.cache?.translatedCues?.length), partial: Boolean(state.cache?.partial), waitingForSubtitles: Boolean(bufferController?.held), playbackError: bufferController?.resumeError || null, importedSubtitles: Boolean(state.cache?.imported), bufferedSeconds: Math.floor(availableSubtitleSeconds(state.cache, subtitleTimeMs(findVideoElement2()?.currentTime || 0, state.pref.subtitleOffsetMs), (state.meta?.duration || 0) * 1e3)), cueCount: state.cache?.sourceCues?.length || state.job?.totalCues || 0, pref: state.pref, model: state.settings.model, promptVersion: state.cache?.promptVersion || state.job?.promptVersion || PROMPT_VERSION, error: state.error, live: state.meta?.isLive, ready: Boolean(state.meta), nativeChinese: Boolean(nativeChineseTracks(state.meta?.captionTracks).length), audioLanguage: state.meta?.audioLanguage || null, autoTranslateBlockedReason: state.settings.autoTranslate && state.track ? autoTranslationLanguageNotice(state.meta) : "", starting };
  }
  function diagnostics() {
    const s = snapshot();
    return { extensionVersion, videoId: s.videoId, audioLanguage: s.audioLanguage, audioLanguageSource: state.meta?.audioLanguageSource || null, autoTranslateBlockedReason: s.autoTranslateBlockedReason, captionTrack: s.track, cueCount: s.cueCount, cacheStatus: s.hasCache ? "hit" : s.hasPlayable ? "partial" : "miss", bufferedSeconds: s.bufferedSeconds, terminologyStatus: s.job?.terminologyStatus || state.cache?.terminologyStatus || null, model: s.model, promptVersion: s.promptVersion, jobId: s.job?.jobId || null, jobStatus: s.job?.status || "idle", error: s.error || s.job?.error || null, warnings: [.../* @__PURE__ */ new Set([...state.cache?.warnings || [], ...s.job?.warnings || []])] };
  }
  function statusText() {
    if (nativeChineseTracks(state.meta?.captionTracks).length) return "影片已有原生中文字幕，已略過 GPT 翻譯。請在播放器選擇中文字幕。";
    if (state.error) return state.error;
    if (bufferController?.resumeError) return bufferController.resumeError;
    if (bufferController?.held) return "正在等待中文字幕緩衝，準備好後會自動播放…";
    if (!state.meta) return isPrime() ? "正在等待 Prime Video 英文字幕；若已開始播放仍未偵測到，請重新整理影片頁面。" : "正在偵測影片與英文字幕…";
    if (state.meta.isLive) return "第一版不支援直播字幕";
    if (starting) return "正在取得英文字幕…";
    if (state.cache?.partial && ACTIVE_STATUSES.includes(state.job?.status)) return `已可顯示中文字幕 · 目前位置已準備 ${snapshot().bufferedSeconds} 秒，背景繼續翻譯 · ${state.job.progress}%`;
    if (state.job && ACTIVE_STATUSES.includes(state.job.status)) return `${state.job.phase} ${state.job.progress}% · ${state.job.translatedCues} / ${state.job.totalCues}`;
    if (state.job?.error) return state.job.error;
    if (state.job?.status === "cancelled") return "已取消，可從目前進度繼續";
    if (state.cache?.partial) return "已載入部分中文字幕，可接續翻譯";
    if (state.cache) return `✓ 已載入本機中文字幕 · 字幕${state.pref.enabled ? "已開啟" : "已關閉"}`;
    if (state.settings.autoTranslate && state.track && autoTranslationLanguageNotice(state.meta)) return autoTranslationLanguageNotice(state.meta);
    return state.track ? `${state.track.autoGenerated ? "YouTube 自動" : "人工"}英文 CC ✓` : "這支影片沒有可用英文 CC";
  }
  function mount() {
    if (!contextAlive()) return;
    const video = findVideoElement2(), player = findPlayer2(video);
    if (!video || !player) {
      sync?.destroy();
      renderer?.destroy();
      sync = null;
      renderer = null;
      return;
    }
    if (priorityVideo !== video) {
      priorityVideo?.removeEventListener("seeked", prioritize);
      priorityVideo?.removeEventListener("timeupdate", trackPlayhead);
      priorityVideo = video;
      video.addEventListener("seeked", prioritize);
      video.addEventListener("timeupdate", trackPlayhead);
      bufferController?.replaceVideo(video, player);
    }
    if (!bufferController) bufferController = new SubtitleBufferController(video, () => ({ ...state, starting }), () => updateControl(), player);
    if (renderer?.player !== player || sync?.video && sync.video !== video) {
      sync?.destroy();
      renderer?.destroy();
      renderer = null;
      sync = null;
    }
    if (!renderer) renderer = new SubtitleRenderer(player, state.settings.style, state.pref.mode);
    if (!control?.isConnected) {
      control?.remove();
      control = document.createElement("div");
      control.id = "ytgpt-control";
      const root = control.attachShadow({ mode: "open" });
      root.innerHTML = `<style>:host{color:#edf2fa;font:13px/1.5 system-ui,"Microsoft JhengHei",sans-serif}*{box-sizing:border-box}button,select{font:inherit;background:#202b3c;color:#edf2fa;border:1px solid #46556d;border-radius:9px;padding:9px 12px;margin:4px 6px 4px 0}button{cursor:pointer}button:hover{background:#2e3c51}button:disabled{opacity:.5;cursor:default}#start{background:#a7d0ff;color:#102947;font-weight:600;border-color:#a7d0ff}details{background:rgba(16,21,31,.96);border:1px solid #344156;border-radius:12px;padding:10px 14px;max-width:480px;box-shadow:0 6px 22px #0003}summary{cursor:pointer;font-weight:600;min-height:24px}p{line-height:1.6;margin:10px 0;color:#b7c6da}#status{color:#edf2fa}select{max-width:100%}:focus-visible{outline:3px solid #93c5fd;outline-offset:2px}input[hidden]{display:none}</style><details><summary>AI 字幕 <span id="badge"></span></summary><p id="status" role="status"></p><select id="track" aria-label="英文字幕來源"></select><div><button id="start">產生繁中字幕</button><button id="cancel">取消</button><button id="toggle">關閉字幕</button></div><select id="mode" aria-label="字幕顯示模式"></select><button id="options">⚙ 字幕設定</button><p id="terminology"></p><p>翻譯使用你的 ChatGPT 方案額度，每批完成就能播放，並儲存於本機。</p></details>`;
      root.querySelector("details").insertAdjacentHTML("beforeend", '<div><button id="save-json">另存字幕備份</button><button id="save-srt">另存繁中 SRT</button><button id="load-file">載入字幕檔</button><input id="subtitle-file" type="file" accept=".srt,.vtt,.json" hidden></div><p id="file-status"></p>');
      for (const [value, label] of Object.entries(MODES)) {
        const o = new Option(label, value);
        root.querySelector("#mode").add(o);
      }
      const clickAction = (fn) => {
        act(fn).catch(() => {
        });
      };
      root.querySelector("#start").addEventListener("click", () => clickAction(start));
      root.querySelector("#cancel").addEventListener("click", () => clickAction(cancel));
      root.querySelector("#toggle").addEventListener("click", () => clickAction(() => setPref({ enabled: !state.pref.enabled })));
      root.querySelector("#options").addEventListener("click", () => clickAction(() => send(MSG.OPTIONS)));
      root.querySelector("#mode").addEventListener("change", (e) => clickAction(() => setPref({ mode: e.target.value })));
      root.querySelector("#track").addEventListener("change", (e) => clickAction(() => chooseTrack(e.target.value)));
      root.querySelector("#save-json").addEventListener("click", () => clickAction(() => exportSubtitle("json", "bilingual")));
      root.querySelector("#save-srt").addEventListener("click", () => clickAction(() => exportSubtitle("srt", "zh")));
      root.querySelector("#load-file").addEventListener("click", () => root.querySelector("#subtitle-file").click());
      root.querySelector("#subtitle-file").addEventListener("change", (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        clickAction(() => importSubtitle(file));
      });
    }
    const below = document.querySelector("ytd-watch-flexy #below");
    if (isPrime()) {
      control.classList.add("ytgpt-prime-control");
      if (control.parentElement !== player) player.append(control);
    } else if (below && control.parentElement !== below) below.prepend(control);
    else if (!control.isConnected) {
      const host = player.closest("#player") || player.closest("ytd-player") || player;
      host.insertAdjacentElement("afterend", control);
    }
    updateControl();
    apply();
  }
  function updateControl() {
    if (!contextAlive() || !control?.isConnected) return;
    const root = control.shadowRoot, busy = starting || ACTIVE_STATUSES.includes(state.job?.status);
    root.querySelector("#status").textContent = statusText();
    root.querySelector("#badge").textContent = state.cache ? "✓" : busy ? `${state.job?.progress || 0}%` : state.track ? "CC ✓" : "";
    const startButton = root.querySelector("#start");
    startButton.disabled = busy || !state.track || state.meta?.isLive || Boolean(nativeChineseTracks(state.meta?.captionTracks).length);
    startButton.textContent = ["error", "cancelled"].includes(state.job?.status) ? "繼續翻譯" : state.cache && !state.cache.partial ? "立即載入字幕" : "產生繁中字幕";
    root.querySelector("#cancel").hidden = !busy;
    root.querySelector("#toggle").hidden = !state.videoId;
    root.querySelector("#toggle").textContent = state.pref.enabled ? "關閉 AI 字幕" : "開啟 AI 字幕";
    const terms = diagnostics();
    root.querySelector("#terminology").textContent = terms.terminologyStatus === "searching" ? "GPT-6 正在搜尋中文專有名詞，字幕先使用中文翻譯或音譯。" : terms.terminologyStatus === "ready" ? "GPT-6 術語搜尋完成，字幕將套用中文詞彙表。" : terms.terminologyStatus === "failed" ? terms.warnings.find((w) => w.includes("術語搜尋未完成")) || "GPT-6 術語搜尋未完成，目前使用中文翻譯或音譯。" : "";
    root.querySelector("#mode").value = state.pref.mode;
    root.querySelector("#track").disabled = busy;
    root.querySelector("#save-json").hidden = root.querySelector("#save-srt").hidden = !state.cache || Boolean(state.cache.partial);
    root.querySelector("#file-status").textContent = state.cache?.imported ? "已載入本機字幕檔，不使用 GPT 額度。" : state.cache ? `已沿用本機字幕${state.cache.model ? `（${state.cache.model}）` : ""}${state.cache.partial ? "；其餘接續翻譯。" : "，不重翻。"}` : "";
    const trackSelect = root.querySelector("#track");
    const signature = state.tracks.map((t) => t.sourceTrackId).join("|");
    if (trackSelect.dataset.signature !== signature) {
      trackSelect.replaceChildren(...state.tracks.map((t) => new Option(`${t.name || t.languageCode}（${t.autoGenerated ? "自動" : "人工"}）`, t.sourceTrackId)));
      trackSelect.dataset.signature = signature;
    }
    trackSelect.value = state.track?.sourceTrackId || "";
  }
  function apply() {
    if (!contextAlive() || !renderer) return;
    renderer.configure(state.settings.style, state.pref.mode);
    renderer.setEnabled(Boolean(state.cache && state.pref.enabled && (!nativeChineseTracks(state.meta?.captionTracks).length || state.cache.imported)));
    const video = findVideoElement2();
    if (state.cache && !sync && video) sync = new SubtitleSync(video, state.cache.translatedCues, (cues) => renderer?.render(cues), () => renderer?.player.classList.contains("ad-showing") || renderer?.player.classList.contains("ad-interrupting"), () => state.pref.subtitleOffsetMs);
    sync?.update();
    bufferController?.check();
  }
  async function refreshCache(token = epoch) {
    if (!state.meta) return;
    const videoId = state.videoId, track = state.track, result = await send(MSG.LOOKUP, { meta: state.meta, track });
    if (token !== epoch || videoId !== state.videoId || track?.sourceTrackId !== state.track?.sourceTrackId) return;
    if ((result.cache?.revision || 0) < (state.cache?.revision || 0)) return;
    if (result.job?.jobId === state.job?.jobId && (result.job?.updatedAt || 0) < (state.job?.updatedAt || 0)) return;
    sync?.destroy();
    sync = null;
    Object.assign(state, result);
    state.settings = result.settings;
    updateControl();
    mount();
  }
  async function chooseTrack(id) {
    const track = state.tracks.find((t) => t.sourceTrackId === id);
    if (!track) return;
    state.track = track;
    state.cache = null;
    state.job = null;
    state.error = null;
    sync?.destroy();
    sync = null;
    renderer?.render([]);
    renderer?.setEnabled(false);
    await setPref({ sourceTrackId: id });
    await refreshCache();
    maybeAutoTranslate();
  }
  async function detect(id) {
    if (!contextAlive()) return;
    if (id !== state.videoId) {
      epoch++;
      cleanup();
      state = { videoId: id, meta: null, tracks: [], track: null, job: null, cache: null, pref: { enabled: true, mode: "zh" }, settings: state.settings, error: null };
    }
    if (!id) return;
    const token = epoch;
    if (refreshing) {
      requestTimer = setTimeout(() => detect(currentVideoId2()), 200);
      return;
    }
    refreshing = true;
    try {
      const meta = await bridge();
      if (token !== epoch) return;
      if (!meta || meta.videoId !== id) {
        mount();
        requestTimer = setTimeout(() => detect(currentVideoId2()), 1500);
        return;
      }
      const previous = state.meta;
      state.meta = meta;
      if (nativeChineseTracks(meta.captionTracks).length && (starting || ACTIVE_STATUSES.includes(state.job?.status))) {
        await cancel();
        if (token !== epoch) return;
      }
      if (previous && meta.sourceRevision !== previous.sourceRevision) {
        const freshTracks = englishTracks(meta.captionTracks);
        state.track = freshTracks.find((t) => t.sourceTrackId === state.track?.sourceTrackId) || freshTracks[0] || null;
        state.tracks = freshTracks;
      }
      if (!previous || !state.tracks.length) {
        state.tracks = englishTracks(meta.captionTracks);
        state.track = state.tracks[0] || null;
        state.error = null;
        log("video detected", id);
        if (state.track) log(`${state.track.autoGenerated ? "auto" : "human"} English caption detected`, state.track.languageCode);
        const initial = await send(MSG.LOOKUP, { meta, track: state.track });
        if (token !== epoch) return;
        state.pref = initial.pref;
        const saved = state.tracks.find((t) => t.sourceTrackId === state.pref.sourceTrackId);
        if (saved) state.track = saved;
        await refreshCache(token);
      }
      mount();
      maybeAutoTranslate();
      if (!playerObserver) {
        let scheduled = false;
        playerObserver = new MutationObserver(() => {
          if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(() => {
              scheduled = false;
              if (token === epoch) mount();
            });
          }
        });
        playerObserver.observe(document.querySelector("ytd-watch-flexy") || document.body, { childList: true, subtree: true });
        playerTimer = setInterval(() => {
          if (token === epoch) mount();
        }, 2e3);
      }
    } catch (e) {
      if (token === epoch) {
        state.error = e.message;
        updateControl();
      }
    } finally {
      refreshing = false;
    }
  }
  async function start({ automatic = false } = {}) {
    if (nativeChineseTracks(state.meta?.captionTracks).length) {
      updateControl();
      return;
    }
    if (starting || ACTIVE_STATUSES.includes(state.job?.status)) return;
    if (state.cache && !state.cache.partial) {
      await setPref({ enabled: true });
      return;
    }
    const token = epoch, attempt = ++startSequence;
    let meta = state.meta, track = state.track;
    if (!track) throw new Error("這支影片沒有可用英文 CC。");
    state.error = null;
    starting = true;
    updateControl();
    try {
      await setPref({ enabled: true });
      if (token !== epoch || attempt !== startSequence) return;
      const fresh = await bridge();
      if (token !== epoch || attempt !== startSequence) return;
      if (fresh?.videoId === meta.videoId) {
        const tracks = englishTracks(fresh.captionTracks);
        meta = fresh;
        track = tracks.find((t) => t.sourceTrackId === track.sourceTrackId) || tracks[0] || null;
        state.meta = meta;
        state.tracks = tracks;
        state.track = track;
      }
      if (nativeChineseTracks(meta.captionTracks).length || automatic && autoTranslationLanguageNotice(meta)) return;
      if (!track) throw new Error("這支影片沒有可用英文 CC。");
      let result;
      const resume = ["cancelled", "error"].includes(state.job?.status);
      let source = null;
      if (!resume || !state.job.totalCues) {
        fetchController = new AbortController();
        if (isPrime()) {
          validatePrimeCaptionUrl(track.baseUrl);
          const response = await bridge("PRIME_SOURCE", { videoId: meta.videoId, url: track.baseUrl }, fetchController.signal);
          source = primeCaptionSource(response.raw, meta.duration);
        } else {
          for (let attempt2 = 0; attempt2 < 2; attempt2++) {
            try {
              source = await fetchVideoCaptionSource(track, meta, fetchController.signal, { player: (t, m, s) => bridge("YOUTUBE_SOURCE", { videoId: m.videoId, track: { languageCode: t.languageCode, name: t.name, kind: t.kind || "", vssId: t.vssId } }, s) });
              break;
            } catch (e) {
              if (e.code !== "CAPTION_NOT_READY" || attempt2 === 1) throw e;
              const updated = await bridge();
              if (updated?.videoId === meta.videoId) {
                meta = updated;
                track = englishTracks(updated.captionTracks).find((t) => t.sourceTrackId === track.sourceTrackId) || track;
              }
            }
          }
        }
        if (token !== epoch || attempt !== startSequence) return;
      }
      const playheadMs = Math.max(0, subtitleTimeMs(findVideoElement2()?.currentTime || 0, state.pref.subtitleOffsetMs));
      if (nativeChineseTracks(meta.captionTracks).length || automatic && autoTranslationLanguageNotice(meta)) return;
      result = resume ? await send(MSG.RESUME, { jobId: state.job.jobId, meta, track, source, playheadMs }) : await send(MSG.START, { meta, track, source, playheadMs });
      if (token !== epoch || attempt !== startSequence) {
        if (result.job && attempt !== startSequence && token === epoch) await send(MSG.CANCEL, { jobId: result.job.jobId });
        return;
      }
      if (result.cache) state.cache = result.cache;
      else state.job = result.job;
    } finally {
      if (token === epoch && attempt === startSequence) {
        starting = false;
        updateControl();
        mount();
      }
    }
  }
  async function cancel() {
    const token = epoch;
    startSequence++;
    fetchController?.abort();
    if (state.job?.jobId) {
      await send(MSG.CANCEL, { jobId: state.job.jobId });
      await refreshCache(token);
    }
    if (token === epoch) {
      starting = false;
      updateControl();
    }
  }
  async function setPref(patch) {
    const id = state.videoId, token = epoch;
    const value = await send(MSG.PREF, { videoId: id, pref: patch });
    if (token === epoch) {
      state.pref = value;
      updateControl();
      apply();
      if (patch.subtitleOffsetMs !== void 0) prioritize();
    }
  }
  async function act(fn) {
    const token = epoch;
    try {
      return await fn();
    } catch (e) {
      if (token !== epoch || e.name === "AbortError" || e.code === "VIDEO_CHANGED") return;
      state.error = e.message;
      updateControl();
      throw e;
    }
  }
  async function exportSubtitle(format, language) {
    if (!state.cache || state.cache.partial) throw new Error("字幕仍在背景翻譯，全部完成後才能匯出。");
    const data = format === "json" ? subtitleBackup(state.cache, state.meta) : format === "vtt" ? toVTT(state.cache.translatedCues, language) : toSRT(state.cache.translatedCues, language);
    await send(MSG.SAVE_FILE, { videoId: state.videoId, title: state.meta.title, format, language: language === "zh" ? "zh-TW" : language, raw: data });
    return true;
  }
  async function importSubtitle(file) {
    if (!file) return;
    if (file.size > 1e7) throw new Error("字幕檔不可超過 10 MB。");
    const token = epoch, meta = state.meta || { videoId: state.videoId, title: document.title, duration: findVideoElement2()?.duration };
    if (!meta.videoId) throw new Error("請先開啟影片。");
    const raw = await file.text();
    if (token !== epoch) return;
    const result = await send(MSG.IMPORT_FILE, { meta, raw, format: file.name.split(".").at(-1).toLowerCase() });
    if (token !== epoch) return;
    state.meta = meta;
    state.cache = result.cache;
    state.error = null;
    sync?.destroy();
    sync = null;
    await setPref({ enabled: true, mode: "zh" });
    mount();
  }
  chrome.runtime.onMessage.addListener((m, sender, respond) => {
    if (sender.id !== chrome.runtime.id) return;
    if (m.type === MSG.SETTINGS_CHANGED) {
      const hasConnection = state.settings.hasConnection;
      state.settings = { ...m.settings, hasConnection };
      apply();
      if (m.cacheIdentityChanged) {
        state.error = null;
        refreshCache().then(maybeAutoTranslate).catch((e) => {
          state.error = e.message;
          updateControl();
        });
      } else maybeAutoTranslate();
      return;
    }
    if (m.type === MSG.PREF_CHANGED && m.videoId === state.videoId) {
      const offsetChanged = state.pref.subtitleOffsetMs !== m.pref.subtitleOffsetMs;
      state.pref = m.pref;
      apply();
      updateControl();
      if (offsetChanged) prioritize();
      return;
    }
    if (m.type === MSG.CONTENT_STATE) {
      respond({ ok: true, data: { ...snapshot(), diagnostics: diagnostics() } });
      return;
    }
    if (m.type === MSG.UPDATE && m.videoId === state.videoId) {
      if (m.job?.jobId === state.job?.jobId && (m.job.updatedAt || 0) < (state.job.updatedAt || 0)) return;
      state.job = m.job;
      state.error = null;
      updateControl();
      if (m.job?.playableCues || m.job?.status === "completed") refreshCache().catch((e) => {
        state.error = e.message;
        updateControl();
      });
      return;
    }
    if (m.type === MSG.INVALIDATE && (!m.videoId || m.videoId === state.videoId)) {
      sync?.destroy();
      sync = null;
      state.cache = null;
      renderer?.render([]);
      renderer?.setEnabled(false);
      refreshCache().catch(() => {
      });
      return;
    }
    let action;
    if (m.type === MSG.CONTENT_START) action = start;
    if (m.type === MSG.CANCEL) action = cancel;
    if (m.type === MSG.EXPORT) action = () => exportSubtitle(m.format, m.language);
    if (m.type === MSG.IMPORT_FILE) action = () => importSubtitle({ size: new TextEncoder().encode(m.raw || "").length, name: m.filename, text: async () => m.raw });
    if (m.type === MSG.CONTENT_PREF) action = () => {
      if (m.videoId && m.videoId !== state.videoId) throw new Error("影片已切換，請重新調整目前影片的字幕時間。");
      if (m.command === "toggle-subtitles") return setPref({ enabled: !state.pref.enabled });
      if (m.command === "cycle-mode") {
        const modes = ["zh", "both-en", "en"];
        return setPref({ mode: modes[(modes.indexOf(state.pref.mode) + 1) % 3] });
      }
      if (m.sourceTrackId) return chooseTrack(m.sourceTrackId);
      return setPref(m.pref || {});
    };
    if (action) {
      act(action).then((data) => respond({ ok: true, data })).catch((e) => respond({ ok: false, error: e.message }));
      return true;
    }
  });
  send(MSG.SETTINGS).then((s) => {
    state.settings = s;
    apply();
  }).catch(() => {
  });
  stopNavigation = watchNavigation2((id) => detect(id));
})();
