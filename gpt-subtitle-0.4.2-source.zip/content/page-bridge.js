(() => {
  const CHANNEL='ytgpt-player-bridge-v1';
  const nativeFetch=window.fetch,captured=new Map(),sourceRequests=new Map();
  const currentId=()=>new URL(location.href).searchParams.get('v');
  function captionKey(value) {
    try {
      const u=new URL(value,location.origin);
      if(u.origin!==location.origin||u.pathname!=='/api/timedtext'||u.searchParams.get('v')!==currentId()||!/^en(?:-|$)/i.test(u.searchParams.get('lang')||'')||['tlang','seq','start','end'].some(k=>u.searchParams.has(k)))return null;
      return JSON.stringify(['v','lang','kind','name'].map(k=>u.searchParams.get(k)||''));
    }catch{return null;}
  }
  function captionData(raw) {
    if(typeof raw!=='string'||raw.length>10000000)return false;
    const text=raw.trim();
    if(/^\{/.test(text)){try{const data=JSON.parse(text);return Array.isArray(data.events)&&data.events.some(e=>Array.isArray(e.segs)&&e.segs.some(s=>s.utf8));}catch{return false;}}
    return /<(?:transcript|timedtext)\b/.test(text)&&/<(?:text|p)\b/.test(text)&&!/<!(?:DOCTYPE|ENTITY)/i.test(text);
  }
  function remember(url,raw) {
    const key=captionKey(url);if(!key||!captionData(raw))return;
    // Keep only recent complete English sources, never player/audio responses.
    captured.delete(key);captured.set(key,raw);
    while(captured.size>4)captured.delete(captured.keys().next().value);
  }
  if(typeof nativeFetch==='function')window.fetch=function(input) {
    const url=typeof input==='string'?input:input?.url||String(input),key=captionKey(url);
    const result=nativeFetch.apply(this,arguments);
    if(key)result.then(r=>{if(r.ok)return r.clone().text().then(raw=>remember(url,raw));}).catch(()=>{});
    return result;
  };
  const xhr=window.XMLHttpRequest?.prototype;
  if(xhr){const open=xhr.open,send=xhr.send,urls=new WeakMap();
    xhr.open=function(method,url){urls.set(this,String(url));return open.apply(this,arguments);};
    xhr.send=function(){const url=urls.get(this);if(captionKey(url))this.addEventListener('load',()=>{try{if(this.status>=200&&this.status<300)remember(url,this.responseType==='json'?JSON.stringify(this.response):this.responseText);}catch{}},{once:true});return send.apply(this,arguments);};
  }
  window.addEventListener('yt-navigate-start',()=>{captured.clear();for(const c of sourceRequests.values())c.abort();});
  function parseResponse(value) { try { return typeof value==='string'?JSON.parse(value):value; } catch { return null; } }
  function audioLanguage(response) {
    const code=value=>{const text=String(value||'').split('.')[0].replaceAll('_','-');return /^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/i.test(text)?text.toLowerCase():null;};
    const formats=[...(response.streamingData?.formats||[]),...(response.streamingData?.adaptiveFormats||[])];
    const tracks=formats.map(f=>f.audioTrack).filter(Boolean);
    const original=tracks.filter(t=>t.isOriginal===true||/\boriginal\b|原始|原音|原聲|原声|オリジナル/i.test(String(t.displayName||'')));
    const unique=list=>[...new Set(list.map(t=>code(t.languageCode||t.id)).filter(Boolean))];
    const originals=unique(original);
    if(originals.length===1)return {audioLanguage:originals[0],audioLanguageSource:'original-audio-track'};
    if(originals.length>1)return {audioLanguage:null,audioLanguageSource:'conflicting-audio-tracks'};
    const languages=unique(tracks);
    const declared=code(response.videoDetails?.defaultAudioLanguage||response.microformat?.playerMicroformatRenderer?.defaultAudioLanguage);
    if(declared){if(languages.some(language=>language.split('-')[0]!==declared.split('-')[0]))return {audioLanguage:null,audioLanguageSource:'conflicting-audio-tracks'};return {audioLanguage:declared,audioLanguageSource:'default-audio-language'};}
    if(languages.length===1)return {audioLanguage:languages[0],audioLanguageSource:'single-audio-language'};
    return {audioLanguage:null,audioLanguageSource:'unknown'};
  }
  function readPlayer() {
    const id=new URL(location.href).searchParams.get('v');
    if(location.pathname!=='/watch' || !/^[\w-]{11}$/.test(id||'')) return null;
    const player=document.getElementById('movie_player');
    const flex=document.querySelector('ytd-watch-flexy');
    const candidates=[];
    try { candidates.push(player?.getPlayerResponse?.()); } catch { /* Player may be initializing. */ }
    candidates.push(flex?.playerResponse,flex?.data?.playerResponse,window.ytInitialPlayerResponse,window.ytplayer?.config?.args?.player_response);
    for(const candidate of candidates) {
      const r=parseResponse(candidate);
      if(r?.videoDetails?.videoId!==id) continue;
      const list=r.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
      return {videoId:id,...audioLanguage(r),title:String(r.videoDetails.title || ''),duration:Number(r.videoDetails.lengthSeconds || 0),isLive:Boolean(r.videoDetails.isLive || r.microformat?.playerMicroformatRenderer?.liveBroadcastDetails?.isLiveNow),captionTracks:list.slice(0,100).map(t=>({languageCode:String(t.languageCode||''),name:String(t.name?.simpleText || t.name?.runs?.map(x=>x.text).join('') || ''),kind:String(t.kind||''),vssId:String(t.vssId||''),isAutoTranslated:Boolean(t.isAutoTranslated),baseUrl:String(t.baseUrl||'')}))};
    }
    // Some SPA player versions expose only the already-loaded caption track list.
    try {
      const details=player?.getVideoData?.(),tracks=player?.getOption?.('captions','tracklist');
      if(details?.video_id===id && Array.isArray(tracks) && tracks.some(t=>t.baseUrl)) return {videoId:id,...audioLanguage({videoDetails:details}),title:String(details.title||''),duration:Number(player.getDuration?.()||0),isLive:Boolean(details.isLive),captionTracks:tracks.filter(t=>t.baseUrl).slice(0,100).map(t=>({languageCode:String(t.languageCode||''),name:String(t.displayName || t.name?.simpleText || t.languageCode || ''),kind:String(t.kind||''),vssId:String(t.vssId||''),isAutoTranslated:Boolean(t.isAutoTranslated),baseUrl:String(t.baseUrl)}))};
    } catch { /* Player option may be unavailable before captions initialize. */ }
    return null;
  }
  window.addEventListener('message',async event=>{
    const m=event.data;
    if(event.source!==window || event.origin!==location.origin || m?.channel!==CHANNEL || typeof m.requestId!=='string') return;
    const reply=(data,error)=>window.postMessage({channel:CHANNEL,type:'RESPONSE',requestId:m.requestId,...(error?{error}:{data})},location.origin);
    if(m.type==='REQUEST'){reply(readPlayer());return;}
    if(m.type==='CANCEL_SOURCE'){sourceRequests.get(m.requestId)?.abort();return;}
    if(m.type!=='YOUTUBE_SOURCE')return;
    if(sourceRequests.has(m.requestId)||sourceRequests.size>=4){reply(null,'字幕讀取要求過多，請稍後再試。');return;}
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
    sourceRequests.set(m.requestId,controller);
    try {
      const meta=readPlayer(),track=meta?.captionTracks.find(t=>t.vssId===m.track?.vssId&&t.languageCode===m.track?.languageCode&&t.kind===m.track?.kind&&t.name===m.track?.name&&!t.isAutoTranslated);
      if(meta?.videoId!==m.videoId||!track||!captionKey(track.baseUrl))throw new Error('目前影片或英文字幕軌已變更，請重新取得來源。');
      const key=captionKey(track.baseUrl),guard=()=>{controller.signal.throwIfAborted();if(currentId()!==m.videoId)throw new Error('影片已切換，已停止取得字幕。');};
      const result=()=>({raw:captured.get(key),format:'youtube-player-captions'});
      if(captured.has(key)){guard();reply(result());return;}
      let last='YouTube 回傳空字幕或非字幕資料。';
      for(const fmt of [null,'json3','srv3']){
        guard();const url=new URL(track.baseUrl);if(fmt)url.searchParams.set('fmt',fmt);
        try {
          const r=await nativeFetch.call(window,url.href,{credentials:'include',redirect:'error',signal:controller.signal});
          if(!r.ok)throw new Error(`HTTP ${r.status}`);
          const raw=await r.text();guard();remember(url.href,raw);
          if(captured.has(key)){reply(result());return;}
        }catch(e){guard();last=e.message;}
      }
      // An in-flight native CC request may finish while the direct download fails.
      guard();if(captured.has(key)){reply(result());return;}
      throw new Error(last);
    }catch(e){reply(null,`YouTube 播放器字幕取得失敗：${String(e.message).slice(0,250)}`);}
    finally{clearTimeout(timer);sourceRequests.delete(m.requestId);}
  });
})();
