import {ACTIVE_STATUSES} from '../shared/constants.js';
import {nativeChineseTracks} from './caption-detector.js';
import {subtitleTimeMs} from '../shared/subtitle-timing.js';
export function availableSubtitleSeconds(cache,playheadMs,durationMs=Infinity) {
  if(cache&&!cache.partial)return Math.max(0,(durationMs-playheadMs)/1000);
  if(!cache?.sourceCues?.length)return 0;
  const translated=(cache.translatedCues||[]).slice().sort((a,b)=>a.startMs-b.startMs);let index=0;
  for(const source of cache.sourceCues){if(source.endMs<=playheadMs)continue;let cursor=Math.max(playheadMs,source.startMs);
    while(index<translated.length&&translated[index].endMs<=cursor)index++;
    for(let n=index;n<translated.length&&cursor<source.endMs;n++){const c=translated[n];if(c.startMs>cursor+50)break;cursor=Math.max(cursor,c.endMs);}
    if(cursor<source.endMs)return Math.max(0,(cursor-playheadMs)/1000);
  }
  return Math.max(0,(durationMs-playheadMs)/1000);
}
export class SubtitleBufferController {
  constructor(video,readState,notify=()=>{},interactionTarget=null) {
    this.read=readState;this.notify=notify;this.held=false;this.pending=false;this.resumeFailures=0;this.resumeError=null;this.lastResumeAt=0;this.destroyed=false;this.intentSequence=0;
    // Native SDKs can emit extra pause events. Only explicit user pause intent
    // relinquishes an owned buffer pause; an unowned pause never gets resumed.
    this.pause=()=>{};
    this.play=()=>{this.held=false;if(!this.pending){this.resumeError=null;this.resumeFailures=0;}this.check();};
    this.timeupdate=()=>this.check();
    this.userIntent=event=>{
      if(!event.isTrusted)return;
      const target=event.target;if(target?.closest?.('#ytgpt-control,input,textarea,select,[contenteditable="true"]'))return;
      const button=target?.closest?.('button,[role="button"]'),label=button?.getAttribute?.('aria-label')||button?.getAttribute?.('title')||button?.textContent||'';
      const key=event.type==='keydown'&&!event.altKey&&!event.ctrlKey&&!event.metaKey&&[' ','Spacebar','k','K'].includes(event.key);
      if(key || /^(?:pause|暫停|暂停)(?:\b|\s|\(|$)/i.test(label.trim()) || target===this.video&&!this.video.paused){this.intentSequence++;this.held=false;this.resumeError=null;this.notify();}
    };
    this.replaceVideo(video,interactionTarget);this.timer=setInterval(()=>this.check(),500);
  }
  detach(){this.video?.removeEventListener('pause',this.pause);this.video?.removeEventListener('play',this.play);this.video?.removeEventListener('timeupdate',this.timeupdate);for(const type of ['pointerdown','click','keydown'])this.interactionTarget?.removeEventListener(type,this.userIntent,true);}
  replaceVideo(video,interactionTarget=null){this.detach();this.video=video;this.pending=false;this.resumeFailures=0;this.resumeError=null;this.lastResumeAt=0;this.interactionTarget=interactionTarget||video.parentElement||video;video.addEventListener('pause',this.pause);video.addEventListener('play',this.play);video.addEventListener('timeupdate',this.timeupdate);for(const type of ['pointerdown','click','keydown'])this.interactionTarget.addEventListener(type,this.userIntent,true);}
  resume(){
    if(this.pending||this.resumeFailures>=3||Date.now()-this.lastResumeAt<1000)return;
    const video=this.video,intent=this.intentSequence;this.pending=true;this.lastResumeAt=Date.now();
    const failed=error=>{if(this.destroyed||video!==this.video)return;this.pending=false;if(intent!==this.intentSequence)return;this.held=true;this.resumeFailures++;this.resumeError=error?.name==='NotAllowedError'?'瀏覽器未允許自動續播，請按播放器的播放鍵。':this.resumeFailures>=3?'播放器未能自動續播，請按播放鍵繼續。':null;if(error?.name==='NotAllowedError')this.resumeFailures=3;this.notify();};
    try {Promise.resolve(video.play()).then(()=>{if(this.destroyed||video!==this.video)return;this.pending=false;if(!video.paused){this.held=false;this.resumeFailures=0;this.resumeError=null;}else failed(new Error('Playback stayed paused'));this.notify();},failed);}catch(error){failed(error);}
  }
  check(){
    if(this.destroyed||this.video.isConnected===false||this.video.readyState===0||this.video.getBoundingClientRect?.().width===0)return;
    const s=this.read(),busy=s.starting||ACTIVE_STATUSES.includes(s.job?.status),enabled=s.settings.pauseForSubtitles&&s.pref?.enabled!==false&&s.pref?.mode!=='en'&&!s.meta?.isLive&&!nativeChineseTracks(s.meta?.captionTracks).length;
    const seconds=availableSubtitleSeconds(s.cache,subtitleTimeMs(this.video.currentTime,s.pref?.subtitleOffsetMs),(s.meta?.duration||this.video.duration)*1000),threshold=(this.held?8:2)*(this.video.playbackRate||1),needs=enabled&&busy&&seconds<threshold;
    if(needs&&!this.video.paused){this.held=true;this.resumeFailures=0;this.resumeError=null;this.lastResumeAt=0;this.video.pause();this.notify();}
    else if(this.held&&!needs){if(s.error||s.job?.status==='error'||this.video.ended){this.held=false;this.resumeError=null;this.notify();}else if(this.video.paused)this.resume();else{this.held=false;this.notify();}}
  }
  destroy(){this.destroyed=true;clearInterval(this.timer);this.detach();this.held=false;}
}
