import {fetchCaptionSource} from './caption-fetcher.js';
import {fetchTranscriptSource} from './transcript-source.js';
import {parseCaptions} from './caption-parser.js';

function delay(ms,signal) {
  return new Promise((resolve,reject)=>{
    const abort=()=>{clearTimeout(timer);reject(signal.reason);};
    const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},ms);
    signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();
  });
}

// Native captions and the download are independent. The first valid source wins.
export async function fetchVideoCaptionSource(track,meta,signal,{player,download=fetchCaptionSource,transcript=fetchTranscriptSource,transcriptDelayMs=750,playerTimeoutMs=15000,downloadTimeoutMs=10000,transcriptTimeoutMs=40000}={}) {
  signal?.throwIfAborted();
  return new Promise((resolve,reject)=>{
    let settled=false,failed=0;const controllers=[],timers=[],errors={},retryable={};
    const cleanup=()=>{signal?.removeEventListener('abort',abort);timers.forEach(clearTimeout);controllers.forEach(c=>c.abort());};
    const finish=(value,error)=>{if(settled)return;settled=true;cleanup();error?reject(error):resolve(value);};
    const abort=()=>finish(null,signal.reason||new DOMException('Aborted','AbortError'));
    signal?.addEventListener('abort',abort,{once:true});
    const sources=player?['player','download','transcript']:['transcript','download'];
    for(const type of sources){
      const controller=new AbortController();controllers.push(controller);
      timers.push(setTimeout(()=>controller.abort(new DOMException('Timeout','TimeoutError')),type==='player'?playerTimeoutMs:type==='download'?downloadTimeoutMs:transcriptTimeoutMs));
      Promise.resolve().then(async()=>{if(settled)return;if(type==='transcript'&&player)await delay(transcriptDelayMs,controller.signal);if(settled)return;return type==='player'?player(track,meta,controller.signal):type==='download'?download(track,meta.videoId,controller.signal):transcript(track,meta,controller.signal);}).then(value=>{if(!settled){if(!value?.raw)throw new Error('字幕來源沒有文字。');if(type==='player')parseCaptions(value.raw,meta.duration);finish(value);}}).catch(e=>{
        if(settled)return;if(signal?.aborted||e.code==='VIDEO_CHANGED'){finish(null,e);return;}
        errors[type]=controller.signal.aborted?'取得逾時':e.message;retryable[type]=e.code==='TRANSCRIPT_NOT_READY'||controller.signal.aborted;
        if(++failed===sources.length){const error=new Error(`取得英文字幕失敗。${player?`播放器原文：${errors.player}；`:''}原生轉錄稿：${errors.transcript}；字幕下載：${errors.download}`);if(retryable.transcript)error.code='CAPTION_NOT_READY';finish(null,error);}
      });
    }
  });
}
