export function createCueIndex(cues) {
  const maxEnds=[]; let max=0;
  for (const c of cues) { max=Math.max(max,c.endMs); maxEnds.push(max); }
  return {cues,maxEnds};
}
export function activeCues(index,timeMs) {
  const {cues,maxEnds}=index; let lo=0,hi=cues.length;
  while(lo<hi) { const mid=(lo+hi)>>>1; if(cues[mid].startMs<=timeMs) lo=mid+1; else hi=mid; }
  const result=[];
  for(let i=lo-1;i>=0 && maxEnds[i]>timeMs;i--) if(cues[i].startMs<=timeMs && timeMs<cues[i].endMs) result.push(cues[i]);
  return result.reverse();
}
import {subtitleTimeMs} from '../shared/subtitle-timing.js';
export class SubtitleSync {
  constructor(video,cues,render,isBlocked=()=>false,readOffset=()=>0) { this.video=video;this.index=createCueIndex(cues);this.render=render;this.isBlocked=isBlocked;this.readOffset=readOffset;this.frame=0;this.key=null;this.tick=this.tick.bind(this);this.update=this.update.bind(this);this.events=['play','pause','seeked','seeking','ratechange','timeupdate','ended','loadedmetadata'];this.events.forEach(e=>video.addEventListener(e,this.update));this.update(); }
  update() {
    const cues=this.isBlocked()?[]:activeCues(this.index,subtitleTimeMs(this.video.currentTime,this.readOffset()));
    const key=cues.map(c=>c.id).join(','); if(key!==this.key){this.key=key;this.render(cues);}
    if(!this.video.paused && !this.frame) this.frame=requestAnimationFrame(this.tick);
  }
  tick() {this.frame=0;this.update();}
  destroy() {cancelAnimationFrame(this.frame);this.events.forEach(e=>this.video.removeEventListener(e,this.update));this.render([]);}
}
