import { currentVideoId as youtubeId,findVideoElement as youtubeVideo,findPlayer as youtubePlayer,watchNavigation as watchYoutube } from './youtube-detector.js';
import { platformFromUrl,primeTitleId } from '../shared/platforms.js';
export const isPrime=()=>platformFromUrl(location.href)==='primevideo';
export function findVideoElement() {
  if(!isPrime())return youtubeVideo();
  return Array.from(document.querySelectorAll('[id^="dv-web-player"] video, .atvwebplayersdk-player-container video')).filter(v=>Number.isFinite(v.duration)&&v.duration>0&&v.getBoundingClientRect().width>0).sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height)[0] || null;
}
export function currentVideoId() {
  if(!isPrime())return youtubeId();
  if(!findVideoElement()&&!document.querySelector('[id^="dv-web-player"], .atvwebplayersdk-player-container'))return null;
  return document.documentElement.getAttribute('data-ytgpt-prime-video-id') || (primeTitleId(location.href)?`prime:${primeTitleId(location.href)}`:null);
}
export function findPlayer(video=findVideoElement()) {return isPrime()?video?.closest('.atvwebplayersdk-player-container, [id^="dv-web-player"]') || null:youtubePlayer(video);}
export function watchNavigation(callback) {
  if(!isPrime())return watchYoutube(callback);
  let previous;const check=()=>{const id=currentVideoId();if(id!==previous){previous=id;callback(id);}else if(id)callback(id);};
  const timer=setInterval(check,1500);window.addEventListener('popstate',check);check();
  return ()=>{clearInterval(timer);window.removeEventListener('popstate',check);};
}
