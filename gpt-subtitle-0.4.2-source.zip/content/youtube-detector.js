import { videoIdFromUrl } from '../shared/utils.js';
export const currentVideoId = () => videoIdFromUrl(location.href);
export function findVideoElement() { return document.querySelector('#movie_player video.html5-main-video') || document.querySelector('.html5-video-player video') || document.querySelector('ytd-player video'); }
export function findPlayer(video=findVideoElement()) { return video?.closest('#movie_player, .html5-video-player') || null; }
export function watchNavigation(callback) {
  let last=location.href, scheduled=false;
  const check=()=>{ if(scheduled) return; scheduled=true; queueMicrotask(()=>{scheduled=false; callback(currentVideoId());}); };
  const events=['yt-navigate-finish','yt-page-data-updated','popstate'];
  events.forEach(e=>window.addEventListener(e,check));
  const reset=()=>callback(null);window.addEventListener('yt-navigate-start',reset);
  const timer=setInterval(()=>{if(last!==location.href){last=location.href;check();}},750);
  check();
  return ()=>{clearInterval(timer);events.forEach(e=>window.removeEventListener(e,check));window.removeEventListener('yt-navigate-start',reset);};
}
