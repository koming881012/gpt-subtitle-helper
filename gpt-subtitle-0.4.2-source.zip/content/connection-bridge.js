// Only an extension-initiated, short-lived request may complete this handoff.
(async()=>{
  if(location.origin!=='http://127.0.0.1:8766'||location.pathname!=='/')return;
  const params=new URLSearchParams(location.search),request=params.get('request');
  if(params.get('extension')!==chrome.runtime.id||!request)return;
  const status=document.querySelector('#status');
  try {
    status.textContent='正在連接字幕助手，接著前往 OpenAI 登入…';
    const response=await fetch('/page-code',{method:'POST',headers:{'X-Page-Token':document.querySelector('meta[name="page-token"]').content},signal:AbortSignal.timeout(5000),redirect:'error'});
    if(!response.ok)throw new Error('連線未完成，請回插件重新按登入。');
    const {connectionCode}=await response.json();
    const result=await chrome.runtime.sendMessage({type:'COMPLETE_CONNECTION',request,connectionCode});
    if(!result?.ok)throw new Error(result?.error||'插件未回應，請回插件重新按登入。');
    if(new URL(result.data.url).origin!=='https://auth.openai.com')throw new Error('登入網址不符。');
    location.replace(result.data.url);
  }catch(e){status.textContent=e.message;document.querySelector('#recovery').hidden=false;}
})();
