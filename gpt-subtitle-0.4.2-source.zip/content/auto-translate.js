import {cacheKey} from '../shared/utils.js';
import {translationVersion,ACTIVE_STATUSES} from '../shared/constants.js';
import {nativeChineseTracks} from './caption-detector.js';
export function autoTranslationLanguageNotice(meta) {
  if(!meta||meta.platform==='primevideo'||meta.videoId?.startsWith('prime:'))return '';
  if(/^en(?:-|$)/i.test(meta.audioLanguage||''))return '';
  return meta.audioLanguage?`影片音訊判定為非英文（${meta.audioLanguage}），已略過自動翻譯。需要時可手動開始。`:'無法確認影片音訊是否為英文，已略過自動翻譯。確認字幕適合後，可手動開始。';
}
export class AutoTranslationGate {
  constructor(){this.attempted=new Set();}
  take(state) {
    const {meta,track,cache,job,settings,pref,starting}=state;
    if(!settings?.autoTranslate||!settings.hasConnection||!meta||meta.isLive||autoTranslationLanguageNotice(meta)||nativeChineseTracks(meta.captionTracks).length||!track||cache&&!cache.partial||ACTIVE_STATUSES.includes(job?.status)||starting||pref?.enabled===false)return false;
    const version=translationVersion(meta);
    const key=cacheKey({...meta,promptVersion:version},track,settings);
    if(this.attempted.has(key))return false;
    this.attempted.add(key);return true;
  }
}
