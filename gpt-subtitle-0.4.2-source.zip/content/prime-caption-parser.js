import { cleanText, validateCues } from './caption-parser.js';
export function subtitleTime(value,{frameRate=30,tickRate=1}={}) {
  const text=String(value || '').trim(),clock=/^(\d+):(\d{2}):(\d{2})(?:\.(\d+)|:(\d{2})(?:\.(\d+))?)?$/.exec(text);
  if(clock)return Math.round((Number(clock[1])*3600+Number(clock[2])*60+Number(clock[3])+(clock[4]?Number(`0.${clock[4]}`):clock[5]?(Number(clock[5])+Number(`0.${clock[6] || 0}`))/frameRate:0))*1000);
  const short=/^(\d{1,2}):(\d{2})\.(\d+)$/.exec(text);if(short)return Math.round((Number(short[1])*60+Number(short[2])+Number(`0.${short[3]}`))*1000);
  const offset=/^(\d+(?:\.\d+)?)(h|m|s|ms|f|t)$/.exec(text);if(offset)return Math.round(Number(offset[1])*({h:3600000,m:60000,s:1000,ms:1,f:1000/frameRate,t:1000/tickRate}[offset[2]]));
  throw new Error(`Prime Video 字幕時間格式不受支援：${text.slice(0,40)}`);
}
function textContent(value) {return cleanText(value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<br\b[^>]*\/?\s*>/gi,'\n').replace(/<[^>]+>/g,''));}
export function parsePrimeCaptions(raw,duration=0) {
  const text=String(raw).replace(/^\uFEFF/,'').trim();if(text.length>10000000||/<!DOCTYPE|<!ENTITY/i.test(text))throw new Error('Prime Video 字幕資料不受支援。');
  const cues=[],push=(startMs,endMs,body)=>{const value=textContent(body);if(value)cues.push({startMs,endMs,durationMs:endMs-startMs,text:value});};
  if(/^WEBVTT(?:\s|$)/.test(text)) {
    for(const block of text.split(/\n\s*\n/)){const lines=block.split(/\r?\n/),i=lines.findIndex(l=>l.includes('-->'));if(i<0)continue;
      const match=/^\s*(\S+)\s+-->\s+(\S+)/.exec(lines[i]);if(match)push(subtitleTime(match[1]),subtitleTime(match[2]),lines.slice(i+1).join('\n'));}
  } else if(/<(?:\w+:)?tt\b/i.test(text)) {
    const attributes=value=>Object.fromEntries(Array.from(value.matchAll(/([\w:.-]+)\s*=\s*["']([^"']*)["']/g),m=>[m[1].split(':').pop(),m[2]]));
    const root=attributes(text.match(/<(?:\w+:)?tt\b([^>]*)>/i)?.[1] || ''),multiplier=(root.frameRateMultiplier || '1 1').split(/\s+/).map(Number);
    const rates={frameRate:Number(root.frameRate || 30)*multiplier[0]/multiplier[1],tickRate:Number(root.tickRate || 1)};
    for(const p of text.matchAll(/<(?:\w+:)?p\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?p\s*>/gi)) {
      const a=attributes(p[1]);if(!a.begin)throw new Error('Prime Video 字幕缺少片段起始時間。');
      const start=subtitleTime(a.begin,rates),end=a.end?subtitleTime(a.end,rates):a.dur?start+subtitleTime(a.dur,rates):NaN;push(start,end,p[2]);
    }
  } else throw new Error('Prime Video 回傳非 TTML／WebVTT 字幕。');
  cues.sort((a,b)=>a.startMs-b.startMs);validateCues(cues,duration);
  return cues.map((c,id)=>({...c,id}));
}
export function primeCaptionSource(raw,duration) {
  const cues=parsePrimeCaptions(raw,duration);
  return {raw:JSON.stringify({events:cues.map(c=>({tStartMs:c.startMs,dDurationMs:c.durationMs,segs:[{utf8:c.text}]}))}),format:'primevideo-timed-captions',warnings:[]};
}
