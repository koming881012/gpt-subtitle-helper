import { DEFAULT_STYLE } from '../shared/constants.js';
export function subtitleLines(cues,mode) {
  const en=cues.map(c=>c.en ?? c.text).join('\n'), zh=cues.map(c=>c.zh || '').join('\n');
  const line=(lang,text)=>({lang,text});
  if(mode==='zh') return {top:[],bottom:[line('zh',zh)]};
  if(mode==='en') return {top:[],bottom:[line('en',en)]};
  if(mode==='split-en') return {top:[line('en',en)],bottom:[line('zh',zh)]};
  if(mode==='split-zh') return {top:[line('zh',zh)],bottom:[line('en',en)]};
  return {top:[],bottom:mode==='both-zh'?[line('zh',zh),line('en',en)]:[line('en',en),line('zh',zh)]};
}
export class SubtitleRenderer {
  constructor(player,style=DEFAULT_STYLE,mode='zh') {
    this.player=player;this.style=style;this.mode=mode;this.cues=[];this.enabled=false;
    this.root=document.createElement('div');this.root.id='ytgpt-subtitle-overlay';this.root.style.cssText='position:absolute;inset:0;pointer-events:none;z-index:60;overflow:hidden';
    this.top=document.createElement('div');this.bottom=document.createElement('div');
    for(const box of [this.top,this.bottom]) {box.className='ytgpt-subtitle-box';box.style.cssText='position:absolute;left:50%;transform:translateX(-50%);text-align:center;white-space:pre-line;overflow-wrap:anywhere;pointer-events:none';this.root.append(box);}
    player.append(this.root);this.applyStyle();
  }
  setEnabled(value) {this.enabled=value;this.root.hidden=!value;this.player.classList.toggle('ytgpt-enabled',value);}
  configure(style,mode) {const changed=JSON.stringify(this.style)!==JSON.stringify(style)||this.mode!==mode;this.style=style;this.mode=mode;if(changed){this.renderKey=null;this.applyStyle();this.render(this.cues);}}
  applyStyle() {const s=this.style;for(const box of [this.top,this.bottom]) {box.style.width=`${s.width}%`;box.style.fontFamily=s.font;box.style.lineHeight=String(s.lineHeight);}this.top.style.top=`${s.top}%`;this.bottom.style.bottom=`${s.bottom}%`;}
  render(cues) {
    this.cues=cues;const key=JSON.stringify(cues.map(c=>[c.id,c.en,c.zh,c.text]));if(key===this.renderKey)return;this.renderKey=key;const lines=subtitleLines(cues,this.mode),s=this.style;
    for(const [box,list] of [[this.top,lines.top],[this.bottom,lines.bottom]]) {
      box.replaceChildren();
      for(const {lang,text} of list) {
        if(!text) continue;
        const line=document.createElement('div');line.className=`ytgpt-subtitle-${lang}`;line.textContent=text;
        line.style.cssText=`font-size:${lang==='zh'?s.zhSize:s.enSize}px;font-weight:${lang==='zh'?s.zhWeight:s.enWeight};color:${lang==='zh'?s.zhColor:s.enColor};`;
        line.style.textShadow=s.outline?`${s.outline}px 0 1px #000, -${s.outline}px 0 1px #000, 0 ${s.outline}px 1px #000, 0 -${s.outline}px 1px #000, 1px 1px 2px #000`:'none';
        line.style.background=s.background?`rgba(0,0,0,${s.opacity/100})`:'transparent';line.style.borderRadius='4px';line.style.padding=s.background?'2px 6px':'0';box.append(line);
      }
    }
  }
  destroy() {this.player.classList.remove('ytgpt-enabled');this.root.remove();}
}
