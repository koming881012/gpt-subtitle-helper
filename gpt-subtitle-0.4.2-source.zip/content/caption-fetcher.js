import { parseCaptions } from './caption-parser.js';
export function validateCaptionUrl(value, videoId) {
  const u=new URL(value);
  if (u.origin!=='https://www.youtube.com' || u.pathname!=='/api/timedtext' || u.searchParams.get('v')!==videoId || !/^en(?:-|$)/i.test(u.searchParams.get('lang') || '') || u.searchParams.has('tlang')) throw new Error('字幕來源網址不符合目前英文影片。');
  return u;
}
export async function fetchCaptionSource(track,videoId,signal,fetchImpl=fetch) {
  const base=validateCaptionUrl(track.baseUrl,videoId);
  let last='';
  // Preserve the platform's signed URL before trying alternate formats.
  for (const fmt of [null,'json3','srv3']) {
    const url=new URL(base); if (fmt) url.searchParams.set('fmt',fmt);
    try {
      const r=await fetchImpl(url.href,{credentials:'include',signal,redirect:'error'});
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const raw=await r.text();
      if(raw.length>10000000)throw new Error('字幕來源過大，未送出翻譯。');
      if (!raw.trim() || (!raw.trim().startsWith('{') && !/<(?:transcript|timedtext)\b/.test(raw))) throw new Error('YouTube 回傳空字幕或非字幕資料。');
      parseCaptions(raw);
      return {raw,format:fmt || 'original'};
    } catch(e) { if(signal?.aborted) throw e; last=e.message; }
  }
  throw new Error(`字幕取得失敗：${last}`);
}
