import { mkdir,writeFile } from 'node:fs/promises';
import { deflateSync } from 'node:zlib';
function crc32(bytes){let crc=0xffffffff;for(const byte of bytes){crc^=byte;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function chunk(type,data){const label=Buffer.from(type),length=Buffer.alloc(4),crc=Buffer.alloc(4);length.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([label,data])));return Buffer.concat([length,label,data,crc]);}
await mkdir('icons',{recursive:true});
for(const size of [16,32,48,128]) {
  const header=Buffer.alloc(13);header.writeUInt32BE(size);header.writeUInt32BE(size,4);header[8]=8;header[9]=6;
  const pixels=Buffer.alloc(size*(size*4+1));
  for(let y=0;y<size;y++)for(let x=0;x<size;x++) {const p=y*(size*4+1)+1+x*4;const border=x<size*.08||x>size*.92||y<size*.08||y>size*.92;const bars=(y>size*.57&&y<size*.66&&x>size*.2&&x<size*.8)||(y>size*.73&&y<size*.8&&x>size*.2&&x<size*.65);const triangle=x>size*.38&&x<size*.68&&Math.abs(y-size*.34)<(x-size*.38)*.7;const white=bars||triangle;pixels[p]=white?245:border?20:45;pixels[p+1]=white?245:border?20:88;pixels[p+2]=white?245:border?20:140;pixels[p+3]=255;}
  await writeFile(`icons/icon${size}.png`,Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(pixels)),chunk('IEND',Buffer.alloc(0))]));
}
await mkdir('tests/fixtures',{recursive:true});
const samples=8000*20,wav=Buffer.alloc(44+samples*2);wav.write('RIFF');wav.writeUInt32LE(wav.length-8,4);wav.write('WAVEfmt ',8);wav.writeUInt32LE(16,16);wav.writeUInt16LE(1,20);wav.writeUInt16LE(1,22);wav.writeUInt32LE(8000,24);wav.writeUInt32LE(16000,28);wav.writeUInt16LE(2,32);wav.writeUInt16LE(16,34);wav.write('data',36);wav.writeUInt32LE(samples*2,40);await writeFile('tests/fixtures/clock.wav',wav);
console.log('Generated packaged icons and local silent playback fixture.');
