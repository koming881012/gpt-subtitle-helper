import { cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const projectRoot = fileURLToPath(new URL('../', import.meta.url));
export const publicFiles = ['.gitignore','LICENSE','PRIVACY.md','PUBLIC_README.md','SUPPORT.md','CONTRIBUTING.md','FREE_ACCOUNT_TEST.md','CHROME_WEB_STORE.md','manifest.json','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','啟動Plus連線.cmd'];
export const publicDirectories = ['background','companion','content','export','icons','offscreen','options','popup','shared','translation','scripts','tests','.github'];

export async function preparePublicSource() {
  const {version} = JSON.parse(await readFile(path.join(projectRoot,'package.json'),'utf8'));
  const destination = path.join(projectRoot,'release',version,'public-source');
  await mkdir(destination,{recursive:true});
  for (const name of [...publicFiles,...publicDirectories]) await cp(path.join(projectRoot,name),path.join(destination,name),{recursive:true});
  await cp(path.join(projectRoot,'PUBLIC_README.md'),path.join(destination,'README.md'));
  await mkdir(path.join(destination,'website'),{recursive:true});
  for (const name of ['build.mjs','preview.mjs','check.mjs','.gitignore']) await cp(path.join(projectRoot,'website',name),path.join(destination,'website',name));
  const files=[];
  async function visit(dir) {
    for(const item of await readdir(dir,{withFileTypes:true})) {
      const absolute=path.join(dir,item.name);
      if(item.isDirectory()) await visit(absolute);
      else files.push(path.relative(destination,absolute).replaceAll('\\','/'));
    }
  }
  await visit(destination);
  const forbidden=files.filter(name=>/credentials|\.dpapi$|\.log$|(^|\/)\.env|(^|\/)(node_modules|\.git|test-results|release)\//i.test(name)||/完整開發報告|TEST_REPORT/.test(name));
  if(forbidden.length) throw new Error('公開原始碼出現不應發行的檔案：'+forbidden.join(', '));
  await writeFile(path.join(projectRoot,'release',version,'public-source-files.json'),JSON.stringify(files.sort(),null,2)+'\n');
  return {directory:destination,files:files.sort(),version};
}

if(process.argv[1]===fileURLToPath(import.meta.url)) preparePublicSource().then(result=>console.log(JSON.stringify({directory:result.directory,count:result.files.length,version:result.version}))).catch(error=>{console.error(error.message);process.exitCode=1;});
