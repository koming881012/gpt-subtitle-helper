$ErrorActionPreference = 'Stop'
$taskPackage = $PSScriptRoot
$taskVersion = (Get-Content -LiteralPath (Join-Path $taskPackage 'package.json') -Raw | ConvertFrom-Json).version
if ($taskVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid package version.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'YouTubeGPTSubtitle'))
$taskInstall = [IO.Path]::GetFullPath((Join-Path $taskRoot ('app\' + $taskVersion)))
if (-not $taskInstall.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid install path.' }
foreach ($taskRequired in @('runtime\node.exe', 'runtime\NODE-LICENSE.txt', 'companion\launch.js', 'package.json')) {
    if (-not (Test-Path -LiteralPath (Join-Path $taskPackage $taskRequired) -PathType Leaf)) { throw ('Missing package file: ' + $taskRequired) }
}
# Same-version installs are already in use; avoid overwriting an executing runtime.
if (-not (Test-Path -LiteralPath (Join-Path $taskInstall '.installation-complete'))) {
    New-Item -ItemType Directory -Path $taskInstall -Force | Out-Null
    foreach ($taskItem in @('runtime', 'companion', 'package.json', 'LICENSE', 'PRIVACY.md')) {
        Copy-Item -LiteralPath (Join-Path $taskPackage $taskItem) -Destination $taskInstall -Recurse -Force
    }
    Set-Content -LiteralPath (Join-Path $taskInstall '.installation-complete') -Value $taskVersion -Encoding ascii
}
& (Join-Path $taskInstall 'runtime\node.exe') (Join-Path $taskInstall 'companion\launch.js')
if ($LASTEXITCODE -ne 0) { throw 'The connection helper could not start.' }
Write-Host 'Installed. Return to the Chrome extension and click Continue with ChatGPT.'
Write-Host ('Location: ' + $taskInstall)
Write-Host 'If upgrading an already-running older helper, sign out of Windows and sign in again first.'
