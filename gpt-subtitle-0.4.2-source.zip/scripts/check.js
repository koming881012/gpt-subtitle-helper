import { readdir,readFile,stat } from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import {buildContent} from './build-content.js';
await buildContent({check:true});
async function files(dir='.') {const result=[];for(const e of await readdir(dir,{withFileTypes:true})){if(e.name.startsWith('.')||['node_modules','test-results','release','website'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())result.push(...await files(p));else result.push(p);}return result;}
const all=await files(),manifest=JSON.parse(await readFile('manifest.json','utf8'));let scripts=0,imports=0;
assert.equal(manifest.manifest_version,3);assert.equal(manifest.version,JSON.parse(await readFile('package.json','utf8')).version);assert(!manifest.host_permissions.includes('<all_urls>'));
const declared=[manifest.background.service_worker,manifest.action.default_popup,manifest.options_page,...Object.values(manifest.icons),...Object.values(manifest.action.default_icon),...manifest.content_scripts.flatMap(x=>[...x.js,...(x.css||[])])];
for(const file of declared)assert((await stat(file)).isFile(),`Manifest 缺少 ${file}`);
for(const file of all.filter(f=>f.endsWith('.js'))) {
  const r=spawnSync(process.execPath,['--check',file],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);scripts++;
  const source=await readFile(file,'utf8');
  for(const m of source.matchAll(/(?:from\s*|import\s*\()(['"])(\.\.?\/[^'"]+)\1/g)){assert((await stat(path.resolve(path.dirname(file),m[2].split(/[?#]/)[0]))).isFile(),`Import 缺少 ${m[2]} in ${file}`);imports++;}
  if(!file.startsWith('scripts')&&!file.startsWith('tests')) {
    assert(!/\beval\s*\(|new\s+Function\s*\(/.test(source),`違反 CSP: ${file}`);
    assert(!/\bTODO\b|\bFIXME\b/.test(source),`未完成項目: ${file}`);
    assert(!/sk-[A-Za-z0-9_-]{12,}/.test(source),`疑似寫死密鑰: ${file}`);
  }
}
for(const file of all.filter(f=>f.endsWith('.html'))) {
  const source=await readFile(file,'utf8');assert(!/\bon\w+\s*=/i.test(source),`Inline handler: ${file}`);
  for(const m of source.matchAll(/<(?:script|link)\b[^>]*(?:src|href)="([^"]+)"/g)){assert(!/^https?:/.test(m[1]),`Remote script/style: ${file}`);assert((await stat(path.resolve(path.dirname(file),m[1]))).isFile());}
  for(const m of source.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g))assert(!m[2].trim(),`Inline JS: ${file}`);
}
const messageSource=await readFile('shared/messages.js','utf8');const {MSG}=await import('../shared/messages.js');
for(const file of all.filter(f=>f.endsWith('.js')&&!f.startsWith('scripts')))for(const m of (await readFile(file,'utf8')).matchAll(/\bMSG\.([A-Z_]+)/g))assert(Object.hasOwn(MSG,m[1]),`Unknown message ${m[1]} in ${file}`);
assert(messageSource.includes('OFFSCREEN_RUN'));
console.log(`PASS: manifest、${scripts} 個 JS 語法、${imports} 個 import、HTML 資源、訊息名稱、CSP、密鑰與未完成標記檢查。`);
