import {build} from 'esbuild';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
export async function buildContent({check=false}={}) {
  const result=await build({absWorkingDir:root,entryPoints:['content/content-script.js'],outfile:'content/content-bundle.js',bundle:true,format:'iife',platform:'browser',target:'chrome116',charset:'utf8',legalComments:'none',write:false});
  const file=new URL('../content/content-bundle.js',import.meta.url),output=result.outputFiles[0].text;
  if(check){if(await readFile(file,'utf8')!==output)throw new Error('Content bundle 過期，請執行 pnpm build。');}
  else await writeFile(file,output,'utf8');
  return output;
}
if(process.argv[1]===fileURLToPath(import.meta.url))buildContent({check:process.argv.includes('--check')}).then(()=>console.log('PASS: Chrome content bundle 已'+(process.argv.includes('--check')?'核對':'產生')+'。')).catch(e=>{console.error(e.message);process.exitCode=1;});
