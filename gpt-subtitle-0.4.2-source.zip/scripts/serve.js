import { createServer } from 'node:http';
import { readFile,stat } from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve('.'),mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.wav':'audio/wav','.png':'image/png'};
createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,'http://127.0.0.1:8765'),file=path.resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/tests/mock-player.html':url.pathname));
    if(file!==root&&!file.startsWith(root+path.sep))throw new Error('Invalid path');if(!(await stat(file)).isFile())throw new Error('Not file');
    let data=await readFile(file);if(['popup/popup.html','options/options.html'].includes(path.relative(root,file).replaceAll('\\','/'))&&url.searchParams.has('ui-preview'))data=Buffer.from(data.toString('utf8').replace('<script type="module"', '<script type="module" src="../tests/ui-preview-mock.js"></script><script type="module"'));
    const headers={'Content-Type':mime[path.extname(file)]||'text/plain','Cache-Control':'no-store','Accept-Ranges':'bytes'};
    const range=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range || '');
    if(range){const start=Number(range[1]),end=Math.min(range[2]?Number(range[2]):data.length-1,data.length-1);if(start>end){res.writeHead(416,{'Content-Range':`bytes */${data.length}`});res.end();return;}res.writeHead(206,{...headers,'Content-Range':`bytes ${start}-${end}/${data.length}`,'Content-Length':end-start+1});res.end(data.subarray(start,end+1));}
    else {res.writeHead(200,{...headers,'Content-Length':data.length});res.end(data);}
  }catch{res.writeHead(404);res.end('Not found');}
}).listen(8765,'127.0.0.1',()=>console.log('Mock Player: http://127.0.0.1:8765/tests/mock-player.html'));
