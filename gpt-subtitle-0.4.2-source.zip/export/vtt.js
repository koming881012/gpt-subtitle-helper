import { timestamp,cueText } from './srt.js';
export function toVTT(cues,language='zh') {return 'WEBVTT\n\n'+cues.map(c=>`${timestamp(c.startMs,'.')} --> ${timestamp(c.endMs,'.')}\n${cueText(c,language).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}\n`).join('\n');}
