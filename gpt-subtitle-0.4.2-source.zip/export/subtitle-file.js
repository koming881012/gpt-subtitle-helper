import {cleanText,validateCues} from '../content/caption-parser.js';
export function subtitleBackup(cache,meta) {
  return JSON.stringify({format:'ytgpt-subtitles',version:1,videoId:meta.videoId,title:meta.title,duration:meta.duration,translatedCues:cache.translatedCues.map(c=>({startMs:c.startMs,endMs:c.endMs,en:c.en||'',zh:c.zh||''}))},null,2);
}
function timestamp(text) {const m=/^(?:(\d{1,3}):)?(\d{2}):(\d{2})[.,](\d{3})$/.exec(text);if(!m||Number(m[2])>59||Number(m[3])>59)throw new Error('字幕時間戳格式不正確。');return ((Number(m[1]||0)*60+Number(m[2]))*60+Number(m[3]))*1000+Number(m[4]);}
export function parseSubtitleFile(raw,format,meta) {
  if(typeof raw!=='string'||raw.length>10000000)throw new Error('字幕檔超出 10 MB 文字上限。');let cues;
  if(format==='json'){
    const data=JSON.parse(raw.replace(/^\uFEFF/,''));if(data.format!=='ytgpt-subtitles'||data.version!==1||data.videoId!==meta.videoId)throw new Error('備份格式不正確，或備份屬於另一支影片。');cues=data.translatedCues;
  }else if(['srt','vtt'].includes(format)){
    cues=[];const text=raw.replace(/^\uFEFF/,'').replace(/\r/g,'');
    for(const block of text.split(/\n[ \t]*\n/)){
      const lines=block.split('\n');if(/^(WEBVTT|NOTE|STYLE|REGION)(?:\s|$)/.test(lines[0]))continue;
      const at=lines.findIndex(line=>line.includes('-->'));if(at<0)continue;
      const m=/^(\S+)\s+-->\s+(\S+)(?:\s.*)?$/.exec(lines[at]);if(!m)throw new Error('字幕時間軸格式不正確。');
      const zh=cleanText(lines.slice(at+1).join('\n').replace(/<[^>]*>/g,''));if(zh)cues.push({startMs:timestamp(m[1]),endMs:timestamp(m[2]),en:'',zh});
    }
  }else throw new Error('請選擇 SRT、VTT 或助手 JSON 備份。');
  if(!Array.isArray(cues)||!cues.length||cues.length>20000)throw new Error('字幕檔沒有有效字幕，或段數過多。');
  const normalized=cues.map((c,id)=>{if(!c||typeof c.zh!=='string'||!c.zh.trim()||c.zh.length>5000||c.en!==undefined&&typeof c.en!=='string'||String(c.en||'').length>5000||!Number.isFinite(c.startMs)||!Number.isFinite(c.endMs)||c.endMs<=c.startMs)throw new Error('字幕內容或時間軸不正確。');return {id,startMs:c.startMs,endMs:c.endMs,durationMs:c.endMs-c.startMs,en:c.en||'',zh:c.zh.trim()};}).sort((a,b)=>a.startMs-b.startMs);
  validateCues(normalized.map(c=>({...c,text:c.zh})),meta.duration);
  return normalized;
}
