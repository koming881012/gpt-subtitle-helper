import assert from 'node:assert/strict';
import {readFile,readdir,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('./dist/',import.meta.url));
const files=[];
async function visit(directory){for(const entry of await readdir(directory,{withFileTypes:true})){const file=path.join(directory,entry.name);if(entry.isDirectory())await visit(file);else files.push(file);}}
await visit(root);
let links=0;
for(const file of files){
  assert((await stat(file)).size<=25*1024*1024,'靜態資源超出單檔限制');
  if(file.endsWith('.html')){
    const html=await readFile(file,'utf8');
    assert(html.includes('lang="zh-Hant"')&&html.includes('name="viewport"'));
    assert(!/<script\b[^>]*>[\s\S]*?\S[\s\S]*?<\/script>/i.test(html.replace(/<script\b[^>]*><\/script>/gi,'')),'出現 inline script');
    for(const match of html.matchAll(/(?:href|src)="([^"#]+)(?:#[^"]*)?"/g)){
      if(!match[1].startsWith('/'))continue;
      const [pathname,fragment]=match[1].split('#');
      const resolved=path.join(root,pathname==='/'?'index.html':pathname);
      assert((await stat(resolved)).isFile(),`網站缺少資源：${match[1]}`);
      if(fragment)assert((await readFile(resolved,'utf8')).includes(`id="${fragment}"`));
      links++;
    }
  }
  if(file.endsWith('.js'))assert.equal(spawnSync(process.execPath,['--check',file],{encoding:'utf8'}).status,0);
}
const release=JSON.parse(await readFile(path.join(root,'downloads','release.json'),'utf8'));
for(const type of ['chrome','source']){
  const item=release[type],data=await readFile(path.join(root,'downloads',item.filename));
  assert.equal(data.length,item.bytes);
  assert.equal(createHash('sha256').update(data).digest('hex'),item.sha256);
}
const helper=Buffer.concat(await Promise.all(release.helper.parts.map(file=>readFile(path.join(root,file)))));
assert.equal(helper.length,release.helper.bytes);
assert.equal(createHash('sha256').update(helper).digest('hex'),release.helper.sha256);
assert.equal(release.freeChatGPTAccount,'not-tested');
assert.equal(release.chromeWebStore,'not-submitted');
for(const page of ['index.html','support.html','download.html','source.html'])assert((await readFile(path.join(root,page),'utf8')).includes('尚未實測'));
console.log(`PASS: ${files.length} 個網站檔案、${links} 個本機連結、3 個發行檔案的大小與 SHA-256、資格與上架狀態。`);
