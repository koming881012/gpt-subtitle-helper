import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('./dist/',import.meta.url));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.zip':'application/zip','.bin':'application/octet-stream'};
createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,'http://127.0.0.1:8787');
    const file=path.resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
    if(!file.startsWith(root)||!(await stat(file)).isFile()) throw new Error('Not found');
    const data=await readFile(file);
    res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'text/plain; charset=utf-8','Content-Length':data.length,'Cache-Control':'no-store'});
    res.end(data);
  }catch{res.writeHead(404);res.end('Not found');}
}).listen(8787,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:8787/'));
