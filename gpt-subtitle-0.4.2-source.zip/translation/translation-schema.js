const obj=(properties)=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const str={type:'string'}, strings={type:'array',items:str};
export const TRANSLATION_SCHEMA=obj({translations:{type:'array',items:obj({id:{type:'integer'},translation:str})}});
export const CONTEXT_SCHEMA=obj({topic:str,tone:str,speakers:strings,terminology:strings,names:strings,glossary:{type:'array',items:obj({source:str,target:str})},translationRules:strings,summary:str});
export function validateTranslation(result,target,{allowMissing=false}={}) {
  if(!result || Object.keys(result).length!==1 || !Array.isArray(result.translations)) throw new Error('翻譯輸出格式不符。');
  const wanted=new Set(target.map(c=>c.id)), seen=new Set();
  let last=-1;
  for(const t of result.translations) {
    if(Object.keys(t).length!==2 || !Number.isInteger(t.id) || !wanted.has(t.id) || seen.has(t.id) || t.id<=last || typeof t.translation!=='string' || !t.translation.trim() || t.translation.length>5000) throw new Error('翻譯字幕 ID、順序或內容不符。');
    seen.add(t.id);last=t.id;
  }
  const missing=target.filter(c=>!seen.has(c.id));
  if(missing.length && !allowMissing) throw new Error('翻譯輸出缺少字幕。');
  return {translations:result.translations,missing};
}
export function validateContext(c) {
  for(const key of ['topic','tone','summary']) if(typeof c?.[key]!=='string') throw new Error('全文上下文格式不符。');
  for(const key of ['speakers','terminology','names','translationRules']) if(!Array.isArray(c[key]) || c[key].some(x=>typeof x!=='string')) throw new Error('全文上下文格式不符。');
  if(!Array.isArray(c.glossary) || c.glossary.some(g=>typeof g.source!=='string'||typeof g.target!=='string')) throw new Error('詞彙對照格式不符。');
  return c;
}
