import {TRANSLATION_CONFIG,FAST_PROMPT_VERSION} from '../shared/constants.js';
import {parseCaptions,validateCues} from '../content/caption-parser.js';
import {requestJSON} from './openai-client.js';
import {TRANSLATION_INSTRUCTIONS} from './translation-prompt.js';
import {TRANSLATION_SCHEMA,validateTranslation} from './translation-schema.js';
import {getRecord,putRecord} from '../background/storage.js';
import {researchTerminology} from './terminology.js';
import {playableSeconds} from '../shared/subtitle-buffer.js';

export function prepareYoutubeCues(source) {
  const parts=[];
  for(const [index,c] of source.entries()){const words=c.text.trim().split(/\s+/),end=Math.max(c.startMs,Math.min(c.endMs,source[index+1]?.startMs??c.endMs));for(let n=0;n<words.length;n+=24){const startMs=Math.round(c.startMs+(end-c.startMs)*n/words.length),endMs=Math.round(c.startMs+(end-c.startMs)*Math.min(words.length,n+24)/words.length);parts.push({startMs,endMs,text:words.slice(n,n+24).join(' ')});}}
  const grouped=[];for(const c of parts){const last=grouped.at(-1);if(last&&!/[.!?…\]]["'”’]*$/.test(last.text)&&c.startMs-last.endMs<1500&&c.endMs-last.startMs<=8000&&(last.text+' '+c.text).split(/\s+/).length<=28){last.text+=' '+c.text;last.endMs=Math.max(last.endMs,c.endMs);}else grouped.push({...c});}
  return grouped.map((c,id)=>({...c,id,durationMs:c.endMs-c.startMs}));
}
export function fastBatch(cues,results,playheadMs=0,first=false,reserved=new Set()) {
  const missing=c=>!Object.hasOwn(results,c.id)&&!reserved.has(c.id);
  let start=cues.findIndex(c=>c.endMs>Math.max(0,playheadMs-1000)&&missing(c));if(start<0)start=cues.findIndex(missing);if(start<0)return null;
  const target=[];let chars=0;for(let i=start;i<cues.length&&target.length<(first?4:32);i++){const c=cues[i];if(!missing(c))break;if(target.length&&(chars+c.text.length>(first?600:2600)||c.endMs-cues[start].startMs>(first?12000:60000)))break;target.push(c);chars+=c.text.length;}
  return {target,previous:cues.slice(Math.max(0,start-25),start),next:cues.slice(start+target.length,start+target.length+25)};
}
export async function translateFastTimed(job,connectionCode,signal,notify,{request=requestJSON,save=putRecord,read=getRecord,research=researchTerminology}={}) {
  const child=new AbortController(),abort=()=>child.abort(signal.reason);signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();
  let writes=Promise.resolve(),researchTask,researchResult;const pending=new Set();
  const checkpoint=async patch=>{Object.assign(job,patch,{updatedAt:Date.now()});await save('jobs',job);notify({jobId:job.jobId});};
  const publish=partial=>{writes=writes.then(async()=>{
    const cues=job.sourceCues.filter(c=>Object.hasOwn(job.results,c.id)).map(c=>({...c,en:c.text,zh:job.results[c.id]}));
    if(cues.length&&job.firstBatchMs===undefined)job.firstBatchMs=Date.now()-job.translationStartedAt;
    await save('cache',{key:job.cacheKey,platform:job.platform,videoId:job.videoId,title:job.title,sourceTrack:job.sourceTrack,model:job.model,modelsUsed:job.modelsUsed||[job.model],promptVersion:job.promptVersion,translatedAt:Date.now(),partial,sourceCues:job.sourceCues,translatedCues:cues,rawSource:job.rawSource,warnings:job.warnings,glossary:job.glossary||[],terminologyStatus:job.terminologyStatus,revision:(job.cacheRevision||0)+1});
    job.cacheRevision=(job.cacheRevision||0)+1;await checkpoint({translatedCues:cues.length,playableCues:cues.length,bufferedSeconds:playableSeconds(cues,job.playheadMs||0),progress:Math.floor(cues.length/job.totalCues*100),phase:partial?'中文字幕已可播放，正在預先翻譯後續字幕…':'✓ 全部翻譯完成，字幕已開啟'});
  });return writes;};
  try {
    if(!job.sourceCues?.length){if(!job.prefetchedSource)throw new Error('請回到影片頁取得英文字幕再繼續。');job.sourceCues=parseCaptions(job.prefetchedSource.raw,job.duration);job.rawSource=job.prefetchedSource.raw;job.sourceFormat=job.prefetchedSource.format;job.warnings=[...validateCues(job.sourceCues,job.duration).warnings,...(job.prefetchedSource.warnings||[])];delete job.prefetchedSource;if(job.promptVersion===FAST_PROMPT_VERSION)job.sourceCues=prepareYoutubeCues(job.sourceCues);}
    if(JSON.stringify(job.sourceCues).length>TRANSLATION_CONFIG.maxTranscriptChars)throw new Error('字幕全文超出安全上限。');
    job.results||={};job.warnings||=[];job.translationStartedAt||=Date.now();
    await checkpoint({totalCues:job.sourceCues.length,status:'translating',phase:'正在翻譯首批中文字幕…',error:null,terminologyStatus:job.settings.terminologyEnabled?job.terminologyStatus:'disabled'});
    const acceptResearch=()=>{if(!researchResult)return;const r=researchResult;researchResult=null;if(r.error){job.terminologyStatus='failed';job.warnings.push(`GPT-6 術語搜尋未完成：${r.error}`);}else{job.terminologyStatus='ready';job.glossary=r.glossary;}};
    const process=async batch=>{let missing=batch.target,lastError='';
      for(let attempt=0;missing.length&&attempt<3;attempt++){
        child.signal.throwIfAborted();
        try {const input={videoTitle:job.title,glossary:job.glossary||[],previousContext:batch.previous.map(c=>({id:c.id,text:c.text})),previousTranslations:batch.previous.filter(c=>Object.hasOwn(job.results,c.id)).slice(-8).map(c=>({en:c.text,zh:job.results[c.id]})),target:missing.map(c=>({id:c.id,text:c.text})),nextContext:batch.next.map(c=>({id:c.id,text:c.text})),validationFeedback:lastError};
          const output=await request({connectionCode,accountId:job.accountId,settings:job.settings,signal:child.signal,instructions:TRANSLATION_INSTRUCTIONS,input:JSON.stringify(input),schema:TRANSLATION_SCHEMA,name:'timed_subtitles'});
          const validated=validateTranslation(output,missing,{allowMissing:true});child.signal.throwIfAborted();
          for(const t of validated.translations)job.results[t.id]=t.translation.trim();missing=validated.missing;
          if(validated.translations.length)await publish(true);lastError=`只補缺少的 id：${missing.map(c=>c.id).join(',')}`;
        }catch(e){if(child.signal.aborted||e.retryable!==undefined||attempt===2)throw e;lastError=e.message;}
      }
      if(missing.length)throw new Error('部分字幕尚未翻譯，可繼續。');
    };
    const first=fastBatch(job.sourceCues,job.results,job.playheadMs,!Object.keys(job.results).length);if(first)await process(first);
    // Optional expensive research starts after the first playable result.
    if(job.settings.terminologyEnabled&&job.terminologyStatus!=='ready'){job.terminologyStatus='searching';researchTask=Promise.resolve().then(()=>research(job,connectionCode,child.signal,request)).then(glossary=>{researchResult={glossary};},e=>{researchResult={error:String(e.message).slice(0,250)};});}
    const reserved=new Set();let failure;
    const launch=batch=>{batch.target.forEach(c=>reserved.add(c.id));const task=process(batch).catch(e=>{failure||=e;child.abort(e);}).finally(()=>{batch.target.forEach(c=>reserved.delete(c.id));pending.delete(task);});pending.add(task);};
    while(true){child.signal.throwIfAborted();acceptResearch();while(pending.size<2){const batch=fastBatch(job.sourceCues,job.results,job.playheadMs,false,reserved);if(!batch)break;launch(batch);}if(!pending.size)break;await Promise.race(pending);if(failure){await Promise.all(pending);throw failure;}}
    if(researchTask){await researchTask;acceptResearch();}signal.throwIfAborted();await publish(false);
    for(const field of ['sourceCues','rawSource','results','prefetchedSource','glossary'])delete job[field];await checkpoint({status:'completed',progress:100,error:null});
  }catch(e){child.abort(e);await Promise.allSettled([...pending]);await writes.catch(()=>{});const latest=await read('jobs',job.jobId),cancelled=signal.aborted||latest?.status==='cancelled';await checkpoint({status:cancelled?'cancelled':'error',phase:cancelled?'已取消；完成的字幕仍可播放':'翻譯暫停；完成的字幕仍可播放',error:cancelled?null:String(e.message).slice(0,700)});}
  finally {child.abort();signal.removeEventListener('abort',abort);}
  return job;
}
