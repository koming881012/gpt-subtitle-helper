import { TRANSLATION_CONFIG } from '../shared/constants.js';
import { parseCaptions,validateCues } from '../content/caption-parser.js';
import { requestJSON } from './openai-client.js';
import { TRANSLATION_INSTRUCTIONS } from './translation-prompt.js';
import { TRANSLATION_SCHEMA,validateTranslation } from './translation-schema.js';
import { getRecord,putRecord } from '../background/storage.js';
import { researchTerminology } from './terminology.js';
import { playableSeconds } from '../shared/subtitle-buffer.js';
export function timedBatch(cues,results,playheadMs=0,first=false) {
  let start=cues.findIndex(c=>c.endMs>Math.max(0,playheadMs-5000)&&!Object.hasOwn(results,c.id));
  if(start<0)start=cues.findIndex(c=>!Object.hasOwn(results,c.id));if(start<0)return null;
  const target=[];for(let i=start;i<cues.length&&target.length<(first?15:40);i++){if(Object.hasOwn(results,cues[i].id))break;target.push(cues[i]);}
  return {target,previous:cues.slice(Math.max(0,start-25),start),next:cues.slice(start+target.length,start+target.length+25)};
}
export async function translateTimedCaptions(job,connectionCode,signal,notify,{request=requestJSON,save=putRecord,read=getRecord,research=researchTerminology}={}) {
  const checkpoint=async patch=>{Object.assign(job,patch,{updatedAt:Date.now()});await save('jobs',job);notify({jobId:job.jobId});};
  let researchTask,researchResult;
  try {
    if(!job.sourceCues?.length){if(!job.prefetchedSource)throw new Error('請在 Prime Video 影片頁重新取得字幕再繼續。');job.sourceCues=parseCaptions(job.prefetchedSource.raw,job.duration);job.rawSource=job.prefetchedSource.raw;job.sourceFormat=job.prefetchedSource.format;job.warnings=validateCues(job.sourceCues,job.duration).warnings;delete job.prefetchedSource;}
    if(JSON.stringify(job.sourceCues).length>TRANSLATION_CONFIG.maxTranscriptChars)throw new Error('字幕全文超出安全上限。');
    job.results ||= {};await checkpoint({totalCues:job.sourceCues.length,status:'translating',phase:'優先翻譯目前位置，保留 Prime Video 原始字幕時間軸…',error:null});
    if(job.terminologyStatus!=='ready'){job.terminologyStatus='searching';researchTask=Promise.resolve().then(()=>research(job,connectionCode,signal,request)).then(glossary=>{researchResult={glossary};},e=>{researchResult={error:String(e.message).slice(0,250)};});}
    const acceptResearch=()=>{if(!researchResult)return;const result=researchResult;researchResult=null;if(result.error){job.terminologyStatus='failed';job.warnings.push(`GPT-6 術語搜尋未完成：${result.error}`);}else{job.terminologyStatus='ready';job.glossary=result.glossary;}};
    const publish=async partial=>{const cues=job.sourceCues.filter(c=>Object.hasOwn(job.results,c.id)).map(c=>({...c,en:c.text,zh:job.results[c.id]}));
      const bufferedSeconds=playableSeconds(cues,job.playheadMs || 0);
      await save('cache',{key:job.cacheKey,platform:'primevideo',videoId:job.videoId,title:job.title,sourceTrack:job.sourceTrack,model:job.model,promptVersion:job.promptVersion,translatedAt:Date.now(),partial,sourceCues:job.sourceCues,translatedCues:cues,rawSource:job.rawSource,warnings:job.warnings,glossary:job.glossary || [],terminologyStatus:job.terminologyStatus,revision:(job.cacheRevision || 0)+1});
      job.cacheRevision=(job.cacheRevision || 0)+1;await checkpoint({translatedCues:cues.length,playableCues:cues.length,bufferedSeconds,progress:Math.floor(cues.length/job.totalCues*100),phase:partial?`已可顯示 ${cues.length} 段中文字幕，背景繼續翻譯…`:'✓ 全部翻譯完成，字幕已開啟'});
    };
    while(true){signal.throwIfAborted();acceptResearch();const batch=timedBatch(job.sourceCues,job.results,job.playheadMs,!Object.keys(job.results).length);if(!batch)break;
      let missing=batch.target,lastError;
      for(let attempt=0;missing.length&&attempt<3;attempt++){
        const input={videoTitle:job.title,glossary:job.glossary || [],previousContext:batch.previous.map(c=>({id:c.id,text:c.text})),target:missing.map(c=>({id:c.id,text:c.text})),nextContext:batch.next.map(c=>({id:c.id,text:c.text})),validationFeedback:lastError || ''};
        try {const output=await request({connectionCode,accountId:job.accountId,settings:job.settings,signal,instructions:TRANSLATION_INSTRUCTIONS+'\n來源是 Prime Video 成品字幕，保留聲音標記、說話者、跨段語意與原始片段對應；不可將正確原文猜改成其他內容。',input:JSON.stringify(input),schema:TRANSLATION_SCHEMA,name:'primevideo_subtitles'});
          const validated=validateTranslation(output,missing,{allowMissing:true});for(const t of validated.translations)job.results[t.id]=t.translation.trim();missing=validated.missing;
        }catch(e){if(signal.aborted||e.retryable!==undefined||attempt===2)throw e;lastError=e.message;}
      }
      if(missing.length)throw new Error('部分 Prime Video 字幕尚未翻譯，可繼續。');signal.throwIfAborted();await publish(true);
    }
    if(researchTask){await researchTask;acceptResearch();}signal.throwIfAborted();await publish(false);
    for(const field of ['sourceCues','rawSource','results','prefetchedSource','glossary'])delete job[field];
    await checkpoint({status:'completed',progress:100,error:null});
  }catch(e){const latest=await read('jobs',job.jobId),cancelled=signal.aborted||latest?.status==='cancelled';await checkpoint({status:cancelled?'cancelled':'error',phase:cancelled?'已取消；完成的字幕仍可播放':'翻譯暫停；完成的字幕仍可播放',error:cancelled?null:String(e.message).slice(0,700)});}
  return job;
}
