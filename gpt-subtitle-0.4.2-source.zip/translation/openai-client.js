import { TRANSLATION_CONFIG } from '../shared/constants.js';
import { COMPANION_URL } from '../shared/companion.js';
export class APIError extends Error {constructor(message,retryable=false,code=''){super(message);this.retryable=retryable;this.code=code;}}
export function apiError(status,code) {
  if(code==='model_not_found') return new APIError('帳號目前無法使用這個模型，請在插件小視窗選擇可用模型並按「套用模型」。',false,code);
  if(code==='subscription_sharing_usage_limit_exceeded')return new APIError('ChatGPT 方案使用量已達限制。請到 ChatGPT 設定查看用量，稍後可繼續翻譯。',false,code);
  if(code==='subscription_sharing_user_not_eligible')return new APIError('此帳號或工作區目前無法授權 ChatGPT 方案額度。',false,code);
  if(['subscription_sharing_usage_unavailable','subscription_sharing_user_unavailable'].includes(code))return new APIError('暫時無法確認 ChatGPT 方案使用量，稍後可從目前進度繼續。',true,code);
  if(status===401) return new APIError('ChatGPT 登入或本機連線已失效，請到設定重新連線。',false,code);
  if(status===403) return new APIError('ChatGPT 方案授權或存取政策不允許此操作。',false,code);
  if(status===429) return new APIError('ChatGPT 使用量或速率已達限制，稍後可從目前進度繼續。',code!=='insufficient_quota',code);
  if(status>=500) return new APIError('OpenAI 暫時無法服務，稍後可從目前進度繼續。',true);
  return new APIError(`OpenAI 請求失敗（${status}），請檢查模型與 Reasoning 設定。`,false,code);
}
export function extractOutput(response) {
  if(response.status==='incomplete') throw new APIError('OpenAI 輸出未完成，請減少每批字幕數量或稍後繼續。',true);
  if(response.error || response.status==='failed') throw new APIError('OpenAI 回應失敗。',true);
  const parts=[];
  for(const item of response.output || []) for(const c of item.content || []) {
    if(c.type==='refusal') throw new APIError('模型拒絕翻譯此內容，未修改原文。');
    if(c.type==='output_text') parts.push(c.text);
  }
  if(!parts.length) throw new APIError('OpenAI 沒有回傳翻譯文字。',true);
  try{return JSON.parse(parts.join(''));}catch{throw new APIError('OpenAI 回傳無效 JSON。',true);}
}
export function buildRequest(settings,instructions,input,schema,name,{webSearch=false}={}) {
  const body={model:settings.model,reasoning:{effort:settings.reasoningEffort},store:false,stream:true,instructions,input:[{role:'user',content:[{type:'input_text',text:input}]}],text:{format:{type:'json_schema',name,strict:true,schema}}};
  if(webSearch){body.tools=[{type:'web_search',search_context_size:'low'}];body.tool_choice='required';}
  return body;
}
export async function readCompleted(stream) {
  const reader=stream.getReader(),decoder=new TextDecoder(),finishedItems=new Map();let buffer='',completed=null,outputBytes=0;
  function event(block) {
    const data=block.split('\n').filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trimStart()).join('\n');if(!data||data==='[DONE]')return;
    let e;try{e=JSON.parse(data);}catch{throw new APIError('OpenAI 串流格式無效。',true);}
    if(e.type==='response.failed'||e.type==='error')throw apiError(e.status||e.error?.status||e.response?.error?.status||400,e.response?.error?.code||e.error?.code||e.code);
    if(e.type==='response.incomplete')throw new APIError('OpenAI 輸出未完成，已保留進度。',true);
    // ChatGPT 方案串流的 terminal response.output 可為空；文字在已完成的 item 事件中。
    if(e.type==='response.output_item.done') {
      if(!Number.isInteger(e.output_index)||e.output_index<0||e.output_index>1000||!e.item)throw new APIError('OpenAI 串流輸出項目不完整。',true);
      if(!['message','web_search_call'].includes(e.item.type))return;
      if(e.item.status!=='completed')throw new APIError('OpenAI 串流輸出項目不完整。',true);
      outputBytes+=JSON.stringify(e.item).length;if(outputBytes>16*1024*1024)throw new APIError('OpenAI 串流資料過大。');
      finishedItems.set(e.output_index,e.item);
    }
    if(e.type==='response.completed'){if(e.response?.status!=='completed')throw new APIError('OpenAI 終止事件不完整。',true);completed=e.response;}
  }
  try {
    while(true){const {done,value}=await reader.read();buffer+=decoder.decode(value,{stream:!done});buffer=buffer.replace(/\r\n/g,'\n');let end;while((end=buffer.indexOf('\n\n'))>=0){event(buffer.slice(0,end));buffer=buffer.slice(end+2);}if(buffer.length>16*1024*1024)throw new APIError('OpenAI 串流資料過大。');if(done)break;}
    if(buffer.trim())event(buffer);if(!completed)throw new APIError('OpenAI 連線中斷，未收到翻譯完成通知。',true);
    if(!completed.output?.length)completed={...completed,output:[...finishedItems].sort((a,b)=>a[0]-b[0]).map(([,item])=>item)};
    return completed;
  }finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}
function delay(ms,signal) {return new Promise((resolve,reject)=>{if(signal?.aborted)return reject(signal.reason || new DOMException('Aborted','AbortError'));const abort=()=>{clearTimeout(timer);reject(signal.reason || new DOMException('Aborted','AbortError'));};const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},ms);signal?.addEventListener('abort',abort,{once:true});});}
export async function requestJSON({connectionCode,accountId,settings,instructions,input,schema,name,signal,webSearch=false,onResponse=()=>{},onRetry=()=>{},fetchImpl=fetch,config=TRANSLATION_CONFIG}) {
  for(let attempt=0;attempt<=config.maxRetries;attempt++) {
    const controller=new AbortController();const abort=()=>controller.abort(signal.reason);signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
    const timeout=setTimeout(()=>controller.abort(new DOMException('Timeout','TimeoutError')),config.timeoutMs);
    let error;
    try {
      const headers={Authorization:`Bearer ${connectionCode}`,'Content-Type':'application/json'};if(accountId)headers['X-ChatGPT-Account']=accountId;
      const r=await fetchImpl(`${COMPANION_URL}/responses`,{method:'POST',headers,body:JSON.stringify(buildRequest(settings,instructions,input,schema,name,{webSearch})),signal:controller.signal,redirect:'error'});
      if(!r.ok){let body;try{body=await r.json();}catch{}throw apiError(r.status,body?.error?.code);}
      const completed=await readCompleted(r.body);onResponse(completed);return extractOutput(completed);
    } catch(e) {
      if(signal?.aborted) throw new DOMException('Aborted','AbortError');
      error=e instanceof APIError?e:new APIError(e.name==='TimeoutError' || controller.signal.aborted?'ChatGPT 請求逾時，可從目前進度繼續。':'本機程式或網路連線失敗，請確認「啟動Plus連線.cmd」已執行。',true);
    } finally {clearTimeout(timeout);signal?.removeEventListener('abort',abort);}
    if(!error.retryable || attempt===config.maxRetries)throw error;
    onRetry(attempt+1,error.message);
    await delay(2000*2**attempt+Math.floor(Math.random()*600),signal);
  }
}
