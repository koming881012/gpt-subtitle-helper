import {PROMPT_VERSION,TRANSLATION_CONFIG} from '../shared/constants.js';
import {parseCaptions,validateCues} from '../content/caption-parser.js';
import {fetchCaptionSource} from '../content/caption-fetcher.js';
import {getRecord,putRecord} from '../background/storage.js';
import {requestJSON} from './openai-client.js';
import {captionWords,sentenceWindow,validateSentences,sentenceInput,SENTENCE_SCHEMA,SENTENCE_INSTRUCTIONS,playableSeconds} from './sentence-subtitles.js';
import {researchTerminology} from './terminology.js';

export async function translateProgressively(job,connectionCode,signal,notify,{request=requestJSON,fetchSource=fetchCaptionSource,save=putRecord,read=getRecord,research=researchTerminology}={}) {
  const checkpoint=async patch=>{Object.assign(job,patch,{updatedAt:Date.now()});await save('jobs',job);notify({jobId:job.jobId});};
  let researchTask,researchResult,words;
  try {
    if(!job.sourceCues?.length) {
      await checkpoint({status:'fetching',phase:'正在取得英文字幕…',error:null});
      const source=job.prefetchedSource || await fetchSource(job.sourceTrack,job.videoId,signal);
      job.sourceCues=parseCaptions(source.raw,job.duration);job.rawSource=source.raw;job.sourceFormat=source.format;delete job.prefetchedSource;
      job.warnings=[...validateCues(job.sourceCues,job.duration).warnings,...(source.warnings || []),'英文與中文依完整短句重新分段；詞時間依原始字幕區間估算。'];
    }
    if(JSON.stringify(job.sourceCues.map(c=>({id:c.id,text:c.text}))).length>TRANSLATION_CONFIG.maxTranscriptChars)throw new Error('字幕全文超出安全上限，未送出翻譯。');
    words=captionWords(job.sourceCues);job.wordRanges ||= [];job.sentenceCues ||= [];job.termRevisionRanges ||= [];
    job.warnings ||= [];
    job.playheadMs=Number.isFinite(job.playheadMs)?job.playheadMs:0;
    await checkpoint({totalCues:job.sourceCues.length,mode:'progressive',status:'translating',phase:'先翻譯目前播放位置，完成首批就可播放…'});
    if(job.settings.terminologyEnabled!==false&&job.terminologyStatus!=='ready') {
      job.terminologyStatus='searching';
      researchTask=Promise.resolve().then(()=>research(job,connectionCode,signal,request)).then(glossary=>{researchResult={glossary};},e=>{researchResult={error:e.message};});
    }
    const publish=async partial=>{
      const cues=job.sentenceCues.slice().sort((a,b)=>a.startWord-b.startWord);
      const covered=new Uint8Array(words.length);for(const range of job.wordRanges)covered.fill(1,range.start,range.end);
      const counts=new Map();for(const word of words){const entry=counts.get(word.cueId)||{total:0,done:0};entry.total++;if(covered[word.id])entry.done++;counts.set(word.cueId,entry);}
      const translatedCues=[...counts.values()].filter(x=>x.total===x.done).length;
      const bufferedSeconds=playableSeconds(cues,job.playheadMs);
      await save('cache',{key:job.cacheKey,videoId:job.videoId,title:job.title,sourceTrack:job.sourceTrack,model:job.model,promptVersion:PROMPT_VERSION,translatedAt:Date.now(),partial,sourceCues:job.sourceCues,translatedCues:cues,rawSource:job.rawSource,warnings:job.warnings,glossary:job.glossary || [],terminologyStatus:job.terminologyStatus,revision:(job.cacheRevision || 0)+1});
      job.cacheRevision=(job.cacheRevision || 0)+1;
      await checkpoint({translatedCues,bufferedSeconds,playableCues:cues.length,progress:Math.floor(translatedCues/job.totalCues*100),phase:partial?`已可顯示 ${cues.length} 句中文字幕 · 目前位置已準備 ${bufferedSeconds} 秒，背景繼續翻譯…`:'✓ 全部翻譯完成，字幕已開啟'});
    };
    const acceptResearch=async()=>{
      if(!researchResult)return;
      const result=researchResult;researchResult=null;
      if(result.error){job.terminologyStatus='failed';job.warnings.push(`GPT-6 術語搜尋未完成：${String(result.error).slice(0,250)}；目前使用繁中翻譯或音譯。`);}
      else {job.glossary=result.glossary;job.terminologyStatus='ready';job.termRevisionRanges=result.glossary.length?job.wordRanges.map(r=>({...r})):[];}
      await checkpoint({terminologyStatus:job.terminologyStatus});
    };
    while(true) {
      signal.throwIfAborted();await acceptResearch();
      const revision=job.termRevisionRanges[0];
      const window=revision?{...revision,desiredEnd:revision.end,isFinalWindow:true}:sentenceWindow(words,job.wordRanges,job.playheadMs,!job.wordRanges.length);
      if(!window) {
        if(researchTask){await researchTask;researchTask=null;await acceptResearch();if(job.termRevisionRanges.length)continue;}
        break;
      }
      let validated,lastError;
      for(let attempt=0;attempt<3;attempt++) {
        try {
          const input=JSON.parse(sentenceInput(job,words,window));if(lastError)input.validationFeedback=lastError;
          const output=await request({connectionCode,accountId:job.accountId,settings:job.settings,signal,instructions:SENTENCE_INSTRUCTIONS,input:JSON.stringify(input),schema:SENTENCE_SCHEMA,name:'subtitle_sentences',onRetry:(n,message)=>notify({jobId:job.jobId,retry:n,message})});
          validated=validateSentences(output,words,window);break;
        } catch(e){if(signal.aborted||e.retryable!==undefined||attempt===2)throw e;lastError=e.message;}
      }
      signal.throwIfAborted();
      if(revision){job.sentenceCues=job.sentenceCues.filter(c=>c.endWord<=revision.start||c.startWord>=revision.end);job.termRevisionRanges.shift();}
      else job.wordRanges.push({start:window.start,end:validated.end});
      job.sentenceCues.push(...validated.cues);await publish(true);
    }
    signal.throwIfAborted();await publish(false);
    for(const key of ['sourceCues','rawSource','prefetchedSource','sentenceCues','wordRanges','termRevisionRanges','glossary'])delete job[key];
    await checkpoint({status:'completed',phase:'✓ 全部翻譯完成，字幕已開啟',progress:100,error:null});
  } catch(e) {
    const latest=await read('jobs',job.jobId);const cancelled=signal.aborted||latest?.status==='cancelled';
    await checkpoint({status:cancelled?'cancelled':'error',phase:cancelled?'已取消；完成的字幕仍可播放':'翻譯暫停；完成的字幕仍可播放',error:cancelled?null:String(e.message).slice(0,700)});
  }
  // Each research task has its own bounded timeout and handles rejection; no unhandled promise.
  return job;
}
