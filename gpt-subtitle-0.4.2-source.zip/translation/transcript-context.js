import { TRANSLATION_CONFIG } from '../shared/constants.js';
export function transcript(cues) {return cues.map(c=>({id:c.id,text:c.text}));}
export function planBatches(cues,config=TRANSLATION_CONFIG) {
  const full=JSON.stringify(transcript(cues));
  if(full.length>config.maxTranscriptChars) throw new Error('字幕全文超出安全上限，未送出 API；請選擇較短影片。');
  if(cues.length<=config.fullTextCues && full.length<=config.fullTextChars) return {mode:'full',batches:[{start:0,end:cues.length}]};
  const batches=[];let start=0;
  while(start<cues.length) {let end=start,chars=0;while(end<cues.length && end-start<config.chunkSize && (end===start || chars+cues[end].text.length<config.chunkChars)) {chars+=cues[end].text.length;end++;}batches.push({start,end});start=end;}
  return {mode:'context',batches};
}
export function batchInput(job,batch,target=job.sourceCues.slice(batch.start,batch.end)) {
  const cues=job.sourceCues;
  return JSON.stringify({videoTitle:job.title,globalContext:job.context || null,previousContext:transcript(cues.slice(Math.max(0,batch.start-TRANSLATION_CONFIG.contextCues),batch.start)),targetCues:transcript(target),nextContext:transcript(cues.slice(batch.end,batch.end+TRANSLATION_CONFIG.contextCues))});
}
