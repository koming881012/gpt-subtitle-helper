@echo off
set "SUBTITLE_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%SUBTITLE_NODE%" (
  "%SUBTITLE_NODE%" "%~dp0companion\launch.js"
) else (
  node "%~dp0companion\launch.js"
)
if errorlevel 1 (
  echo Startup failed. See the error above. The connection page was not opened.
) else (
  echo Ready. Open http://127.0.0.1:8766 in Chrome.
)
pause
