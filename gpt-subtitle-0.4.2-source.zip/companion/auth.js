import {randomBytes,randomUUID,createHash,createPublicKey,verify} from 'node:crypto';
export const RESOURCE='https://api.openai.com/v1';
const AUTH='https://auth.openai.com',SCOPE='openid profile email offline_access resource.invoke chatgpt.tokens.use.direct';
const random=()=>randomBytes(32).toString('base64url');
export function hasPlan(scopes=[]) {return scopes.includes('chatgpt.tokens.use.direct')&&scopes.includes('resource.invoke');}
export function verifyIdentity(jwt,{keys,clientId,nonce,subject,now=Date.now()/1000}) {
  const parts=jwt?.split('.');if(parts?.length!==3)throw new Error('登入身分格式不正確。');
  const h=JSON.parse(Buffer.from(parts[0],'base64url')),p=JSON.parse(Buffer.from(parts[1],'base64url'));
  if(h.alg!=='RS256')throw new Error('登入簽章算法不符。');
  const jwk=keys.find(k=>k.kid===h.kid&&k.kty==='RSA'&&(!k.use||k.use==='sig')&&(!k.alg||k.alg==='RS256'));
  if(!jwk||!verify('RSA-SHA256',Buffer.from(`${parts[0]}.${parts[1]}`),createPublicKey({key:jwk,format:'jwk'}),Buffer.from(parts[2],'base64url')))throw new Error('登入簽章驗證失敗。');
  if(p.iss!==AUTH||!(Array.isArray(p.aud)?p.aud.includes(clientId):p.aud===clientId)||!Number.isFinite(p.exp)||p.exp<=now||p.nonce!==nonce||typeof p.sub!=='string'||!p.sub||(p.nbf&&p.nbf>now+30)||(subject&&p.sub!==subject))throw new Error('登入身分、有效期限或 nonce 驗證失敗。');
  if(Array.isArray(p.aud)&&p.aud.length>1&&p.azp!==clientId)throw new Error('登入 audience 不符。');
  return p;
}
export class ChatGPTAuth {
  constructor(vault,redirect,fetchImpl=fetch) {this.vault=vault;this.redirect=redirect;this.fetch=fetchImpl;this.pending=null;this.refreshing=null;this.lastError='';}
  async init() {const v=this.vault.value;v.hostId||=`urn:uuid:${randomUUID()}`;v.connectionCode||=random();v.accounts||=[];await this.vault.save();}
  get account() {return this.vault.value.accounts.find(a=>a.id===this.vault.value.active);}
  status() {const a=this.account;return {signedIn:Boolean(a?.access_token),planEnabled:Boolean(a?.access_token&&hasPlan(a.scopes)),account:a?{id:a.id,email:a.email}:null,accounts:this.vault.value.accounts.map(x=>({id:x.id,email:x.email})),pending:Boolean(this.pending),error:this.lastError};}
  start({newAccount=false,enablePlan=false}={}) {
    const a=newAccount?null:this.account,state=random(),nonce=random(),verifier=random();
    this.pending={state,nonce,verifier,account:a?structuredClone(a):null,created:Date.now()};this.lastError='';
    const q=new URLSearchParams({client_id:a?.client_id||'dynamic_agent_client',ext_agent_host_id:this.vault.value.hostId,response_type:'code',redirect_uri:this.redirect,scope:SCOPE,resource:RESOURCE,state,nonce,code_challenge_method:'S256',code_challenge:createHash('sha256').update(verifier).digest('base64url')});
    if(!a)q.set('agent_name_hint','YouTube GPT 中文字幕助手');
    if(a?.id_token)q.set('id_token_hint',a.id_token);
    if(enablePlan)q.set('prompt','consent');
    return `${AUTH}/api/accounts/authorize?${q}`;
  }
  async metadata() {
    const r=await this.fetch(`${AUTH}/.well-known/openid-configuration`,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('無法讀取 OpenAI 登入設定。');const m=await r.json();
    if(m.issuer!==AUTH||new URL(m.jwks_uri).origin!==AUTH||!m.jwks_uri.startsWith('https://'))throw new Error('OpenAI 登入設定來源不符。');return m;
  }
  async token(fields) {
    const r=await this.fetch(`${AUTH}/api/accounts/oauth/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({...fields,resource:RESOURCE}),signal:AbortSignal.timeout(30000),redirect:'error'});
    const b=await r.json();if(!r.ok){const e=new Error('ChatGPT 登入或更新失敗，請重新登入。');e.code=typeof b.error==='string'?b.error:b.error?.code;throw e;}return b;
  }
  async callback(q) {
    const p=this.pending;
    if(!p||q.get('state')!==p.state||Date.now()-p.created>600000)throw new Error('登入 state 不符或已逾時，請從設定重新登入。');
    this.pending=null;
    try {
      if(q.has('error'))throw new Error('登入授權未完成，未使用任何方案額度。');
      const clientId=q.get('client_id')||p.account?.client_id;
      if(!q.get('code')||!clientId||clientId==='dynamic_agent_client'||(p.account&&clientId!==p.account.client_id))throw new Error('登入 client ID 不符。');
      const t=await this.token({grant_type:'authorization_code',client_id:clientId,code:q.get('code'),code_verifier:p.verifier,redirect_uri:this.redirect});
      const m=await this.metadata(),r=await this.fetch(m.jwks_uri,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('無法驗證 OpenAI 登入簽章。');
      const identity=verifyIdentity(t.id_token,{keys:(await r.json()).keys,clientId,nonce:p.nonce,subject:p.account?.subject});
      if(t.token_type?.toLowerCase()!=='bearer'||!t.access_token||!t.refresh_token||!(t.expires_in>0))throw new Error('登入憑證不完整。');
      const a={id:`${clientId}:${identity.sub}`,client_id:clientId,subject:identity.sub,email:String(identity.email||identity.sub),id_token:t.id_token,access_token:t.access_token,refresh_token:t.refresh_token,scopes:String(t.scope||'').split(/\s+/),expiresAt:Date.now()+t.expires_in*1000};
      const v=this.vault.value;v.accounts=v.accounts.filter(x=>x.id!==a.id);v.accounts.push(a);v.active=a.id;await this.vault.save();
      if(!hasPlan(a.scopes))this.lastError='已登入，但未授權 ChatGPT 方案額度。請按「授權方案額度」。';return this.status();
    }catch(e){this.lastError=e.message;throw e;}
  }
  async select(id) {if(!this.vault.value.accounts.some(x=>x.id===id))throw new Error('找不到帳號。');this.vault.value.active=id;await this.vault.save();return this.status();}
  async access() {
    if(this.refreshing)await this.refreshing;
    let a=this.account;if(!a?.access_token||!hasPlan(a.scopes))throw Object.assign(new Error('請先登入 ChatGPT 並授權方案額度。'),{status:401});
    if(a.expiresAt>Date.now()+60000)return a.access_token;
    this.refreshing=(async()=>{
      try {const t=await this.token({grant_type:'refresh_token',client_id:a.client_id,refresh_token:a.refresh_token});if(!t.access_token||!(t.expires_in>0))throw new Error('更新憑證不完整。');Object.assign(a,{access_token:t.access_token,refresh_token:t.refresh_token||a.refresh_token,expiresAt:Date.now()+t.expires_in*1000});if(t.scope!==undefined)a.scopes=String(t.scope).split(/\s+/);await this.vault.save();}
      catch(e){if(['invalid_grant','invalid_refresh_token','token_expired','refresh_token_expired','refresh_token_invalidated','refresh_token_reused'].includes(e.code)){delete a.access_token;delete a.refresh_token;delete a.id_token;await this.vault.save();}throw e;}
    })();
    try {await this.refreshing;}finally{this.refreshing=null;}
    a=this.account;if(!hasPlan(a.scopes))throw Object.assign(new Error('ChatGPT 方案授權已失效，請重新授權。'),{status:401});return a.access_token;
  }
  async logout() {
    if(this.refreshing)await this.refreshing;const a=this.account;this.pending=null;if(!a)return {revoked:true};let revoked=false;
    try {const m=await this.metadata();if(m.revocation_endpoint&&new URL(m.revocation_endpoint).origin===AUTH&&m.revocation_endpoint.startsWith('https://'))for(let n=0;n<3;n++){const r=await this.fetch(m.revocation_endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({token:a.refresh_token||a.access_token,token_type_hint:a.refresh_token?'refresh_token':'access_token',client_id:a.client_id}),signal:AbortSignal.timeout(10000),redirect:'error'});if(r.ok){revoked=true;break;}if(r.status<500)break;await new Promise(resolve=>setTimeout(resolve,300*2**n));}}catch{}
    for(const k of ['access_token','refresh_token','id_token'])delete a[k];await this.vault.save();return {revoked};
  }
}
