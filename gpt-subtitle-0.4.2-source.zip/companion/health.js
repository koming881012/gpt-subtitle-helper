export const HEALTH_URL='http://127.0.0.1:8766/health';
export async function checkHealth(fetchImpl=fetch) {
  try {const r=await fetchImpl(HEALTH_URL,{signal:AbortSignal.timeout(1500),cache:'no-store',redirect:'error'});if(!r.ok)return false;const b=await r.json();return b.app==='youtube-gpt-subtitle-companion'&&b.ready===true;}
  catch{return false;}
}
export async function waitForReady({check=checkHealth,attempts=60,delayMs=200,failed=()=>false}={}) {
  for(let i=0;i<attempts;i++){if(await check())return true;if(failed())return false;await new Promise(resolve=>setTimeout(resolve,delayMs));}return false;
}
