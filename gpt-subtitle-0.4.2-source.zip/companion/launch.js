import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {mkdir,open,readFile} from 'node:fs/promises';
import {checkHealth,waitForReady} from './health.js';
import {installStartup} from './startup.js';
import {runtimeDirectory} from './supervisor.js';
import path from 'node:path';
const dir=runtimeDirectory(),logPath=path.join(dir,'runtime.log');
async function launch() {
  if(!process.argv.includes('--background')){await installStartup();console.log('Auto-start at Windows sign-in is enabled.');}
  await mkdir(dir,{recursive:true});const log=await open(logPath,'a');let exited=false,spawnError=null,child;
  try {
    child=spawn(process.execPath,[fileURLToPath(new URL('./supervisor.js',import.meta.url))],{detached:true,windowsHide:true,stdio:['ignore',log.fd,log.fd]});
    child.on('error',e=>{spawnError=e;exited=true;});child.on('exit',()=>{exited=true;});
    // A duplicate supervisor exits normally; the existing instance still owns recovery.
    const ready=await waitForReady({failed:()=>Boolean(spawnError)});child.unref();
    if(!ready){const tail=(await readFile(logPath,'utf8').catch(()=>'' )).trim().split('\n').slice(-5).join('\n');throw new Error(`Plus companion is recovering. ${spawnError?.message||tail||'Startup timed out.'}\nLog: ${logPath}`);}
    console.log('Plus companion is ready: http://127.0.0.1:8766 (automatic recovery enabled)');
  }finally{await log.close();}
}
launch().catch(e=>{console.error(e.message);process.exitCode=1;});
