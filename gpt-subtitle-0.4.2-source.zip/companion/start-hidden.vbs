Option Explicit
Dim shell, files, base, nodePath
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
base = files.GetParentFolderName(WScript.ScriptFullName)
nodePath = files.BuildPath(files.GetParentFolderName(base), "runtime\node.exe")
If Not files.FileExists(nodePath) Then nodePath = shell.ExpandEnvironmentStrings("%USERPROFILE%") & "\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
If Not files.FileExists(nodePath) Then nodePath = "node.exe"
shell.Run Chr(34) & nodePath & Chr(34) & " " & Chr(34) & base & "\launch.js" & Chr(34) & " --background", 0, False
