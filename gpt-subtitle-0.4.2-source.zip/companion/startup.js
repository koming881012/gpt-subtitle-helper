import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export async function installStartup() {
  if(process.platform!=='win32')throw new Error('自動啟動目前支援 Windows。');
  const config={script:fileURLToPath(new URL('./start-hidden.vbs',import.meta.url)),directory:fileURLToPath(new URL('../',import.meta.url)),startup:path.join(process.env.APPDATA,'Microsoft','Windows','Start Menu','Programs','Startup','YouTube GPT 字幕連線.lnk')};
  const script="$ErrorActionPreference='Stop'; [Console]::InputEncoding=[Text.UTF8Encoding]::new($false); [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); $config=[Console]::In.ReadToEnd() | ConvertFrom-Json; $shell=New-Object -ComObject WScript.Shell; $link=$shell.CreateShortcut($config.startup); $link.TargetPath=Join-Path $env:WINDIR 'System32\\wscript.exe'; $link.Arguments='\"'+$config.script+'\"'; $link.WorkingDirectory=$config.directory; $link.Description='YouTube GPT 字幕本機連線自動啟動'; $link.Save()";
  await new Promise((resolve,reject)=>{
    const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,stdio:['pipe','ignore','pipe']});let error='';
    child.stderr.on('data',c=>error+=c);child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(new Error(`無法設定登入後自動啟動：${error.trim()}`)));child.stdin.end(JSON.stringify(config));
  });
  return config.startup;
}
