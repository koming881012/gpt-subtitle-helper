if(new URLSearchParams(location.search).has('request')){document.querySelector('#intro').textContent='正在自動連接插件，接著前往 OpenAI 官方登入頁面。';document.querySelector('#manual').hidden=true;}
document.querySelector('#copy').addEventListener('click',async()=>{
  try {const r=await fetch('/page-code',{method:'POST',headers:{'X-Page-Token':document.querySelector('meta[name="page-token"]').content}});if(!r.ok)throw new Error('無法取得本機連線碼。');const b=await r.json();await navigator.clipboard.writeText(b.connectionCode);document.querySelector('#status').textContent='已複製。到插件設定的「帳號管理與連線修復 → 手動配對」儲存連線碼。';}
  catch(e){document.querySelector('#status').textContent=e.message;}
});
