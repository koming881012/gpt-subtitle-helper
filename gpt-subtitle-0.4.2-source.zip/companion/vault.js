import {spawn} from 'node:child_process';
import {mkdir,readFile,writeFile,rename} from 'node:fs/promises';
import path from 'node:path';
export function crypt(mode,bytes) {
  const operation=mode==='protect'?'Protect':'Unprotect';
  const script=`$ErrorActionPreference = 'Stop'; Add-Type -AssemblyName System.Security; $bytes = [Convert]::FromBase64String([Console]::In.ReadToEnd()); $result = [Security.Cryptography.ProtectedData]::${operation}($bytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Out.Write([Convert]::ToBase64String($result))`;
  return new Promise((resolve,reject)=>{
    const p=spawn('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,stdio:['pipe','pipe','pipe']});let out='';
    p.stdout.on('data',c=>out+=c);p.stderr.resume();p.on('error',reject);
    p.on('exit',code=>code===0?resolve(Buffer.from(out.trim(),'base64')):reject(new Error('Windows 憑證保護失敗。')));
    p.stdin.end(Buffer.from(bytes).toString('base64'));
  });
}
export async function openVault() {
  if(process.platform!=='win32')throw new Error('此本機連線程式目前使用 Windows DPAPI。');
  const dir=path.join(process.env.LOCALAPPDATA,'YouTubeGPTSubtitle');await mkdir(dir,{recursive:true});
  const file=path.join(dir,'credentials.dpapi');let value;
  try {value=JSON.parse((await crypt('unprotect',await readFile(file))).toString('utf8'));}
  catch(e){if(e.code!=='ENOENT')throw e;value={};}
  let queue=Promise.resolve();
  return {value,save:()=>{const snapshot=JSON.stringify(value);const work=queue.catch(()=>{}).then(async()=>{const bytes=await crypt('protect',Buffer.from(snapshot));await writeFile(`${file}.tmp`,bytes);await rename(`${file}.tmp`,file);});queue=work;return work;}};
}
