import net from 'node:net';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir,open,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {checkHealth,waitForReady} from './health.js';

export const runtimeDirectory=()=>path.join(process.env.LOCALAPPDATA||process.cwd(),'YouTubeGPTSubtitle');
export function supervisorPipe(directory) {
  const identity=createHash('sha256').update(path.resolve(directory).toLowerCase()).digest('hex').slice(0,24);
  return process.platform==='win32'?`\\\\.\\pipe\\YouTubeGPTSubtitle-${identity}`:path.join(directory,'supervisor.sock');
}
const pause=(ms,signal)=>new Promise(resolve=>{if(signal?.aborted)return resolve();const done=()=>{clearTimeout(timer);signal?.removeEventListener('abort',done);resolve();};const timer=setTimeout(done,ms);signal?.addEventListener('abort',done,{once:true});});

export async function supervise({directory=runtimeDirectory(),check=checkHealth,serverFile=fileURLToPath(new URL('./server.js',import.meta.url)),monitorMs=3000,restartDelayMs=1000,attempts=60,readyDelayMs=200,signal}={}) {
  await mkdir(directory,{recursive:true});
  const lock=net.createServer(socket=>socket.end());
  const claimed=await new Promise((resolve,reject)=>{lock.once('error',e=>e.code==='EADDRINUSE'?resolve(false):reject(e));lock.listen(supervisorPipe(directory),()=>resolve(true));});
  if(!claimed)return false;
  const log=await open(path.join(directory,'runtime.log'),'a');let child=null,exited=true,failures=0,unhealthy=0;
  const status=state=>writeFile(path.join(directory,'supervisor.json'),JSON.stringify({pid:process.pid,childPid:child?.pid||null,state,updatedAt:Date.now()}));
  const note=message=>log.write(`${new Date().toISOString()} ${message}\n`);
  try {
    await note('Connection supervisor started.');
    while(!signal?.aborted) {
      try {
        if(await check()){failures=0;unhealthy=0;await status('ready');await pause(monitorMs,signal);continue;}
        if(child&&!exited&&++unhealthy<3){await pause(monitorMs,signal);continue;}
        // Only terminate a server started by this supervisor, never another process on the port.
        if(child&&!exited)child.kill();
        if(signal?.aborted)break;
        await status('restarting');exited=false;
        child=spawn(process.execPath,[serverFile],{windowsHide:true,stdio:['ignore',log.fd,log.fd]});
        const instance=child;instance.on('error',()=>{if(child===instance)exited=true;});instance.on('exit',()=>{if(child===instance)exited=true;});
        const ready=await waitForReady({check,attempts,delayMs:readyDelayMs,failed:()=>exited||signal?.aborted});
        if(ready){failures=0;await status('ready');continue;}
        if(!exited)child.kill();
        await note('Server not ready; will retry automatically.');
      } catch(e){await note(`Recovery failed: ${e.code||e.name}.`).catch(()=>{});}
      failures++;await pause(Math.min(30000,restartDelayMs*2**Math.min(failures-1,5)),signal);
    }
  } finally {
    if(child&&!exited)child.kill();
    await status('stopped').catch(()=>{});await log.close();await new Promise(resolve=>lock.close(resolve));
  }
  return true;
}
if(process.argv[1]===fileURLToPath(import.meta.url))supervise().catch(e=>{console.error(`Connection supervisor failed: ${e.code||e.name}`);process.exitCode=1;});
