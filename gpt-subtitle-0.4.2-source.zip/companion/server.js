import http from 'node:http';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {ChatGPTAuth,RESOURCE} from './auth.js';
import {openVault} from './vault.js';
const PORT=8766,BASE=`http://127.0.0.1:${PORT}`;
function equal(a,b) {const x=Buffer.from(a||''),y=Buffer.from(b||'');return x.length===y.length&&timingSafeEqual(x,y);}
function json(res,status,data) {res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));}
async function body(req) {let text='';for await(const c of req){text+=c;if(Buffer.byteLength(text)>8*1024*1024)throw Object.assign(new Error('請求太大。'),{status:413});}return JSON.parse(text||'{}');}
export function createCompanion(auth,fetchImpl=fetch) {
  const pageToken=randomBytes(24).toString('base64url');
  const server=http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    const localBase=`http://127.0.0.1:${server.address().port}`;
    if(req.headers.host!==`127.0.0.1:${server.address().port}`){json(res,403,{error:{message:'不允許的 Host。'}});return;}
    const u=new URL(req.url,localBase),origin=req.headers.origin,extension=/^chrome-extension:\/\/[a-p]{32}$/.test(origin||'');
    if(extension){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-ChatGPT-Account');res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');}
    if(req.method==='OPTIONS'){res.writeHead(extension?204:403);res.end();return;}
    try {
      if(req.method==='GET'&&u.pathname==='/health'){json(res,200,{app:'youtube-gpt-subtitle-companion',ready:true,version:'0.4.1'});return;}
      if(req.method==='GET'&&u.pathname==='/auth/callback') {
        const result=await auth.callback(u.searchParams);res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'"});res.end(`<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ChatGPT 登入完成</title><style>body{font:16px/1.7 system-ui;margin:64px auto;max-width:600px;padding:24px;background:#10151f;color:#edf2fa}main{background:#1c2a3d;border:1px solid #405673;border-radius:20px;padding:32px}h1{font-size:25px}p{color:#a7b4c8}.success{color:#91dfb9}</style></head><body><main><p class="success">GPT 中文字幕助手</p><h1>${result.planEnabled?'登入完成，開始看懂影片。':'已登入，還差方案授權。'}</h1><p>${result.planEnabled?'已授權 ChatGPT 方案用量。回到 YouTube 或 Prime Video 影片即可使用中文字幕，插件會自動更新連線狀態。':'請回插件設定按「授權使用 ChatGPT 方案」，完成後即可翻譯。'}</p><p>可以關閉此分頁。</p></main></body></html>`);return;
      }
      if(req.method==='GET'&&u.pathname==='/') {
        const source=await readFile(new URL('./index.html',import.meta.url),'utf8');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"});res.end(source.replace('PAGE_NONCE',pageToken));return;
      }
      if(req.method==='GET'&&u.pathname==='/page.js') {res.writeHead(200,{'Content-Type':'text/javascript'});res.end(await readFile(new URL('./page.js',import.meta.url)));return;}
      if(req.method==='POST'&&u.pathname==='/page-code'&&origin===localBase&&equal(req.headers['x-page-token'],pageToken)) {json(res,200,{connectionCode:auth.vault.value.connectionCode});return;}
      if(!extension||req.method!=='POST'||!equal(req.headers.authorization,`Bearer ${auth.vault.value.connectionCode}`)){json(res,401,{error:{message:'本機連線碼不符，請從本機頁面取得連線碼。'}});return;}
      const b=await body(req);
      if(u.pathname==='/status'){json(res,200,auth.status());return;}
      if(u.pathname==='/auth/start'){json(res,200,{url:auth.start(b)});return;}
      if(u.pathname==='/auth/select'){if(auth.refreshing)await auth.refreshing;json(res,200,await auth.select(b.id));return;}
      if(u.pathname==='/auth/logout'){json(res,200,await auth.logout());return;}
      if(!['/models','/responses'].includes(u.pathname)){json(res,404,{error:{message:'找不到此操作。'}});return;}
      if(req.headers['x-chatgpt-account']&&req.headers['x-chatgpt-account']!==auth.account?.id)throw Object.assign(new Error('翻譯工作與登入帳號不符，請切回原帳號。'),{status:401});
      const controller=new AbortController();res.on('close',()=>controller.abort());const timeout=setTimeout(()=>controller.abort(),245000);
      try {
        const token=await auth.access();
        if(u.pathname==='/responses'&&(b.store!==false||b.stream!==true||!Array.isArray(b.input)||typeof b.model!=='string'))throw Object.assign(new Error('ChatGPT 方案請求格式不符。'),{status:400});
        const headers={Authorization:`Bearer ${token}`};if(u.pathname==='/responses')headers['Content-Type']='application/json';
        const upstream=await fetchImpl(`${RESOURCE}${u.pathname}`,{method:u.pathname==='/models'?'GET':'POST',headers,body:u.pathname==='/responses'?JSON.stringify(b):undefined,signal:controller.signal,redirect:'error'});
        const responseHeaders={'Content-Type':upstream.headers.get('content-type')||'application/json'};const requestId=upstream.headers.get('x-request-id');if(requestId)responseHeaders['X-Request-ID']=requestId;
        res.writeHead(upstream.status,responseHeaders);
        for await(const chunk of upstream.body){if(!res.write(chunk))await new Promise((resolve,reject)=>{const close=()=>{res.off('drain',drain);reject(new Error('本機連線已中斷。'));};const drain=()=>{res.off('close',close);resolve();};res.once('close',close);res.once('drain',drain);});}res.end();
      }finally{clearTimeout(timeout);}
    }catch(e){if(!res.headersSent)json(res,e.status||400,{error:{message:e.message}});else res.destroy();}
  });
  return server;
}
export async function main() {
  const auth=new ChatGPTAuth(await openVault(),`${BASE}/auth/callback`);await auth.init();const server=createCompanion(auth);
  server.listen(PORT,'127.0.0.1',()=>console.log(`本機連線已啟動：${BASE}`));server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'本機連線已在執行，或 8766 埠已被占用。':e.message);process.exitCode=1;});
}
if(process.argv[1]===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
