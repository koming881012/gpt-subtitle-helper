import test from 'node:test';
import assert from 'node:assert/strict';
import {captionWords,sentenceWindow,validateSentences,playableSeconds} from '../translation/sentence-subtitles.js';
test('英文彎引號可結束完整句；超長回饋指出來源詞與詞數，仍拒絕未完成句',()=>{
  const words=captionWords([{id:0,startMs:0,endMs:2000,text:'He said hello to me.'}]),window={start:0,end:words.length,isFinalWindow:true};
  const output={sentences:[{startWord:0,endWord:words.length,en:'He said, “Hello.”',zh:'他說：「你好。」'}]};
  assert.equal(validateSentences(output,words,window).end,words.length);
  const bad=structuredClone(output);bad.sentences[0].en='hello '.repeat(29)+'.';assert.throws(()=>validateSentences(bad,words,window),/startWord 0.*30 詞/);
  bad.sentences[0].en='He said, “Hello”';assert.throws(()=>validateSentences(bad,words,window),/完整句/);
});
import {translateProgressively} from '../translation/progressive-translator.js';
import {researchTerminology} from '../translation/terminology.js';
import {DEFAULT_SETTINGS,PROMPT_VERSION} from '../shared/constants.js';
import {cacheKey} from '../shared/utils.js';
const source=Array.from({length:30},(_,id)=>({id,text:'This is a complete sentence about the board game.',startMs:id*5000,endMs:(id+1)*5000,durationMs:5000}));
const newJob=()=>({jobId:'progressive-test',videoId:'video',title:'Test',duration:150,sourceCues:structuredClone(source),sourceTrack:{languageCode:'en'},cacheKey:'test-cache',model:DEFAULT_SETTINGS.model,promptVersion:PROMPT_VERSION,settings:{...structuredClone(DEFAULT_SETTINGS),terminologyEnabled:true},playheadMs:75000,translatedCues:0});
const memory=()=>{const data={jobs:new Map(),cache:new Map()};return {data,save:async(store,value)=>data[store].set(store==='cache'?value.key:value.jobId,structuredClone(value)),read:async(store,key)=>structuredClone(data[store].get(key))};};

test('播放位置變更優先翻譯新位置；搜尋模型有獨立快取',()=>{
  const words=captionWords(source),first=sentenceWindow(words,[],0,true);
  const sought=sentenceWindow(words,[{start:first.start,end:20}],125000);
  assert(words[sought.start].startMs>=115000);
  const meta={videoId:'video',promptVersion:PROMPT_VERSION},track={languageCode:'en'};
  assert.notEqual(cacheKey(meta,track,DEFAULT_SETTINGS),cacheKey(meta,track,{...DEFAULT_SETTINGS,terminologyModel:'gpt-6-sol'}));
  assert.equal(playableSeconds([{startMs:0,endMs:12000},{startMs:12000,endMs:22000}],5000),17);
  assert.equal(playableSeconds([{startMs:10000,endMs:22000}],0),0);
});
function response(input){const p=JSON.parse(input),sentences=[];for(let start=p.words[0].id;start<p.words.at(-1).id+1;start+=10)sentences.push({startWord:start,endWord:Math.min(start+10,p.words.at(-1).id+1),en:'This is a complete sentence.',zh:'這是完整且容易閱讀的句子。'});return {sentences};}
test('句子字幕保留來源詞範圍，阻擋遺漏、英文名稱、過長與未完成句',()=>{
  const words=captionWords(source),window=sentenceWindow(words,[],0,true),output=response(JSON.stringify({words:words.slice(window.start,window.end)}));
  const validated=validateSentences(output,words,window);assert.equal(validated.end,window.end);assert.equal(validated.cues[0].startMs,0);assert(playableSeconds(validated.cues,0)>30);
  for(const change of [s=>s.zh='使用 Nemesis。',s=>s.zh='字'.repeat(50)+'。',s=>s.en='in the middle of',s=>s.startWord++]){const bad=structuredClone(output);change(bad.sentences[0]);assert.throws(()=>validateSentences(bad,words,window));}
  const next=sentenceWindow(words,[{start:window.start,end:window.end}],0);assert.equal(next.start,window.end);
});
test('未完成整片前保存可播字幕；首批優先播放位置，取消後能保留並續翻',async()=>{
  const store=memory(),job=newJob(),controller=new AbortController();let calls=0,firstStart;
  const request=async({input})=>{calls++;if(calls===1){firstStart=JSON.parse(input).words[0].id;return response(input);}const partial=store.data.cache.get(job.cacheKey);assert(partial.partial);assert(partial.translatedCues.length);assert(partial.translatedCues[0].startMs>=65000);controller.abort();throw new DOMException('Aborted','AbortError');};
  await translateProgressively(job,'test',controller.signal,()=>{}, {...store,request,research:async()=>[]});assert(firstStart>0);assert.equal(job.status,'cancelled');assert(store.data.cache.get(job.cacheKey).partial);const previous=structuredClone(job.wordRanges);
  const resumed=await store.read('jobs',job.jobId);await translateProgressively(resumed,'test',new AbortController().signal,()=>{}, {...store,request:async({input})=>{const p=JSON.parse(input);assert(!previous.some(r=>p.words[0].id>=r.start&&p.words[0].id<r.end));return response(input);},research:async()=>[]});
  const complete=store.data.cache.get(job.cacheKey);assert.equal(resumed.status,'completed',resumed.error);assert.equal(complete.partial,false);assert.equal(resumed.translatedCues,30);assert.equal(complete.translatedCues[0].startMs,0);assert.equal(complete.translatedCues.at(-1).endMs,150000);assert.equal(new Set(complete.translatedCues.map(c=>c.id)).size,complete.translatedCues.length);
});
test('背景術語搜尋不擋首批；完成後校正暫用譯名，搜尋失敗仍保留字幕並提示',async()=>{
  const store=memory(),job=newJob();let resolveResearch,researchReady=false,requests=0,sawPartial=false;
  const research=()=>new Promise(resolve=>{resolveResearch=resolve;});
  await translateProgressively(job,'test',new AbortController().signal,()=>{const cache=store.data.cache.get(job.cacheKey);if(cache?.partial&&!researchReady){sawPartial=true;researchReady=true;resolveResearch([{source:'Game',target:'遊戲',urls:[]}]);}}, {...store,research,request:async({input})=>{requests++;const p=JSON.parse(input);if(requests>2)assert(p.glossary.length);return response(input);}});
  assert(sawPartial);assert.equal(job.terminologyStatus,'ready');assert.equal(store.data.cache.get(job.cacheKey).glossary[0].target,'遊戲');assert.equal(job.status,'completed');
  const failed=newJob();await translateProgressively(failed,'test',new AbortController().signal,()=>{}, {...memory(),research:async()=>{throw new Error('方案使用量已達限制');},request:async({input})=>response(input)});assert.equal(failed.status,'completed',failed.error);assert.equal(failed.terminologyStatus,'failed');assert(failed.warnings?.some(s=>s.includes('搜尋未完成')));
});
test('GPT-6 搜尋必須有實際 tool 紀錄與全繁中詞彙；不能拿模型猜測冒充查證',async()=>{
  const job=newJob();const request=async a=>{assert.equal(a.settings.model,'gpt-6-astra');assert(a.webSearch);a.onResponse({output:[{type:'web_search_call',status:'completed'}]});return {glossary:[{source:'Nemesis',target:'復仇女神號',urls:['https://example.com/rules']}]};};
  assert.equal((await researchTerminology(job,'test',null,request))[0].target,'復仇女神號');
  await assert.rejects(researchTerminology(job,'test',null,async()=>({glossary:[]})),/搜尋紀錄/);
});
