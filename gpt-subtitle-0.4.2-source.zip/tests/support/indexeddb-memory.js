// Node-only transport stub. Real IndexedDB is also tested in mock-player.js.
export function memoryIndexedDB() {
  const stores=new Map();
  const db={createObjectStore:(name,{keyPath})=>stores.set(name,{keyPath,data:new Map()}),transaction:(name)=>{
    const tx={};tx.objectStore=()=>{
      const store=stores.get(name);
      const op=fn=>{const r={};setTimeout(()=>{try{r.result=fn();r.onsuccess?.();setTimeout(()=>tx.oncomplete?.(),0);}catch(e){r.error=e;tx.error=e;tx.onerror?.();}},0);return r;};
      return {get:key=>op(()=>structuredClone(store.data.get(key))),put:value=>op(()=>{store.data.set(value[store.keyPath],structuredClone(value));return value[store.keyPath];}),getAll:()=>op(()=>structuredClone([...store.data.values()])),delete:key=>op(()=>store.data.delete(key)),clear:()=>op(()=>store.data.clear())};
    };return tx;
  }};
  let initialized=false;
  return {open:()=>{const r={};setTimeout(()=>{r.result=db;if(!initialized){initialized=true;r.onupgradeneeded?.();}r.onsuccess?.();},0);return r;}};
}
