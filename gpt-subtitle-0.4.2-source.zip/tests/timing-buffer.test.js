import test from 'node:test';
import assert from 'node:assert/strict';
import {SubtitleBufferController} from '../content/subtitle-buffer-controller.js';
import {SubtitleSync} from '../content/subtitle-sync.js';
import {normalizeSubtitleOffset,subtitleOffsetLabel,subtitleTimeMs} from '../shared/subtitle-timing.js';
import {currentVideoId} from '../content/platform-detector.js';
const settle=()=>new Promise(resolve=>setImmediate(resolve));
function videoFixture({paused=false}={}){
  const handlers=new Map();return {paused,currentTime:12,duration:40,playbackRate:1,isConnected:true,playCalls:0,
    addEventListener(name,fn){if(!handlers.has(name))handlers.set(name,new Set());handlers.get(name).add(fn);},
    removeEventListener(name,fn){handlers.get(name)?.delete(fn);},
    emit(name,event={}){for(const fn of handlers.get(name)||[])fn({type:name,target:this,...event});},
    pause(){this.paused=true;this.emit('pause');},
    play(){this.playCalls++;this.paused=false;this.emit('play');return Promise.resolve();},
    get listenerCount(){return [...handlers.values()].reduce((n,list)=>n+list.size,0);}};
}
const stateFixture=()=>({settings:{pauseForSubtitles:true},pref:{enabled:true,mode:'zh'},meta:{duration:40},job:{status:'translating'},cache:null});

test('額外暫停事件、暫時移除與替換影片元素後仍保留緩衝續播責任',async()=>{
  const state=stateFixture(),old=videoFixture(),controller=new SubtitleBufferController(old,()=>state);
  try {
    controller.check();old.emit('pause');old.emit('pause');assert(controller.held);
    old.isConnected=false;state.cache={partial:false};controller.check();assert.equal(old.playCalls,0);
    const next=videoFixture({paused:true});controller.replaceVideo(next);assert(controller.held);assert.equal(old.listenerCount,0);
    controller.check();await settle();assert(!next.paused);assert(!controller.held);assert.equal(next.playCalls,1);
    controller.check();assert.equal(next.playCalls,1);
  }finally{controller.destroy();}
});

test('明確手動暫停優先，不將使用者的暫停当成緩衝暫停',async()=>{
  const state=stateFixture(),video=videoFixture(),controller=new SubtitleBufferController(video,()=>state);
  try {
    controller.check();video.emit('pointerdown',{isTrusted:true,target:{closest:selector=>selector.startsWith('#ytgpt-control')?null:{getAttribute:()=> 'Pause'}}});
    assert(!controller.held);state.cache={partial:false};controller.check();await settle();assert(video.paused);assert.equal(video.playCalls,0);
    state.cache=null;video.paused=false;controller.check();assert(controller.held);
    video.emit('keydown',{isTrusted:true,key:' ',target:video});state.cache={partial:false};controller.check();assert(video.paused);assert.equal(video.playCalls,0);
  }finally{controller.destroy();}
});

test('續播暫時被播放器中斷時有限重試，拒絕自動播放時保留明確提示',async()=>{
  const state=stateFixture(),video=videoFixture(),controller=new SubtitleBufferController(video,()=>state);
  try {
    controller.check();state.cache={partial:false};const normalPlay=video.play;
    video.play=function(){this.playCalls++;return Promise.reject(new DOMException('interrupted','AbortError'));};
    controller.check();controller.check();await settle();assert.equal(video.playCalls,1);assert(controller.held);
    video.play=normalPlay;controller.lastResumeAt=0;controller.check();await settle();assert.equal(video.playCalls,2);assert(!video.paused);
    state.cache=null;controller.check();state.cache={partial:false};controller.lastResumeAt=0;
    video.play=function(){this.playCalls++;return Promise.reject(new DOMException('blocked','NotAllowedError'));};
    controller.check();await settle();assert(controller.held);assert.match(controller.resumeError,/播放鍵/);
    controller.lastResumeAt=0;controller.check();assert.equal(video.playCalls,3);
    video.play=normalPlay;await video.play();assert(!controller.held);assert.equal(controller.resumeError,null);
  }finally{controller.destroy();}
});

test('提前／延後秒數與分鐘即時作用於整體字幕，負時間不顯示字幕',()=>{
  const video=videoFixture({paused:true});let offset=0,shown;
  globalThis.cancelAnimationFrame=()=>{};
  const sync=new SubtitleSync(video,[{id:0,startMs:10000,endMs:20000},{id:1,startMs:610000,endMs:620000}],c=>shown=c,()=>false,()=>offset);
  try {
    assert.equal(shown[0].id,0);offset=5000;sync.update();assert.equal(shown.length,0);
    offset=120000;assert.equal(subtitleTimeMs(12,offset),-108000);sync.update();assert.equal(shown.length,0);
    offset=-600000;sync.update();assert.equal(shown[0].id,1);
    offset=0;sync.update();assert.equal(shown[0].id,0);
    assert.equal(normalizeSubtitleOffset(Infinity),0);assert.equal(normalizeSubtitleOffset(900000),600000);assert.equal(normalizeSubtitleOffset(-900000),-600000);
    assert.equal(subtitleOffsetLabel(150500),'延後 2 分 30.5 秒');assert.equal(subtitleOffsetLabel(-2500),'提前 2.5 秒');
  }finally{sync.destroy();delete globalThis.cancelAnimationFrame;}
});

test('字幕時間調整後，緩衝使用同一個偏移時間',()=>{
  const video=videoFixture(),state=stateFixture();state.cache={partial:true,sourceCues:[{id:0,startMs:10000,endMs:20000}],translatedCues:[]};state.pref.subtitleOffsetMs=5000;
  const controller=new SubtitleBufferController(video,()=>state);
  try {controller.check();assert(!video.paused);state.pref.subtitleOffsetMs=0;controller.check();assert(video.paused);assert(controller.held);}finally{controller.destroy();}
});

test('Prime 播放器仍存在但影片元素尚未就緒時，不誤判為離開影片',()=>{
  const previousDocument=globalThis.document,previousLocation=globalThis.location;let playerExists=true;
  globalThis.location={href:'https://www.primevideo.com/detail/B012345678'};
  globalThis.document={querySelectorAll:()=>[],querySelector:()=>playerExists?{}:null,documentElement:{getAttribute:()=> 'prime:B012345678'}};
  try{assert.equal(currentVideoId(),'prime:B012345678');playerExists=false;assert.equal(currentVideoId(),null);}finally{globalThis.document=previousDocument;globalThis.location=previousLocation;}
});
