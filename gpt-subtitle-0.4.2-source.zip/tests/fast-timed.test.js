import test from 'node:test';
import assert from 'node:assert/strict';
import {fastBatch,prepareYoutubeCues,translateFastTimed} from '../translation/fast-timed.js';
import {DEFAULT_SETTINGS,FAST_PROMPT_VERSION} from '../shared/constants.js';
const cues=Array.from({length:100},(_,id)=>({id,startMs:id*2000,endMs:id*2000+1800,durationMs:1800,text:`This is line ${id}.`}));
const job=()=>({jobId:'fast',videoId:'video',platform:'youtube',promptVersion:FAST_PROMPT_VERSION,sourceCues:structuredClone(cues),settings:{...DEFAULT_SETTINGS},results:{},duration:200,cacheKey:'fast',warnings:[],playheadMs:80000,model:DEFAULT_SETTINGS.model});
function storage(){let saved;const caches=[];return {caches,save:async(store,value)=>{if(store==='jobs')saved=structuredClone(value);else caches.push(structuredClone(value));},read:async()=>saved};}
test('小首批優先目前位置，後續最多兩批並行；不重送，預設不用術語搜尋，保留時間軸',async()=>{
  const j=job(),s=storage(),sent=[];let active=0,max=0,researchCalls=0;
  const request=async o=>{assert.equal(o.settings.model,'gpt-5.6-luna');assert.equal(o.settings.reasoningEffort,'medium');const input=JSON.parse(o.input);sent.push(input.target.map(c=>c.id));max=Math.max(max,++active);await new Promise(r=>setTimeout(r,3));active--;return {translations:input.target.map(c=>({id:c.id,translation:`第${c.id}句。`}))};};
  await translateFastTimed(j,'test',new AbortController().signal,()=>{},{...s,request,research:async()=>{researchCalls++;return [];}});
  assert.equal(j.status,'completed',j.error);assert(sent[0].length<=4);assert.equal(sent[0][0],39);assert.equal(max,2);assert.equal(researchCalls,0);assert(s.caches[0].partial);assert.equal(s.caches.at(-1).partial,false);
  const ids=sent.flat();assert.equal(ids.length,100);assert.equal(new Set(ids).size,100);for(const c of s.caches.at(-1).translatedCues){assert.equal(c.startMs,cues[c.id].startMs);assert.equal(c.endMs,cues[c.id].endMs);}
});
test('取消保存已完成字幕；重建後只送剩餘 id',async()=>{
  const j=job(),s=storage(),controller=new AbortController(),sent=[];let once=true;
  const request=async o=>{const p=JSON.parse(o.input);sent.push(...p.target.map(c=>c.id));return {translations:p.target.map(c=>({id:c.id,translation:'中文。'}))};};
  const save=async(store,value)=>{await s.save(store,value);if(store==='cache'&&once){once=false;controller.abort();}};
  await translateFastTimed(j,'test',controller.signal,()=>{},{...s,save,request});assert.equal(j.status,'cancelled');assert.equal(Object.keys(j.results).length,4);
  await translateFastTimed(j,'test',new AbortController().signal,()=>{},{...s,request});assert.equal(j.status,'completed');assert.equal(sent.length,new Set(sent).size);assert.equal(sent.length,100);
});
test('部分 batch 輸出先保存並顯示，修復只送缺少的 id',async()=>{
  const j={...job(),sourceCues:cues.slice(0,3),playheadMs:0},s=storage(),sent=[];
  await translateFastTimed(j,'test',new AbortController().signal,()=>{},{...s,request:async o=>{const target=JSON.parse(o.input).target;sent.push(target.map(c=>c.id));return {translations:(sent.length===1?target.slice(0,1):target).map(c=>({id:c.id,translation:'中文。'}))};}});
  assert.equal(j.status,'completed');assert.deepEqual(sent,[[0,1,2],[1,2]]);assert.equal(s.caches[0].translatedCues.length,1);
});
test('YouTube 依原文合併短片段、拆開長片段；不請模型重寫英文且保留完整來源詞',()=>{
  const original=[{id:0,startMs:0,endMs:1000,text:'This is'},{id:1,startMs:1000,endMs:3000,text:'a full sentence.'},{id:2,startMs:3000,endMs:12000,text:Array(60).fill('hello').join(' ')}],result=prepareYoutubeCues(original);
  assert.equal(result[0].text,'This is a full sentence.');assert(result.every(c=>c.text.split(/\s+/).length<=28));assert.equal(result.map(c=>c.text).join(' '),original.map(c=>c.text).join(' '));assert.equal(result.at(-1).endMs,12000);
  assert(fastBatch(cues,{},0,true).target.length<fastBatch(cues,{},0,false).target.length);
});
test('其中一個並行請求失敗會中止其他請求；首批快取及續翻資料不遺失',async()=>{
  const j={...job(),playheadMs:0},s=storage();let calls=0,aborted=0;
  await translateFastTimed(j,'test',new AbortController().signal,()=>{},{...s,request:async o=>{calls++;const p=JSON.parse(o.input);if(calls===1)return {translations:p.target.map(c=>({id:c.id,translation:'中文。'}))};if(calls===2){await new Promise(r=>setTimeout(r,5));const e=new Error('network failed');e.retryable=false;throw e;}return new Promise((_,reject)=>o.signal.addEventListener('abort',()=>{aborted++;reject(o.signal.reason);}));}});
  assert.equal(j.status,'error');assert.equal(j.error,'network failed');assert.equal(aborted,1);assert.equal(Object.keys(j.results).length,4);assert.equal(s.caches.at(-1).translatedCues.length,4);assert(s.caches.at(-1).partial);
});
