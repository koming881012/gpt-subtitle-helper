import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,writeFile,readdir,unlink,rmdir} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {supervise} from '../companion/supervisor.js';

async function until(check) {for(let i=0;i<150;i++){if(await check())return;await new Promise(resolve=>setTimeout(resolve,30));}throw new Error('Supervisor test timed out.');}
test('背景監管只啟動一份；伺服器終止後恢復真正 HTTP 連線',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'ytgpt-supervisor-')),serverFile=path.join(directory,'server.cjs'),addressFile=path.join(directory,'address.json'),signal=new AbortController();
  await writeFile(serverFile,`const http=require('http'),fs=require('fs');const server=http.createServer((req,res)=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ready:true}));});server.listen(0,'127.0.0.1',()=>fs.writeFileSync(${JSON.stringify(addressFile)},JSON.stringify({pid:process.pid,port:server.address().port})));`);
  const address=async()=>JSON.parse(await readFile(addressFile,'utf8'));
  let missNext=false;
  const check=async()=>{if(missNext){missNext=false;return false;}try{const a=await address();return (await fetch('http://127.0.0.1:'+a.port,{signal:AbortSignal.timeout(300)})).ok;}catch{return false;}};
  const running=supervise({directory,serverFile,check,monitorMs:30,restartDelayMs:30,attempts:30,readyDelayMs:30,signal:signal.signal});
  try {
    await until(check);const first=await address();assert(await check());
    assert.equal(await supervise({directory,serverFile,check}),false);
    process.kill(first.pid);await until(async()=>{try{return (await address()).pid!==first.pid&&await check();}catch{return false;}});
    const next=await address();assert.notEqual(next.pid,first.pid);assert(await check());
    // A transient failed health read does not restart a live owned server.
    missNext=true;await until(async()=>!missNext);await new Promise(resolve=>setTimeout(resolve,70));assert.equal((await address()).pid,next.pid);
    assert.equal(JSON.parse(await readFile(path.join(directory,'supervisor.json'),'utf8')).pid,process.pid);
  }finally{signal.abort();await running;for(const file of await readdir(directory))await unlink(path.join(directory,file));await rmdir(directory);}
});
