import test from 'node:test';
import assert from 'node:assert/strict';
import {checkHealth,waitForReady} from '../companion/health.js';
import {requireCompanion} from '../shared/companion.js';
test('連線拒絕、錯誤服務、無效 JSON 不視為 ready',async()=>{
  assert(!await checkHealth(async()=>{throw new TypeError('connection refused');}));
  assert(!await checkHealth(async()=>Response.json({ready:true,app:'other-service'})));
  assert(!await checkHealth(async()=>new Response('bad')));
  assert(await checkHealth(async()=>Response.json({ready:true,app:'youtube-gpt-subtitle-companion'})));
});
test('啟動等待實際 ready，失敗不宣告成功',async()=>{
  let n=0;assert(await waitForReady({check:async()=>++n===3,delayMs:1,attempts:4}));assert.equal(n,3);
  assert(!await waitForReady({check:async()=>false,failed:()=>true,delayMs:1}));
  assert(!await waitForReady({check:async()=>false,attempts:2,delayMs:1}));
});
test('插件等待服務恢復；持續離線不清除登入且拒絕錯誤服務',async()=>{
  await assert.rejects(requireCompanion({attempts:1,fetchImpl:async()=>{throw new TypeError('connection refused');}}),e=>e.code==='COMPANION_UNAVAILABLE'&&/配對與登入仍會保留/.test(e.message));
  await assert.rejects(requireCompanion({attempts:1,fetchImpl:async()=>Response.json({ready:true,app:'other'})}),/尚未恢復/);
  let calls=0;await requireCompanion({attempts:4,delayMs:1,fetchImpl:async()=>{if(++calls<3)throw new TypeError('connection refused');return Response.json({ready:true,app:'youtube-gpt-subtitle-companion'});}});assert.equal(calls,3);
});
