import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {parsePrimeCaptions,primeCaptionSource,subtitleTime} from '../content/prime-caption-parser.js';
import {parseCaptions} from '../content/caption-parser.js';
import {platformFromUrl,primeTitleId,validatePrimeCaptionUrl} from '../shared/platforms.js';
import {cacheKey} from '../shared/utils.js';
import {translateTimedCaptions,timedBatch} from '../translation/timed-translator.js';
const ttml='<tt xmlns="http://www.w3.org/ns/ttml" xmlns:ttp="http://www.w3.org/ns/ttml#parameter" ttp:frameRate="25"><body><div><p begin="00:00:01:12" end="00:00:03:00"><span>Hello &amp; welcome.</span><br/>[door opens]</p><p begin="4.5s" dur="1500ms">Goodbye.</p></div></body></tt>';
test('Prime TTML 與 VTT 保留原始時間、換行、字元，拒絕空白與外部實體',()=>{
  const cues=parsePrimeCaptions(ttml,10);assert.equal(cues[0].startMs,1480);assert.equal(cues[0].endMs,3000);assert.equal(cues[0].text,'Hello & welcome.\n[door opens]');assert.equal(cues[1].endMs,6000);
  assert.deepEqual(parseCaptions(primeCaptionSource(ttml,10).raw,10),cues);
  assert.equal(parsePrimeCaptions('WEBVTT\n\n1\n00:01.250 --> 00:03.000 align:center\n<i>Welcome</i>\n',10)[0].startMs,1250);
  assert.equal(subtitleTime('60t',{tickRate:30}),2000);assert.equal(subtitleTime('10f',{frameRate:25}),400);
  assert.throws(()=>parsePrimeCaptions('<!DOCTYPE tt><tt/>'),/不受支援/);assert.throws(()=>parsePrimeCaptions('<tt><p begin="1s" end="0s">wrong</p></tt>'));
});
test('Prime 跨集數請求排除舊回應；沒有英文時清除上一集來源',async()=>{
  const source=await readFile(new URL('../content/prime-page-bridge.js',import.meta.url),'utf8'),attrs=new Map(),pending=new Map(),answers=[];let handler;
  const video={duration:100,getBoundingClientRect:()=>({width:100,height:100}),closest:()=>null};
  const location={href:'https://www.primevideo.com/detail/B012345678',origin:'https://www.primevideo.com'};
  const document={documentElement:{setAttribute:(k,v)=>attrs.set(k,v),removeAttribute:k=>attrs.delete(k)},querySelectorAll:()=>[video],querySelector:()=>null,title:'Prime'};
  const window={fetch:input=>new Promise(resolve=>pending.set(typeof input==='string'?input:input.url,resolve)),addEventListener:(type,fn)=>{handler=fn;},postMessage:m=>answers.push(m)};
  vm.runInNewContext(source,{window,document,location,URL,AbortSignal,WeakMap});
  const url=id=>`https://atv-ps-fe.primevideo.com/playback/prs/GetVodPlaybackResources?asin=${id}`,payload={subtitleUrls:[{languageCode:'en',url:'https://cf-timedtext.aux.pv-cdn.net/test.ttml2'}]};
  const first=window.fetch(url('B000000001')),second=window.fetch(url('B000000002'));
  pending.get(url('B000000002'))(Response.json(payload));await second;await new Promise(r=>setTimeout(r,5));
  pending.get(url('B000000001'))(Response.json(payload));await first;await new Promise(r=>setTimeout(r,5));
  const read=async()=>{answers.length=0;await handler({source:window,origin:location.origin,data:{channel:'ytgpt-player-bridge-v1',requestId:'read',type:'REQUEST'}});return answers.at(-1).data;};
  assert.equal((await read()).videoId,'prime:B000000002');
  const third=window.fetch(url('B000000003'));assert.equal(await read(),null);pending.get(url('B000000003'))(Response.json({subtitleUrls:[]}));await third;await new Promise(r=>setTimeout(r,5));
  const meta=await read();assert.equal(meta.videoId,'prime:B000000003');assert.equal(meta.captionTracks.length,0);assert.equal(attrs.get('data-ytgpt-prime-bridge'),'no-english-track');
});
test('平台身份與字幕網址限制；Prime 不共用 YouTube 快取',()=>{
  assert.equal(platformFromUrl('https://www.primevideo.com/detail/B012345678'),'primevideo');assert.equal(platformFromUrl('https://primevideo.com.evil.test/'),null);
  assert.equal(primeTitleId('https://www.primevideo.com/detail/title/B012345678'),'B012345678');
  assert(validatePrimeCaptionUrl('https://s.example.aiv-cdn.net/subtitles/file.ttml?signature=example'));
  for(const url of ['https://evil.test/file','http://s.aiv-cdn.net/file','https://user:pass@s.aiv-cdn.net/file','https://aiv-cdn.net.evil.test/file'])assert.throws(()=>validatePrimeCaptionUrl(url));
  const track={languageCode:'en',vssId:'en',kind:'manual'},settings={model:'test',reasoningEffort:'low'};
  assert.notEqual(cacheKey({videoId:'B012345678'},track,settings),cacheKey({videoId:'prime:B012345678'},track,settings));
});
test('Prime 翻譯先處理播放位置，分批可播並精確保留字幕時間',async()=>{
  const cues=Array.from({length:70},(_,id)=>({id,startMs:id*2000,endMs:id*2000+1800,durationMs:1800,text:`Line ${id}`}));
  const job={jobId:'prime-test',videoId:'prime:B012345678',platform:'primevideo',sourceCues:cues,results:{},warnings:[],terminologyStatus:'ready',settings:{model:'test'},playheadMs:80000,duration:140,cacheKey:'prime-key'};
  const calls=[],cache=[],saved=new Map();const request=async options=>{const input=JSON.parse(options.input);calls.push(input);return {translations:input.target.map(c=>({id:c.id,translation:`第${c.id}句中文`}))};};
  await translateTimedCaptions(job,'test',new AbortController().signal,()=>{},{request,save:async(store,value)=>{saved.set(store,structuredClone(value));if(store==='cache')cache.push(structuredClone(value));},read:async()=>saved.get('jobs')});
  assert.equal(job.status,'completed');assert.equal(calls[0].target[0].id,37);assert.equal(calls[0].previousContext.length,25);assert(cache[0].partial);assert.equal(cache.at(-1).partial,false);assert.equal(cache.at(-1).translatedCues.length,70);
  for(const c of cache.at(-1).translatedCues){assert.equal(c.startMs,cues[c.id].startMs);assert.equal(c.endMs,cues[c.id].endMs);}
  assert.equal(new Set(calls.flatMap(c=>c.target.map(x=>x.id))).size,70);assert.equal(timedBatch(cues,Object.fromEntries(cues.map(c=>[c.id,'中文']))),null);
});
test('Prime 翻譯取消保留可播快取，續翻不重送已完成字幕',async()=>{
  const cues=Array.from({length:20},(_,id)=>({id,startMs:id*2000,endMs:id*2000+1000,durationMs:1000,text:'Hello'})),controller=new AbortController(),sent=[],cache=[];
  const job={jobId:'cancel-prime',videoId:'prime:B012345678',sourceCues:cues,results:{},warnings:[],terminologyStatus:'ready',settings:{},duration:40};
  let saved;const request=async o=>{const input=JSON.parse(o.input);sent.push(input.target.map(c=>c.id));return {translations:input.target.map(c=>({id:c.id,translation:'你好'}))};};
  const save=async(store,value)=>{if(store==='jobs')saved=structuredClone(value);else {cache.push(structuredClone(value));if(cache.length===1)controller.abort();}};
  await translateTimedCaptions(job,'test',controller.signal,()=>{},{request,save,read:async()=>saved});assert.equal(job.status,'cancelled');assert.equal(cache[0].translatedCues.length,15);
  await translateTimedCaptions(job,'test',new AbortController().signal,()=>{},{request,save,read:async()=>saved});assert.equal(job.status,'completed');assert.deepEqual(sent[1],[15,16,17,18,19]);
});
test('Prime bridge 保留原生中文字幕偵測，只下載英文，拒絕任意網址與外部訊息',async()=>{
  const source=await readFile(new URL('../content/prime-page-bridge.js',import.meta.url),'utf8'),attrs=new Map(),messages=[],handlers={},requests=[];
  const video={duration:100,getBoundingClientRect:()=>({width:100,height:100}),closest:()=>({querySelector:()=>({textContent:'Sample Prime'})})};
  const subtitleUrl='https://sub.aiv-cdn.net/english.ttml';const window={addEventListener:(type,fn)=>handlers[type]=fn,postMessage:m=>messages.push(m),fetch:async(url)=>{requests.push(url);return /Get(?:Vod)?PlaybackResources/.test(String(url))?Response.json({subtitleUrls:[{languageCode:'en-US',url:subtitleUrl,timedTextTrackId:'English CC'},{languageCode:'zh',url:'https://sub.aiv-cdn.net/zh.ttml'}],forcedNarratives:[{languageCode:'en',url:'https://sub.aiv-cdn.net/forced.ttml'}]}):new Response(ttml);}};
  const document={documentElement:{setAttribute:(key,value)=>attrs.set(key,value),removeAttribute:key=>attrs.delete(key)},querySelectorAll:()=>[video],querySelector:()=>null,title:'Prime'};const location={href:'https://www.primevideo.com/detail/B012345678',origin:'https://www.primevideo.com'};
  vm.runInNewContext(source,{window,document,location,URL,AbortSignal,WeakMap});
  await window.fetch('https://www.primevideo.com/cdp/catalog/GetPlaybackResources?asin=B012345678');await new Promise(r=>setTimeout(r,10));
  const send=async m=>{messages.length=0;await handlers.message({source:window,origin:location.origin,data:{channel:'ytgpt-player-bridge-v1',requestId:'test',...m}});return messages.at(-1);};
  const meta=(await send({type:'REQUEST'})).data;assert.equal(meta.videoId,'prime:B012345678');assert.equal(meta.captionTracks.length,2);assert.equal(meta.captionTracks[1].languageCode,'zh');
  assert.equal((await send({type:'PRIME_SOURCE',videoId:meta.videoId,url:subtitleUrl})).data.raw,ttml);
  const count=requests.length;assert((await send({type:'PRIME_SOURCE',videoId:meta.videoId,url:'https://evil.test'})).error);assert.equal(requests.length,count);
  assert((await send({type:'PRIME_SOURCE',videoId:meta.videoId,url:'https://sub.aiv-cdn.net/zh.ttml'})).error);assert.equal(requests.length,count);
  messages.length=0;await handlers.message({source:{},origin:'https://evil.test',data:{channel:'ytgpt-player-bridge-v1',requestId:'test',type:'REQUEST'}});assert.equal(messages.length,0);
  await window.fetch('https://atv-ps-fe.primevideo.com/playback/prs/GetVodPlaybackResources?titleId=amzn1.dv.gti.a4b25268-4206-4958-b9a5-6a8afc1475a1');await new Promise(r=>setTimeout(r,10));
  // The mock transport uses the same payload for both Prime endpoint generations.
  assert.equal((await send({type:'REQUEST'})).data?.videoId,'prime:A4B2526842064958B9A56A8AFC1475A1');
});
