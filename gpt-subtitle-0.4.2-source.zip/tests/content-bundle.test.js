import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {buildContent} from '../scripts/build-content.js';
import {MSG} from '../shared/messages.js';
import {DEFAULT_SETTINGS} from '../shared/constants.js';
test('Manifest 直接注入完整的 isolated content script；沒有動態模組載入',async()=>{
  const manifest=JSON.parse(await readFile(new URL('../manifest.json',import.meta.url),'utf8'));
  const script=manifest.content_scripts.find(x=>x.js.includes('content/content-bundle.js'));assert.equal(script.world,'ISOLATED');assert.deepEqual(script.js,['content/content-bundle.js']);assert.deepEqual(script.matches,['https://www.youtube.com/*','https://www.primevideo.com/*','https://primevideo.com/*']);assert(!manifest.web_accessible_resources?.length);
  const source=await buildContent({check:true});assert(!/\bimport\s*\(/.test(source));assert(!/\b(?:import|export)\s+[{*]/.test(source));assert(!source.includes('chrome.runtime.getURL'));new vm.Script(source);
});
test('Chrome classic script 初始化與訊息可運作，無跨來源程式請求',async()=>{
  const source=await readFile(new URL('../content/content-bundle.js',import.meta.url),'utf8'),listeners=[],requests=[],errors=[];
  const window={addEventListener:()=>{},removeEventListener:()=>{}};
  const chrome={runtime:{id:'test-extension',onMessage:{addListener:fn=>listeners.push(fn)},getManifest:()=>({version:'0.2.3'}),sendMessage:async m=>{requests.push(m);return {ok:true,data:DEFAULT_SETTINGS};}}};
  const context=vm.createContext({window,chrome,document:{querySelector:()=>null},location:{href:'https://www.youtube.com/',origin:'https://www.youtube.com'},URL,structuredClone,queueMicrotask,DOMException,AbortController,console:{info:()=>{},error:(...args)=>errors.push(args)},setInterval:()=>1,clearInterval:()=>{},clearTimeout:()=>{}});
  vm.runInContext(source,context);await new Promise(resolve=>setImmediate(resolve));
  assert.equal(listeners.length,1);assert.equal(requests[0].type,MSG.SETTINGS);assert.equal(errors.length,0);
  let response;listeners[0]({type:MSG.CONTENT_STATE},{id:'test-extension'},r=>response=r);assert(response.ok);assert.equal(response.data.model,DEFAULT_SETTINGS.model);assert.equal(response.data.videoId,null);assert.equal(response.data.diagnostics.extensionVersion,'0.2.3');
});

test('插件重新載入後舊內容程式停止偵測；diagnostics 不反覆呼叫失效 runtime',async()=>{
  const source=await readFile(new URL('../content/content-bundle.js',import.meta.url),'utf8'),listeners=[],intervals=[],cleared=[],requests=[];let manifestCalls=0;
  const window={addEventListener:()=>{},removeEventListener:()=>{}},location={href:'https://www.youtube.com/',origin:'https://www.youtube.com'};
  const chrome={runtime:{id:'test-extension',onMessage:{addListener:fn=>listeners.push(fn)},getManifest:()=>{if(++manifestCalls>1)throw new Error('Extension context invalidated.');return {version:'0.2.3'};},sendMessage:async m=>{requests.push(m);return {ok:true,data:DEFAULT_SETTINGS};}}};
  const context=vm.createContext({window,chrome,document:{querySelector:()=>null},location,URL,structuredClone,queueMicrotask,DOMException,AbortController,console:{info:()=>{},error:()=>{}},setInterval:fn=>{intervals.push(fn);return intervals.length;},clearInterval:id=>cleared.push(id),clearTimeout:()=>{}});
  vm.runInContext(source,context);await new Promise(resolve=>setImmediate(resolve));
  for(let i=0;i<10;i++){let response;listeners[0]({type:MSG.CONTENT_STATE},{id:'test-extension'},r=>response=r);assert.equal(response.data.diagnostics.extensionVersion,'0.2.3');}
  assert.equal(manifestCalls,1);const previous=requests.length;
  chrome.runtime.id=undefined;location.href='https://www.youtube.com/watch?v=TRv6u_jjP7M';intervals[0]();await new Promise(resolve=>setImmediate(resolve));
  assert(cleared.includes(1));assert.equal(requests.length,previous);assert.equal(manifestCalls,1);
});

async function contentFixture({automatic=false,freshLanguage='en',newJob=false}={}) {
  const source=await readFile(new URL('../content/content-bundle.js',import.meta.url),'utf8'),listeners=[],events=new Map(),messages=[];
  const settings={...DEFAULT_SETTINGS,autoTranslate:automatic,hasConnection:true};
  let pref={enabled:true,mode:'zh',subtitleOffsetMs:0},finishResume,resumeRequested=false,bridgeCalls=0;
  const meta={platform:'youtube',videoId:'3Ah_V94PEJY',title:'Test',duration:20,audioLanguage:'en',captionTracks:[{languageCode:'en',vssId:'a.en',kind:'asr',baseUrl:'https://www.youtube.com/api/timedtext?v=3Ah_V94PEJY&lang=en&kind=asr'}]};
  const window={addEventListener:(name,fn)=>{if(!events.has(name))events.set(name,[]);events.get(name).push(fn);},removeEventListener:()=>{},postMessage:message=>{if(message.type==='REQUEST'){bridgeCalls++;queueMicrotask(()=>{for(const fn of events.get('message')||[])fn({source:window,origin:location.origin,data:{...message,type:'RESPONSE',data:{...meta,audioLanguage:bridgeCalls===1?'en':freshLanguage}}});});}else if(message.type==='YOUTUBE_SOURCE'){assert.equal(message.track.kind,'asr');assert.equal(message.videoId,meta.videoId);queueMicrotask(()=>{for(const fn of events.get('message')||[])fn({source:window,origin:location.origin,data:{...message,type:'RESPONSE',data:{raw:JSON.stringify({events:[{tStartMs:0,dDurationMs:2000,segs:[{utf8:'Hello world.'}]}]}),format:'youtube-player-captions'}}});});}}};
  const location={href:'https://www.youtube.com/watch?v=3Ah_V94PEJY',origin:'https://www.youtube.com'};
  const job={jobId:'job',status:'cancelled',totalCues:1,updatedAt:1};
  const chrome={runtime:{id:'test-extension',getManifest:()=>({version:'test'}),onMessage:{addListener:fn=>listeners.push(fn)},sendMessage:async m=>{messages.push(m);if(m.type===MSG.SETTINGS)return {ok:true,data:settings};if(m.type===MSG.LOOKUP)return {ok:true,data:{pref:{...pref},settings,job:automatic||newJob?null:job,cache:null}};if(m.type===MSG.PREF){pref={...pref,...m.pref};return {ok:true,data:{...pref}};}if(m.type===MSG.RESUME){resumeRequested=true;return new Promise(resolve=>{finishResume=()=>resolve({ok:true,data:{job:{...job,status:'translating',updatedAt:2}}});});}return {ok:true,data:{}};}}};
  const context=vm.createContext({window,chrome,document:{querySelector:()=>null,body:{}},location,URL,structuredClone,queueMicrotask,DOMException,AbortController,crypto:{randomUUID:()=>String(Math.random())},MutationObserver:class{observe(){}disconnect(){}},console:{info:()=>{},error:()=>{}},setTimeout,clearTimeout,setInterval:()=>1,clearInterval:()=>{}});
  vm.runInContext(source,context);
  const request=message=>new Promise(resolve=>listeners[0](message,{id:'test-extension'},resolve));
  for(let n=0;n<30;n++){await new Promise(resolve=>setImmediate(resolve));if((await request({type:MSG.CONTENT_STATE})).data.ready)break;}
  return {request,messages,finish:()=>finishResume?.(),resuming:()=>resumeRequested};
}
test('開始翻譯仍在等待背景回應時能關閉字幕，回應完成不重新開啟',async()=>{
  const f=await contentFixture();const pending=f.request({type:MSG.CONTENT_START});
  for(let n=0;n<30&&!f.resuming();n++)await new Promise(resolve=>setImmediate(resolve));assert(f.resuming());
  const preparing=(await f.request({type:MSG.CONTENT_STATE})).data;assert(preparing.starting);assert(!preparing.hasPlayable);
  assert((await f.request({type:MSG.CONTENT_PREF,pref:{enabled:false}})).ok);
  assert.equal((await f.request({type:MSG.CONTENT_STATE})).data.pref.enabled,false);
  f.finish();assert((await pending).ok);const state=(await f.request({type:MSG.CONTENT_STATE})).data;
  assert.equal(state.pref.enabled,false);assert.equal(state.job.status,'translating');assert(!f.messages.some(m=>m.type===MSG.CANCEL));
  assert((await f.request({type:MSG.CONTENT_PREF,pref:{enabled:true}})).ok);assert.equal((await f.request({type:MSG.CONTENT_STATE})).data.pref.enabled,true);
});
test('自動啟動前重新取得音訊資料，語言改為非英文就停止，不送翻譯工作',async()=>{
  const f=await contentFixture({automatic:true,freshLanguage:'zh'});
  for(let n=0;n<30;n++)await new Promise(resolve=>setImmediate(resolve));
  assert(!f.messages.some(m=>m.type===MSG.START||m.type===MSG.RESUME));
  const state=(await f.request({type:MSG.CONTENT_STATE})).data;assert.equal(state.audioLanguage,'zh');assert.match(state.autoTranslateBlockedReason,/非英文/);assert.equal(state.starting,false);
});

test('正式 bundle 在沒有轉錄稿 DOM 與 fetch 的環境，仍透過播放器 bridge 送出有效原文',async()=>{
  const f=await contentFixture({newJob:true});assert((await f.request({type:MSG.CONTENT_START})).ok);
  const start=f.messages.find(m=>m.type===MSG.START);assert(start);assert.equal(start.source.format,'youtube-player-captions');
  assert.equal(JSON.parse(start.source.raw).events[0].segs[0].utf8,'Hello world.');
});
