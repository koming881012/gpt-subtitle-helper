import test from 'node:test';
import assert from 'node:assert/strict';
import {fetchVideoCaptionSource} from '../content/caption-source.js';
const track={languageCode:'en',vssId:'a.en'},meta={videoId:'video',duration:20};
test('兩個來源並行，人工下載空白仍取得原生英文',async()=>{
  const source={raw:'valid captions'},calls=[];
  assert.equal(await fetchVideoCaptionSource(track,meta,null,{transcript:async()=>{calls.push('native');return source;},download:async()=>{calls.push('download');throw new Error('empty');}}),source);assert.deepEqual(calls,['native','download']);
  assert.equal(await fetchVideoCaptionSource({...track,vssId:'.en'},meta,null,{download:async()=>{throw new Error('YouTube 回傳空字幕或非字幕資料。');},transcript:async()=>source}),source);
});
test('兩種來源失敗保留原因；取消或切換影片中止全部來源',async()=>{
  await assert.rejects(fetchVideoCaptionSource(track,meta,null,{transcript:async()=>{throw new Error('新版轉錄稿載入失敗');},download:async()=>{throw new Error('YouTube 回傳空字幕或非字幕資料。');}}),e=>e.message.includes('新版轉錄稿載入失敗')&&e.message.includes('空字幕'));
  for(const code of ['cancel','VIDEO_CHANGED']){const controller=new AbortController();let downloadSignal;await assert.rejects(fetchVideoCaptionSource(track,meta,controller.signal,{transcript:async()=>{if(code==='cancel')controller.abort();const e=new Error('stopped');e.code=code;throw e;},download:async(_t,_id,s)=>{downloadSignal=s;return new Promise((_,reject)=>s.addEventListener('abort',()=>reject(s.reason)));}}));assert(!downloadSignal||downloadSignal.aborted);}
});
test('慢轉錄稿不阻擋成功下載；贏家取消其餘來源且瞬時失敗可重試',async()=>{let losing;const result=await fetchVideoCaptionSource(track,meta,null,{transcript:(_t,_m,s)=>{losing=s;return new Promise((_,reject)=>s.addEventListener('abort',()=>reject(s.reason)));},download:async()=>({raw:'ready'})});assert.equal(result.raw,'ready');assert(losing.aborted);await assert.rejects(fetchVideoCaptionSource(track,meta,null,{transcript:async()=>{const e=new Error('not ready');e.code='TRANSCRIPT_NOT_READY';throw e;},download:async()=>{throw new Error('empty');}}),{code:'CAPTION_NOT_READY'});});
test('每個來源都有逾時，第一種逾時後可換來源且移除計時器',async()=>{
  const source={raw:'fallback'};
  assert.equal(await fetchVideoCaptionSource(track,meta,null,{transcriptTimeoutMs:5,transcript:(_t,_m,s)=>new Promise((_,reject)=>s.addEventListener('abort',()=>reject(s.reason))),download:async(_t,id,s)=>{assert.equal(id,meta.videoId);assert(!s.aborted);return source;}}),source);
});
