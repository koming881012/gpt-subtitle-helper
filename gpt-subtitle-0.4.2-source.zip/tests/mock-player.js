import { parseCaptions } from '../content/caption-parser.js';
import { SubtitleRenderer,subtitleLines } from '../content/subtitle-renderer.js';
import { SubtitleSync,activeCues,createCueIndex } from '../content/subtitle-sync.js';
import { DEFAULT_STYLE,MODES,PROMPT_VERSION,DEFAULT_SETTINGS } from '../shared/constants.js';
import { putRecord,getRecord,deleteRecord,cacheStats } from '../background/storage.js';
import { cacheKey } from '../shared/utils.js';
import { toSRT } from '../export/srt.js';
const el=id=>document.getElementById(id),video=document.querySelector('video'),player=el('movie_player');
const raw=await (await fetch('fixtures/manual-en-json3.json')).text(),source=parseCaptions(raw,20),translated=(await (await fetch('fixtures/sample-translation.json')).json()).translations;
const cues=source.map(c=>({...c,en:c.text,zh:translated.find(t=>t.id===c.id).translation}));
let style={...DEFAULT_STYLE},mode='both-en',renderer,sync,enabled=true,otherVideo=false;
function mount() {renderer=new SubtitleRenderer(player,style,mode);renderer.setEnabled(enabled);sync=new SubtitleSync(video,cues,c=>renderer.render(c));}
mount();for(const [value,label] of Object.entries(MODES))el('mode').add(new Option(label,value));el('mode').value=mode;
el('mode').addEventListener('change',()=>{mode=el('mode').value;renderer.configure(style,mode);});
el('size').addEventListener('input',()=>{style={...style,zhSize:Number(el('size').value)};renderer.configure(style,mode);});
el('background').addEventListener('change',()=>{style={...style,background:el('background').checked};renderer.configure(style,mode);});
el('play').addEventListener('click',()=>video.paused?video.play():video.pause());
for(const [id,time] of [['seekOverlap',5.5],['seekForward',14],['seekBack',1]])el(id).addEventListener('click',()=>{video.currentTime=time;});
el('speed').addEventListener('change',()=>{video.playbackRate=Number(el('speed').value);});
el('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await player.requestFullscreen();}catch{el('report').textContent='瀏覽器未授權此自動化操作進入全螢幕，請手動在 Chrome 驗證。';}});
el('toggle').addEventListener('click',()=>{enabled=!enabled;renderer.setEnabled(enabled);});
el('navigate').addEventListener('click',()=>{sync?.destroy();renderer?.destroy();sync=null;renderer=null;otherVideo=!otherVideo;if(!otherVideo)mount();el('report').textContent=otherVideo?'SPA 切換：前一影片 Overlay 與 listener 已移除。':'回到原影片：重新掛載字幕。';});
const check=(condition,message)=>{if(!condition)throw new Error(message);};
const waitEvent=(type,action)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error(`${type} timeout`)),3000);video.addEventListener(type,()=>{clearTimeout(timer);resolve();},{once:true});action();});
async function run() {
  const button=el('run');button.disabled=true;const lines=[];
  const test=async(name,fn)=>{await fn();lines.push(`PASS ${name}`);el('report').textContent=lines.join('\n');};
  try {
    if(!renderer){otherVideo=false;mount();}video.pause();
    await test('JSON3/XML 與自動字幕解析',async()=>{check(source.length===5,'cue count');const auto=parseCaptions(await (await fetch('fixtures/auto-en-json3.json')).text());check(auto.length===3,'ASR cue count');check(parseCaptions('<transcript><text start="1" dur="2">A &amp; B</text></transcript>')[0].text==='A & B','XML');});
    await test('實際 HTMLVideoElement 快轉／倒轉／暫停／重疊',async()=>{await waitEvent('seeked',()=>{video.currentTime=5.5;});check(renderer.cues.length===2,'overlap');await waitEvent('seeked',()=>{video.currentTime=14;});check(renderer.cues[0].id===4,'forward');await waitEvent('seeked',()=>{video.currentTime=1;});check(renderer.cues[0].id===0,'backward');const old=video.currentTime;await new Promise(r=>setTimeout(r,50));check(video.currentTime===old,'pause');video.playbackRate=2;await video.play();await new Promise(r=>setTimeout(r,200));video.pause();check(video.currentTime>old,'playback');check(video.playbackRate===2,'rate');video.playbackRate=1;});
    await test('六種排版與雙語上下順序',()=>{for(const key of Object.keys(MODES)){renderer.configure(style,key);const layout=subtitleLines(renderer.cues,key);check(renderer.bottom.children.length===layout.bottom.length,key);check(renderer.top.children.length===layout.top.length,key);}renderer.configure(style,'both-en');check(renderer.bottom.firstElementChild.className==='ytgpt-subtitle-en','English first');});
    await test('即時尺寸／背景／顏色／位置與 native 恢復',()=>{renderer.configure({...style,zhSize:38,background:true,opacity:70,zhColor:'#ffee00',top:11,bottom:12},'split-en');check(renderer.bottom.firstElementChild.style.fontSize==='38px','size');check(renderer.bottom.firstElementChild.style.color==='rgb(255, 238, 0)','color');check(renderer.bottom.style.bottom==='12%','position');renderer.setEnabled(false);check(!player.classList.contains('ytgpt-enabled'),'restore native');renderer.setEnabled(true);renderer.configure(style,mode);});
    await test('相同 cue 不重建 DOM；resize 保留 Overlay',()=>{const node=renderer.bottom.firstElementChild;sync.update();sync.update();check(node===renderer.bottom.firstElementChild,'DOM churn');player.style.width='80%';check(renderer.root.isConnected,'resize');player.style.width='100%';});
    await test('SPA cleanup 不殘留 Overlay，重新掛載不串字幕',()=>{sync.destroy();renderer.destroy();check(!document.getElementById('ytgpt-subtitle-overlay'),'cleanup');check(!player.classList.contains('ytgpt-enabled'),'native restore');mount();check(document.querySelectorAll('#ytgpt-subtitle-overlay').length===1,'duplicate');});
    await test('部分字幕先由快取顯示，下一批到達後可直接更新',async()=>{
      const key='mock-progressive';sync.destroy();
      await putRecord('cache',{key,videoId:'mock-progressive',partial:true,translatedCues:cues.slice(0,2)});
      const first=await getRecord('cache',key);check(first.partial&&first.translatedCues.length<cues.length,'partial before complete');
      sync=new SubtitleSync(video,first.translatedCues,c=>renderer.render(c));
      await waitEvent('seeked',()=>{video.currentTime=1;});check(renderer.cues[0].zh===cues[0].zh,'first partial displays');
      await waitEvent('seeked',()=>{video.currentTime=14;});check(renderer.cues.length===0,'unbuffered position clears old subtitles');
      await putRecord('cache',{key,videoId:'mock-progressive',partial:false,translatedCues:cues});
      sync.destroy();sync=new SubtitleSync(video,(await getRecord('cache',key)).translatedCues,c=>renderer.render(c));
      check(renderer.cues[0].zh===cues[4].zh,'new batch displays at current playhead');await deleteRecord('cache',key);
    });
    await test('實際 IndexedDB 讀寫／cache identity／刪除',async()=>{const key=cacheKey({videoId:'mock-video',promptVersion:PROMPT_VERSION},{languageCode:'en',vssId:'.en'},DEFAULT_SETTINGS);await putRecord('cache',{key,videoId:'mock-video',sourceCues:source,translatedCues:cues});check((await getRecord('cache',key)).translatedCues[0].zh===cues[0].zh,'IDB read');check((await cacheStats()).videos>=1,'stats');await deleteRecord('cache',key);check(await getRecord('cache',key)===undefined,'delete');});
    await test('實際 IndexedDB 工作 checkpoint 可由新連線讀取',async()=>{const jobId='mock-checkpoint';await putRecord('jobs',{jobId,status:'translating',results:{0:'已翻譯'},videoId:'mock-video'});const req=indexedDB.open('ytgpt-subtitles',1);const db=await new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});const tx=db.transaction('jobs','readonly'),r=tx.objectStore('jobs').get(jobId);const j=await new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});check(j.results[0]==='已翻譯','checkpoint');db.close();await deleteRecord('jobs',jobId);});
    await test('匯出保留時間軸；binary lookup 閉區間',()=>{check(toSRT(cues,'bilingual').includes('00:00:03,000'),'export timing');check(activeCues(createCueIndex(cues),6000).length===1,'end exclusive');});
    lines.push(`ALL PASS (${lines.length} browser checks)`);el('report').textContent=lines.join('\n');document.body.dataset.testResult='passed';
  } catch(e) {lines.push(`FAIL ${e.message}`);el('report').textContent=lines.join('\n');document.body.dataset.testResult='failed';}
  finally {button.disabled=false;}
}
el('run').addEventListener('click',run);el('report').textContent='已載入 5 段測試字幕。按「執行瀏覽器驗證」開始。';
