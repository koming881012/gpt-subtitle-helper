import {fetchTranscriptSource} from '../content/transcript-source.js';
import {fetchVideoCaptionSource} from '../content/caption-source.js';
import {parseCaptions} from '../content/caption-parser.js';
const fixture=document.querySelector('#fixture'),report=document.querySelector('#result'),button=document.querySelector('#run');
button.addEventListener('click',async()=>{
  button.disabled=true;const lines=[];
  const check=(value,message)=>{if(!value)throw new Error(message);};
  const test=async(name,fn)=>{await fn();lines.push(`PASS ${name}`);report.textContent=lines.join('\n');};
  try {
    const capture=await (await fetch('../test-results/modern-transcript.json')).json(),track={languageCode:'en',kind:'asr',name:'英文 (自動產生)'},meta={videoId:capture.videoId,duration:capture.duration,captionTracks:[track]};
    let currentId=meta.videoId;
    const acquire=(m=meta,signal)=>fetchTranscriptSource(track,m,signal,{doc:document,videoId:()=>currentId});
    fixture.innerHTML=capture.html;
    await test('報錯影片新版章節轉錄稿：161 段、0:00 至 21:30',async()=>{const cues=parseCaptions((await acquire()).raw,meta.duration);check(cues.length===161,'段落數不符');check(cues[0].startMs===0&&cues.at(-1).startMs===1290000,'來源時間不符');});
    await test('自動英文來源直接擷取，不進入空字幕下載備援',async()=>{let downloads=0;const result=await fetchVideoCaptionSource(track,meta,null,{transcript:(_t,m,s)=>acquire(m,s),download:async()=>{downloads++;throw new Error('空字幕');}});check(parseCaptions(result.raw).length===161&&downloads===0,'未優先取得原生來源');});
    await test('新版搜尋篩選結果禁止當完整字幕',async()=>{const search=fixture.querySelector('textarea');search.value='Nemesis';let rejected=false;try{await acquire();}catch(e){rejected=e.message.includes('清空');}search.value='';check(rejected,'搜尋未被阻擋');});
    await test('同頁切換至舊版面板，重新開啟當前影片轉錄稿',async()=>{
      currentId='second-video';let clicks=0;
      const host=document.createElement('ytd-video-description-transcript-section-renderer'),open=document.createElement('button');open.textContent='Show transcript';host.append(open);fixture.prepend(host);
      open.addEventListener('click',()=>{clicks++;fixture.querySelector('yt-section-list-renderer').remove();const panel=document.createElement('ytd-transcript-renderer');panel.setAttribute('panel-content-visible','');panel.innerHTML='<ytd-transcript-footer-renderer><span id="label-text">英文 (自動產生)</span></ytd-transcript-footer-renderer><ytd-transcript-segment-renderer><span class="segment-timestamp">0:40</span><span class="segment-text">This is the second video.</span></ytd-transcript-segment-renderer><ytd-transcript-segment-renderer><span class="segment-timestamp">1:00</span><span class="segment-text">A short talk before a long music outro.</span></ytd-transcript-segment-renderer>';fixture.append(panel);});
      const cues=parseCaptions((await acquire({...meta,videoId:currentId,duration:300})).raw);check(clicks===1&&cues.length===2&&cues[0].text==='This is the second video.','沿用上一影片');
    });
    lines.push(`ALL PASS (${lines.length} browser checks)`);report.textContent=lines.join('\n');document.body.dataset.testResult='passed';
  }catch(e){report.textContent=lines.join('\n')+`\nFAIL ${e.message}`;document.body.dataset.testResult='failed';}
  finally{button.disabled=false;}
});
