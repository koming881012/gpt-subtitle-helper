import test from 'node:test';
import assert from 'node:assert/strict';
import {connectionUrl,validateHandoff} from '../shared/connection-handoff.js';
import {memoryIndexedDB} from './support/indexeddb-memory.js';
import {MSG} from '../shared/messages.js';
const id='a'.repeat(32),request='test-session',pending={request,tabId:7,expiresAt:2000};
const sender={id,url:connectionUrl(id,request),tab:{id:7}},message={request,connectionCode:'b'.repeat(43)};
test('免連線碼配對只接受插件發起的同分頁、同 session、有期限的本機要求',()=>{
  assert.doesNotThrow(()=>validateHandoff(message,sender,pending,id,1000));
  for(const changed of [{id:'other'},{tab:{id:8}},{url:'http://127.0.0.1:8767/?extension='+id+'&request='+request},{url:'https://www.youtube.com/'},{url:connectionUrl(id,'wrong')},{url:connectionUrl('other',request)}])assert.throws(()=>validateHandoff(message,{...sender,...changed},pending,id,1000));
  assert.throws(()=>validateHandoff({...message,request:'wrong'},sender,pending,id,1000));
  assert.throws(()=>validateHandoff({...message,connectionCode:'invalid'},sender,pending,id,1000));
  assert.throws(()=>validateHandoff(message,sender,pending,id,2000));
  assert.throws(()=>validateHandoff(message,sender,null,id,1000));
  assert(!sender.url.includes(message.connectionCode));
});

test('首次登入自動配對、背景重啟後可完成，重送及來源錯誤不替換連線',async()=>{
  globalThis.indexedDB=memoryIndexedDB();
  const local={},session={},opened=[],calls=[],event={addListener:()=>{}};
  const storage=value=>({get:async key=>({[key]:value[key]}),set:async data=>Object.assign(value,data),remove:async key=>delete value[key],setAccessLevel:async()=>{}});
  globalThis.chrome={storage:{local:storage(local),session:storage(session)},runtime:{id,getURL:p=>`chrome-extension://${id}/${p}`,onMessage:event,onInstalled:event,onStartup:event,getContexts:async()=>[]},commands:{onCommand:event},tabs:{query:async()=>[],create:async options=>{opened.push(options);return {id:7};},update:async(tabId,options)=>opened.push({tabId,...options}),remove:async()=>{}},offscreen:{}};
  globalThis.fetch=async(url,options)=>{
    calls.push(url);
    if(url.endsWith('/health'))return Response.json({app:'youtube-gpt-subtitle-companion',ready:true});
    if(options.headers.Authorization==='Bearer invalid')return Response.json({error:{message:'invalid'}},{status:401});
    assert.equal(options.headers.Authorization,'Bearer '+message.connectionCode);
    return Response.json(url.endsWith('/auth/start')?{url:'https://auth.openai.com/api/accounts/authorize?state=mock'}:{signedIn:true,planEnabled:true});
  };
  const sw=await import('../background/service-worker.js?handoff');
  const ui={id,url:`chrome-extension://${id}/popup/popup.html`};
  await sw.route({type:MSG.SIGN_IN},ui);
  assert.equal(opened[0].url,'about:blank');assert.equal(session.pendingConnection.tabId,7);
  const bridge={id,url:opened[1].url,tab:{id:7}},handoff={...message,request:session.pendingConnection.request};
  const restarted=await import('../background/service-worker.js?handoff-restarted');
  await assert.rejects(restarted.completeConnection(handoff,{...bridge,tab:{id:8}}));assert(!local.connectionCode);
  const result=await restarted.completeConnection(handoff,bridge);
  assert.equal(new URL(result.url).origin,'https://auth.openai.com');assert.equal(local.connectionCode,message.connectionCode);assert(!session.pendingConnection);
  await assert.rejects(restarted.completeConnection(handoff,bridge));assert.equal(local.connectionCode,message.connectionCode);
  local.connectionCode='invalid';const status=await restarted.route({type:MSG.AUTH_STATUS},ui);assert.equal(status.companionReady,true);assert.match(status.error,/重新連接/);
  await restarted.route({type:MSG.SIGN_IN},ui);assert(session.pendingConnection);assert(!opened.at(-1).url.includes(message.connectionCode));
  const pending=session.pendingConnection;pending.expiresAt=0;await assert.rejects(restarted.completeConnection({...message,request:pending.request},{id,url:opened.at(-1).url,tab:{id:7}}));assert.equal(local.connectionCode,'invalid');
  assert(calls.some(url=>url.endsWith('/auth/start')));
});
