import test from 'node:test';
import assert from 'node:assert/strict';
import { memoryIndexedDB } from './support/indexeddb-memory.js';
import { MSG } from '../shared/messages.js';
import { getRecord,putRecord,listRecords } from '../background/storage.js';
globalThis.indexedDB=memoryIndexedDB();
const extensionId='test-extension',extensionOrigin=`chrome-extension://${extensionId}/`,local={},running=new Set(),broadcasts=[];
let created=0,contexts=[];
const event=()=>({addListener:()=>{}});
globalThis.chrome={storage:{local:{get:async name=>Object.fromEntries((Array.isArray(name)?name:[name]).map(k=>[k,structuredClone(local[k])])),set:async value=>Object.assign(local,structuredClone(value)),remove:async name=>delete local[name],setAccessLevel:async()=>{}}},tabs:{query:async()=>[{id:1,url:'https://www.youtube.com/watch?v=3Ah_V94PEJY'}],sendMessage:async(id,message)=>{broadcasts.push(message);return {ok:true};},get:async()=>({url:'https://www.youtube.com/watch?v=3Ah_V94PEJY'})},runtime:{id:extensionId,getURL:p=>extensionOrigin+p,getContexts:async()=>contexts,onMessage:event(),onInstalled:event(),onStartup:event(),openOptionsPage:async()=>{},sendMessage:async m=>{if(m.type===MSG.PING)return {ok:true,data:{jobIds:[...running]}};if(m.type===MSG.RUN){running.add(m.job.jobId);return {ok:true};}if(m.type===MSG.ABORT){running.delete(m.jobId);return {ok:true};}return {ok:true};}},offscreen:{createDocument:async()=>{created++;contexts=[{contextType:'OFFSCREEN_DOCUMENT'}];}},commands:{onCommand:event()}};
const sender={id:extensionId,url:extensionOrigin+'options/options.html',tab:{id:99}},contentSender={id:extensionId,url:'https://www.youtube.com/watch?v=3Ah_V94PEJY',tab:{id:1}};
globalThis.fetch=async(url,o)=>{if(url.endsWith('/health'))return Response.json({app:'youtube-gpt-subtitle-companion',ready:true});assert.equal(o.headers.Authorization,'Bearer '+ 'a'.repeat(43));return Response.json(url.endsWith('/models')?{models:[{slug:'gpt-5.6-luna',display_name:'GPT-5.6-Luna',visibility:'list'}]}:{signedIn:true,planEnabled:true});};
const sw=await import('../background/service-worker.js');
const meta={videoId:'3Ah_V94PEJY',title:'Test',duration:20,isLive:false},track={languageCode:'en',vssId:'a.en',kind:'asr',name:'English (auto-generated)',baseUrl:'https://www.youtube.com/api/timedtext?v=3Ah_V94PEJY&lang=en&kind=asr'};

test('中文字幕預設與一次偏好遷移，後續使用者選擇仍保留',async()=>{
  local[`pref:${meta.videoId}`]={enabled:true,mode:'both-en'};
  assert.equal((await sw.route({type:MSG.LOOKUP,meta,track},contentSender)).pref.mode,'zh');
  await sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{mode:'both-zh'}},contentSender);
  assert.equal((await sw.route({type:MSG.LOOKUP,meta,track},contentSender)).pref.mode,'both-zh');
  await sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{mode:'zh'}},contentSender);
  assert.equal((await sw.route({type:MSG.LOOKUP,meta,track},contentSender)).pref.subtitleOffsetMs,0);
  await sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{subtitleOffsetMs:120500}},contentSender);
  await sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{mode:'both-en'}},contentSender);
  assert.equal((await sw.route({type:MSG.LOOKUP,meta,track},contentSender)).pref.subtitleOffsetMs,120500);
  await assert.rejects(sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{subtitleOffsetMs:700000}},contentSender),/10 分鐘/);
  await assert.rejects(sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{subtitleOffsetMs:NaN}},contentSender),/10 分鐘/);
  await sw.route({type:MSG.PREF,videoId:'other-video',pref:{subtitleOffsetMs:-2000}},sender);
  assert.equal(local['pref:other-video'].subtitleOffsetMs,-2000);assert.equal(local[`pref:${meta.videoId}`].subtitleOffsetMs,120500);
  await sw.route({type:MSG.PREF,videoId:meta.videoId,pref:{mode:'zh',subtitleOffsetMs:0}},contentSender);
});

test('原生人工中文字幕在背景啟動前阻擋，不建立翻譯工作',async()=>{
  const before=(await listRecords('jobs')).length;
  await assert.rejects(sw.route({type:MSG.START,meta:{...meta,captionTracks:[track,{languageCode:'zh-TW'}]},track},contentSender),/原生中文字幕/);
  assert.equal((await listRecords('jobs')).length,before);
});
test('Service Worker 訊息、重啟、重複工作防護、取消與 cache lifecycle',async()=>{
  local.modelChoiceVersion=0;
  local.settings={model:'gpt-6.1-sol'};
  await sw.route({type:MSG.CONNECT,connectionCode:'a'.repeat(43)},sender);
  const s=await sw.route({type:MSG.SETTINGS},contentSender);assert(s.hasConnection);assert(!JSON.stringify(s).includes('test-token'));
  assert.equal(s.model,'gpt-5.6-luna');assert.equal(s.reasoningEffort,'medium');assert.equal(s.terminologyEnabled,false);assert.equal(local.modelChoiceVersion,2);
  await sw.route({type:MSG.SAVE,settings:{...s,model:'gpt-6-astra'}},sender);assert.equal((await sw.route({type:MSG.SETTINGS},sender)).model,'gpt-6-astra');
  await sw.route({type:MSG.SAVE,settings:s},sender);
  const spaSender={...contentSender,url:'https://www.youtube.com/watch?v=LNgmTsCaExE'};
  assert((await sw.route({type:MSG.LOOKUP,meta,track},spaSender)).settings);
  await assert.rejects(sw.route({type:MSG.LOOKUP,meta,track},{...contentSender,url:'https://example.com/'}),/訊息來源/);
  await assert.rejects(sw.route({type:MSG.CONNECT,connectionCode:'bad'},contentSender),/只允許/);
  await assert.rejects(sw.route({type:MSG.START,meta:{...meta,videoId:'LNgmTsCaExE'},track},contentSender),/切換/);
  const starts=await Promise.all([sw.route({type:MSG.START,meta,track},contentSender),sw.route({type:MSG.START,meta,track},contentSender)]);assert.equal(starts[0].job.jobId,starts[1].job.jobId);assert.equal((await listRecords('jobs')).length,1);assert.equal(created,1);
  const id=starts[0].job.jobId;let job=await getRecord('jobs',id);job.sourceCues=[{id:0,startMs:0,durationMs:1000,endMs:1000,text:'source'}];job.results={0:'已完成'};await putRecord('jobs',job);
  assert(await sw.route({type:MSG.PRIORITY,jobId:id,playheadMs:15000},contentSender));
  assert.equal(await sw.route({type:MSG.PRIORITY,jobId:id,playheadMs:NaN},contentSender),false);
  await assert.rejects(sw.route({type:MSG.PRIORITY,jobId:id,playheadMs:1},sender),/訊息來源/);
  await putRecord('cache',{key:job.cacheKey,videoId:meta.videoId,partial:true,translatedCues:[{id:0,zh:'已可播放'}]});
  const partialStart=await sw.route({type:MSG.START,meta,track},contentSender);assert(partialStart.job);assert(!partialStart.cache);assert.equal(partialStart.job.jobId,id);
  running.clear();const restarted=await import('../background/service-worker.js?restart=1');
  // Explicit recovery is acknowledged synchronously; wait for persisted job dispatch.
  await restarted.route({type:MSG.RECOVER},{id:extensionId,url:extensionOrigin+'offscreen/offscreen.html'});
  for(let i=0;i<100&&!running.has(id);i++)await new Promise(r=>setTimeout(r,5));
  assert(running.has(id));assert.equal((await getRecord('jobs',id)).results[0],'已完成');assert.equal((await listRecords('jobs')).length,1);assert.equal(created,1);
  await restarted.route({type:MSG.CANCEL,jobId:id},contentSender);assert.equal((await getRecord('jobs',id)).status,'cancelled');assert(!running.has(id));
  await assert.rejects(restarted.route({type:MSG.RESUME,jobId:id,meta:{...meta,captionTracks:[{languageCode:'zh-Hant'}]},track},contentSender),/原生中文字幕/);assert(!running.has(id));
  await restarted.route({type:MSG.RESUME,jobId:id,track},contentSender);assert(running.has(id));assert.equal((await getRecord('jobs',id)).results[0],'已完成');
  await assert.rejects(restarted.route({type:MSG.CLEAR,current:true,tabId:1},sender),/取消/);
  await restarted.route({type:MSG.CANCEL,jobId:id},contentSender);
  job=await getRecord('jobs',id);job.status='completed';await putRecord('jobs',job);await putRecord('cache',{key:job.cacheKey,videoId:meta.videoId,sourceTrack:track,sourceCues:job.sourceCues,translatedCues:[{id:0,en:'source',zh:'中文',startMs:0,endMs:1000}]});
  await restarted.route({type:MSG.PREF,videoId:meta.videoId,pref:{enabled:false}},contentSender);
  await restarted.route({type:MSG.CHECKPOINT,jobId:id},{id:extensionId,url:extensionOrigin+'offscreen/offscreen.html'});
  assert.equal(local[`pref:${meta.videoId}`].enabled,false,'翻譯完成不覆蓋手動關閉字幕');
  const hit=await restarted.route({type:MSG.LOOKUP,meta,track},contentSender);assert(hit.cache);const cached=await restarted.route({type:MSG.START,meta,track},contentSender);assert(cached.cache);assert.equal((await listRecords('jobs')).length,1);
  await restarted.route({type:MSG.CLEAR,current:true,tabId:1},sender);assert.equal((await listRecords('cache')).length,0);assert(broadcasts.some(x=>x.type===MSG.INVALIDATE));
  assert.equal(await getRecord('jobs',id),undefined);delete job.sourceCues;job.status='error';job.totalCues=0;await putRecord('jobs',job);
  const nativeSource={raw:'{"events":[{"tStartMs":0,"dDurationMs":1000,"segs":[{"utf8":"English"}]}]}',format:'youtube-transcript-dom'};
  await restarted.route({type:MSG.RESUME,jobId:id,track,source:nativeSource},contentSender);assert.deepEqual((await getRecord('jobs',id)).prefetchedSource,nativeSource);await restarted.route({type:MSG.CANCEL,jobId:id},contentSender);
  await assert.rejects(restarted.route({type:MSG.SIGN_OUT},contentSender),/只允許/);
});
test('Prime 背景工作核對播放集數，隔離快取並拒絕無效來源及子框架',async()=>{
  const primeMeta={platform:'primevideo',videoId:'prime:B012345678',title:'Prime Episode',duration:20,isLive:false},primeTrack={languageCode:'en-US',vssId:'english-cc',kind:'manual',baseUrl:'https://s.aiv-cdn.net/subs/english.ttml'},primeSender={id:extensionId,url:'https://www.primevideo.com/detail/B098765432',frameId:0,tab:{id:2}};
  const source={raw:'{"events":[{"tStartMs":0,"dDurationMs":1000,"segs":[{"utf8":"Welcome"}]}]}',format:'primevideo-timed-captions'},oldGet=chrome.tabs.get,oldSend=chrome.tabs.sendMessage;
  let currentId=primeMeta.videoId;
  chrome.tabs.get=async id=>id===2?{id:2,url:primeSender.url}:oldGet(id);
  chrome.tabs.sendMessage=async(id,m)=>id===2&&m.type===MSG.CONTENT_STATE?{ok:true,data:{videoId:currentId}}:oldSend(id,m);
  try {
    assert((await sw.route({type:MSG.LOOKUP,meta:primeMeta,track:primeTrack},primeSender)).settings);
    await assert.rejects(sw.route({type:MSG.LOOKUP,meta:primeMeta,track:primeTrack},{...primeSender,frameId:1}),/訊息來源/);
    currentId='prime:B000000000';await assert.rejects(sw.route({type:MSG.LOOKUP,meta:primeMeta,track:primeTrack},primeSender),/切換/);currentId=primeMeta.videoId;
    await assert.rejects(sw.route({type:MSG.START,meta:primeMeta,track:primeTrack},primeSender),/取得英文字幕/);
    await assert.rejects(sw.route({type:MSG.START,meta:primeMeta,track:{...primeTrack,baseUrl:'https://evil.test'},source},primeSender),/來源不受支援/);
    const started=await sw.route({type:MSG.START,meta:primeMeta,track:primeTrack,source,playheadMs:5000},primeSender),job=await getRecord('jobs',started.job.jobId);
    assert.equal(job.platform,'primevideo');assert(job.promptVersion.endsWith('-prime-timed-v1'));assert.equal(JSON.parse(job.cacheKey)[0],'primevideo');assert.equal(job.playheadMs,5000);assert.deepEqual(job.prefetchedSource,source);
    await sw.route({type:MSG.CANCEL,jobId:job.jobId},primeSender);
  }finally{chrome.tabs.get=oldGet;chrome.tabs.sendMessage=oldSend;}
});
test('改模型仍載入舊完整快取且不發起翻譯；備份匯入／另存使用本機與指定位置',async()=>{
  const old={key:'old-sol-cache',videoId:meta.videoId,sourceTrack:track,model:'gpt-5.6-sol',promptVersion:'old',translatedCues:[{id:0,startMs:0,endMs:1000,durationMs:1000,en:'Hello.',zh:'你好。'}]};await putRecord('cache',old);
  const before=(await listRecords('jobs')).length,hit=await sw.route({type:MSG.LOOKUP,meta,track},contentSender);assert.equal(hit.cache.model,'gpt-5.6-sol');assert((await sw.route({type:MSG.START,meta,track},contentSender)).cache);assert.equal((await listRecords('jobs')).length,before);
  let download;chrome.downloads={download:async opts=>{download=opts;return 42;}};
  await sw.route({type:MSG.SAVE_FILE,videoId:meta.videoId,title:'test',format:'srt',language:'zh-TW',raw:'你好。'},contentSender);assert.equal(download.saveAs,true);assert.equal(download.filename,'test.zh-TW.srt');assert(download.url.startsWith('data:'));assert.equal(decodeURIComponent(download.url.split(',')[1]),'你好。');
  const imported=await sw.route({type:MSG.IMPORT_FILE,meta,format:'srt',raw:'1\n00:00:00,000 --> 00:00:01,000\n匯入字幕。'},contentSender);assert(imported.cache.imported);const loaded=await sw.route({type:MSG.LOOKUP,meta,track:null},contentSender);assert.equal(loaded.cache.translatedCues[0].zh,'匯入字幕。');
  await assert.rejects(sw.route({type:MSG.IMPORT_FILE,meta,format:'srt',raw:'bad'},contentSender),/有效字幕/);await sw.route({type:MSG.CLEAR,current:true,tabId:1},sender);
});
test('舊部分進度找回同一個工作，改用 Luna／medium 只續翻剩餘部分',async()=>{
  const ck='partial-old-key',partialJob={jobId:'partial-old',videoId:meta.videoId,status:'cancelled',settings:{model:'gpt-5.6-sol',reasoningEffort:'high'},model:'gpt-5.6-sol',sourceTrack:track,sourceTrackId:[track.languageCode,track.vssId,track.kind].join(':'),cacheKey:ck,duration:20,totalCues:2,sourceCues:[{id:0,startMs:0,endMs:1000,durationMs:1000,text:'Hello.'},{id:1,startMs:1000,endMs:2000,durationMs:1000,text:'Next.'}],results:{0:'你好。'}};
  await putRecord('jobs',partialJob);await putRecord('cache',{key:ck,videoId:meta.videoId,sourceTrack:track,partial:true,sourceCues:partialJob.sourceCues,translatedCues:[{id:0,startMs:0,endMs:1000,en:'Hello.',zh:'你好。'}]});
  const found=await sw.route({type:MSG.LOOKUP,meta,track},contentSender);assert.equal(found.job.jobId,'partial-old');await sw.route({type:MSG.RESUME,jobId:found.job.jobId,track},contentSender);const resumed=await getRecord('jobs','partial-old');assert.equal(resumed.settings.model,'gpt-5.6-luna');assert.equal(resumed.settings.reasoningEffort,'medium');assert.deepEqual(resumed.results,{0:'你好。'});await sw.route({type:MSG.CANCEL,jobId:'partial-old'},contentSender);
});
