import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {fetchCaptionSource} from '../content/caption-fetcher.js';
import {fetchVideoCaptionSource} from '../content/caption-source.js';
import {parseCaptions} from '../content/caption-parser.js';

const script=await readFile(new URL('../content/page-bridge.js',import.meta.url),'utf8');
const videoId='x-a5Kn9p8WM';
const raw=JSON.stringify({events:[{tStartMs:13000,dDurationMs:6000,segs:[{utf8:'Hi, baby. I just wanted to send a quick hello.'}]}]});
const url=`https://www.youtube.com/api/timedtext?v=${videoId}&lang=en&kind=asr&signature=original&fmt=srv3`;
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function fixture(fetchImpl=async()=>new Response('')) {
  const events=new Map(),messages=[],calls=[];
  const track={languageCode:'en',name:'English (auto-generated)',kind:'asr',vssId:'a.en',baseUrl:url};
  const response={videoDetails:{videoId,lengthSeconds:'1151'},captions:{playerCaptionsTracklistRenderer:{captionTracks:[{...track,name:{simpleText:track.name}}]}}};
  const location={href:`https://www.youtube.com/watch?v=${videoId}`,pathname:'/watch',origin:'https://www.youtube.com'};
  class XHR {
    open(method,url){this.url=url;}
    send(){}
    addEventListener(name,fn){this.onload=fn;}
    complete(text,{status=200,type=''}={}){this.status=status;this.responseType=type;this.response=type==='json'?JSON.parse(text):text;this.responseText=text;this.onload?.();}
  }
  const window={XMLHttpRequest:XHR,fetch:(input,init)=>{calls.push({url:input,init});return fetchImpl(input,init);},addEventListener:(name,fn)=>events.set(name,fn),postMessage:m=>messages.push(m)};
  const document={getElementById:()=>({getPlayerResponse:()=>response}),querySelector:()=>null};
  vm.runInContext(script,vm.createContext({window,location,document,URL,AbortController,setTimeout,clearTimeout}));
  const emit=(data,source=window,origin=location.origin)=>events.get('message')({source,origin,data:{channel:'ytgpt-player-bridge-v1',requestId:'source',...data}});
  return {window,calls,location,track,response,emit,navigate:()=>events.get('yt-navigate-start')(),messages,source:async(data={})=>{await emit({type:'YOUTUBE_SOURCE',videoId,track,...data});return messages.at(-1);}};
}

test('不需要轉錄稿 DOM 即可從頁面環境取得英文字幕；先保留完整簽署網址',async()=>{
  const f=fixture(async()=>new Response(raw)),reply=await f.source();
  assert.equal(reply.data.format,'youtube-player-captions');assert.equal(parseCaptions(reply.data.raw).length,1);
  assert.equal(f.calls.length,1);assert.equal(f.calls[0].url,url);assert.equal(f.calls[0].init.credentials,'include');assert.equal(f.calls[0].init.redirect,'error');
  const urls=[];await fetchCaptionSource(f.track,videoId,null,async u=>{urls.push(u);return new Response(raw);});assert.deepEqual(urls,[url]);
});

test('播放器原生 fetch／XHR 完整來源可沿用，不另行下載；不修改原始回應',async()=>{
  for(const transport of ['fetch','xhr-text','xhr-json']){
    const f=fixture(async()=>new Response(raw));
    if(transport==='fetch'){const r=await f.window.fetch(url);assert.equal(await r.text(),raw);await tick();}
    else {const x=new f.window.XMLHttpRequest();x.open('GET',url);x.send();x.complete(raw,{type:transport==='xhr-json'?'json':''});}
    const before=f.calls.length,reply=await f.source();assert.equal(reply.data.raw,raw);assert.equal(f.calls.length,before);
  }
});

test('不沿用其他影片、語言、來源軌、自動翻譯或分段回應；拒絕非字幕資料',async()=>{
  for(const rejected of [url.replace(videoId,'3Ah_V94PEJY'),url.replace('lang=en','lang=ja'),url.replace('kind=asr','kind=manual'),url+'&tlang=en',url+'&seq=1',url+'&start=10']){
    const f=fixture(async u=>new Response(u===rejected?raw:''));await f.window.fetch(rejected);await tick();
    const reply=await f.source();assert(reply.error,`reused ${rejected}`);
  }
  for(const bad of ['', '<html>sign in</html>', '{"events":[]}', '<!DOCTYPE x><transcript><text>bad</text></transcript>']){
    const f=fixture(async()=>new Response(bad));const reply=await f.source();assert(reply.error);
  }
});

test('來源要求只能使用目前播放器的英文軌，拒絕外部網址、偽造來源與跨網站訊息',async()=>{
  for(const patch of [{languageCode:'ja'},{kind:'manual'},{vssId:'a.other'},{name:'different'}]){
    const f=fixture(async()=>new Response(raw)),reply=await f.source({track:{...f.track,...patch}});assert(reply.error);assert.equal(f.calls.length,0);
  }
  const f=fixture();f.response.captions.playerCaptionsTracklistRenderer.captionTracks[0].baseUrl='https://evil.test/api/timedtext';assert((await f.source()).error);assert.equal(f.calls.length,0);
  await f.emit({type:'YOUTUBE_SOURCE',videoId,track:f.track},{},'https://evil.test');assert.equal(f.messages.length,1);
});

test('取消與 SPA 切換中止實際下載，不將前一支影片回應交給新影片',async()=>{
  for(const navigation of [false,true]){
    let signal;const f=fixture((_u,init)=>new Promise((resolve,reject)=>{signal=init.signal;signal.addEventListener('abort',()=>reject(signal.reason),{once:true});}));
    const pending=f.source();await tick();assert(signal);
    if(navigation){f.location.href='https://www.youtube.com/watch?v=3Ah_V94PEJY';f.navigate();}else await f.emit({type:'CANCEL_SOURCE'});
    assert(signal.aborted);assert((await pending).error);
  }
  const f=fixture(async()=>new Response(raw));await f.window.fetch(url);await tick();f.navigate();
  assert((await f.source()).data);assert.equal(f.calls.length,2,'navigation must clear previously captured subtitles');
});

test('播放器資料成功時不開啟轉錄稿；格式錯誤仍可切換其他來源',async()=>{
  const meta={videoId,duration:1151},track={languageCode:'en'};let opened=0;
  const result=await fetchVideoCaptionSource(track,meta,null,{player:async()=>({raw,format:'youtube-player-captions'}),download:async()=>{throw new Error('empty');},transcript:async()=>{opened++;throw new Error('no DOM');}});
  assert.equal(result.raw,raw);assert.equal(opened,0);
  const fallback=await fetchVideoCaptionSource(track,meta,null,{transcriptDelayMs:0,player:async()=>({raw:'{"events":[]}'}),download:async()=>{throw new Error('empty');},transcript:async()=>({raw,format:'youtube-transcript-dom'})});
  assert.equal(fallback.format,'youtube-transcript-dom');
  await assert.rejects(fetchVideoCaptionSource(track,meta,null,{transcriptDelayMs:0,player:async()=>{throw new Error('player failure');},download:async()=>{throw new Error('download failure');},transcript:async()=>{throw new Error('DOM failure');}}),e=>['player failure','download failure','DOM failure'].every(s=>e.message.includes(s)));
});
