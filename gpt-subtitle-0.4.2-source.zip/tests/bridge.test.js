import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
const script=await readFile(new URL('../content/page-bridge.js',import.meta.url),'utf8');
function bridge(player,response,flex) {
  let handler,answer;
  const window={ytInitialPlayerResponse:response,addEventListener:(name,fn)=>{handler=fn;},postMessage:message=>{answer=message;}};
  const location={href:'https://www.youtube.com/watch?v=3Ah_V94PEJY',pathname:'/watch',origin:'https://www.youtube.com'};
  const context=vm.createContext({window,location,URL,document:{getElementById:()=>player,querySelector:()=>flex}});
  vm.runInContext(script,context);
  return {request:(videoId='3Ah_V94PEJY')=>{location.href=`https://www.youtube.com/watch?v=${videoId}`;answer=null;handler({source:window,origin:location.origin,data:{channel:'ytgpt-player-bridge-v1',type:'REQUEST',requestId:'test-request'}});return answer?.data;},foreign:()=>{answer=null;handler({source:{},origin:'https://evil.test',data:{channel:'ytgpt-player-bridge-v1',type:'REQUEST',requestId:'test-request'}});return answer;}};
}
const response=id=>({videoDetails:{videoId:id,title:'Sample',lengthSeconds:'120',secret:'never share'},captions:{playerCaptionsTracklistRenderer:{captionTracks:[{languageCode:'en',kind:'asr',vssId:'a.en',name:{runs:[{text:'English'},{text:' (auto-generated)'}]},baseUrl:`https://www.youtube.com/api/timedtext?v=${id}&lang=en&kind=asr`}]}}});
test('MAIN bridge 讀取 player JSON，只輸出需要資料，保留 ASR',()=>{const api=bridge({getPlayerResponse:()=>JSON.stringify(response('3Ah_V94PEJY'))});const r=api.request();assert.equal(r.captionTracks[0].kind,'asr');assert.equal(r.captionTracks[0].name,'English (auto-generated)');assert.equal(r.duration,120);assert(!JSON.stringify(r).includes('secret'));assert.equal(api.foreign(),null);});
test('SPA 不沿用 stale ytInitialPlayerResponse，讀取當前 flex response',()=>{const api=bridge({},response('LNgmTsCaExE'),{playerResponse:response('3Ah_V94PEJY')});assert.equal(api.request().videoId,'3Ah_V94PEJY');assert.equal(api.request('rbhX4k7aklA'),null);});
test('Player runtime tracklist fallback，必須核對影片 ID',()=>{const api=bridge({getVideoData:()=>({video_id:'3Ah_V94PEJY',title:'Runtime'}),getOption:()=>[{languageCode:'en-US',displayName:'English (US)',baseUrl:'https://www.youtube.com/api/timedtext?v=3Ah_V94PEJY&lang=en-US'}],getDuration:()=>10});assert.equal(api.request().title,'Runtime');assert.equal(api.request('LNgmTsCaExE'),null);});

test('英文 ASR 與英文配音不冒充原始英文音訊；不分享音訊 URL',()=>{
  const r=response('3Ah_V94PEJY');r.streamingData={adaptiveFormats:[{url:'private-audio-url',audioTrack:{id:'zh-TW.1',displayName:'中文（原始）'}},{audioTrack:{id:'en.2',displayName:'English',audioIsDefault:true}}]};r.videoDetails.defaultAudioLanguage='en';
  const result=bridge({getPlayerResponse:()=>r}).request();assert.equal(result.audioLanguage,'zh-tw');assert.equal(result.audioLanguageSource,'original-audio-track');assert(!JSON.stringify(result).includes('private-audio-url'));
});
test('音訊語言以音軌或明確音訊中繼資料判斷；不從字幕、標題語言或預設配音猜原始語言',()=>{
  const r=response('3Ah_V94PEJY');r.videoDetails.defaultLanguage='en';
  assert.equal(bridge({getPlayerResponse:()=>r}).request().audioLanguage,null);
  r.videoDetails.defaultAudioLanguage='ja';assert.equal(bridge({getPlayerResponse:()=>r}).request().audioLanguage,'ja');delete r.videoDetails.defaultAudioLanguage;
  r.streamingData={adaptiveFormats:[{audioTrack:{id:'en-US.1',displayName:'English'}},{audioTrack:{id:'en-US.1'}}]};assert.equal(bridge({getPlayerResponse:()=>r}).request().audioLanguage,'en-us');
  r.streamingData.adaptiveFormats.push({audioTrack:{id:'es.2',audioIsDefault:true}});assert.equal(bridge({getPlayerResponse:()=>r}).request().audioLanguage,null);
  r.videoDetails.defaultAudioLanguage='en';assert.equal(bridge({getPlayerResponse:()=>r}).request().audioLanguage,null);delete r.videoDetails.defaultAudioLanguage;
  r.streamingData.adaptiveFormats=[{audioTrack:{id:'en.1',displayName:'English (original)'}},{audioTrack:{id:'es.2',displayName:'Spanish (original)'}}];assert.equal(bridge({getPlayerResponse:()=>r}).request().audioLanguage,null);
});
