import test from 'node:test';
import assert from 'node:assert/strict';
import {fillModels} from '../shared/model-select.js';
test('模型選單可選帳號提供的模型，不自動替換不可用的設定',()=>{
  globalThis.Option=class {constructor(text,value){this.text=text;this.value=value;}};
  const select={replaceChildren(...options){this.options=options;}},models=[{slug:'gpt-5.6-sol',display_name:'GPT-5.6-Sol'},{slug:'gpt-6-astra',display_name:'GPT-6-Astra'}];
  assert(fillModels(select,models,'gpt-5.6-sol'));assert.equal(select.value,'gpt-5.6-sol');assert.equal(select.disabled,false);assert.equal(select.options[1].value,'gpt-6-astra');
  assert(!fillModels(select,models,'unavailable'));assert.equal(select.value,'');assert(select.options[0].disabled);assert.equal(select.options[1].value,'gpt-5.6-sol');
  fillModels(select,[],'unavailable');assert.equal(select.disabled,true);delete globalThis.Option;
});
