import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {MSG} from '../shared/messages.js';
test('背景取消有等待上限，未回應的 Worker 終止後可重新續翻',async()=>{
  const source=(await readFile(new URL('../offscreen/offscreen.js',import.meta.url),'utf8')).replace(/^import[^\n]+\n/,''),timers=new Map(),workers=[];let listener,timerId=0;
  class Worker {constructor(){this.sent=[];this.terminated=false;workers.push(this);}postMessage(m){this.sent.push(m);}terminate(){this.terminated=true;}}
  const chrome={runtime:{id:'test',getURL:p=>`chrome-extension://test/${p}`,onMessage:{addListener:fn=>listener=fn},sendMessage:async()=>({ok:true})}};
  vm.runInNewContext(source,{MSG,chrome,Worker,setTimeout:(fn,ms)=>{assert.equal(ms,2500);timers.set(++timerId,fn);return timerId;},clearTimeout:id=>timers.delete(id)});
  const sender={id:'test',url:'chrome-extension://test/background/service-worker.js'},send=(type,payload={},respond=()=>{})=>listener({target:'offscreen',type,...payload},sender,respond),job={jobId:'prime-test'};
  send(MSG.RUN,{job});let acknowledged=0;send(MSG.ABORT,{jobId:job.jobId},()=>acknowledged++);assert.equal(workers[0].sent.at(-1).type,'abort');assert.equal(acknowledged,0);
  [...timers.values()][0]();assert(workers[0].terminated);assert.equal(acknowledged,1);
  send(MSG.RUN,{job});assert.equal(workers.length,2);assert.equal(workers[1].sent[0].type,'run');
  send(MSG.ABORT,{jobId:job.jobId},()=>acknowledged++);workers[1].onmessage({data:{type:'done',jobId:job.jobId}});assert.equal(acknowledged,2);assert(workers[1].terminated);
});
