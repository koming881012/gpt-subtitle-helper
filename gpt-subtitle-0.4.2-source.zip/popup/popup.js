import { MSG,send } from '../shared/messages.js';
import { ACTIVE_STATUSES } from '../shared/constants.js';
import { videoIdFromUrl } from '../shared/utils.js';
import { platformFromUrl } from '../shared/platforms.js';
import { $,modeOptions,tabMessage,showError,notice,bindAction } from '../shared/ui.js';
import { fillModels } from '../shared/model-select.js';
import {normalizeSubtitleOffset,subtitleOffsetLabel,MAX_SUBTITLE_OFFSET_MS} from '../shared/subtitle-timing.js';
let tabId=null,state=null,busy=false,modelsReady=false,modelsLoading=false,lastModelCheck=0;
let offsetEditing=false,offsetSaving=false,offsetTimer=null,offsetSequence=0;
let account=null,lastAccountId='';
modeOptions($('#mode'));
async function refresh() {
  if(!tabId)return;
  try {state=await send(MSG.STATE,{tabId});render();}catch(e){showError(e.message);}
}
function render() {
  if(!state){$('#status').textContent='請開啟 YouTube 或 Prime Video 影片頁面。';return;}
  $('#title').textContent=state.title || '正在偵測影片…';$('#platform').textContent=state.platform==='primevideo'||platformFromUrl(state.url)==='primevideo'?'Prime Video':'YouTube';
  const job=state.job,active=state.starting || ACTIVE_STATUSES.includes(job?.status);
  $('#status').textContent=state.error || job?.error || (active?job?.phase || '正在取得英文字幕…':state.hasCache?`✓ 翻譯完成\n字幕${state.pref.enabled?'已開啟':'已關閉'}`:job?.status==='cancelled'?'翻譯已取消，可繼續':!state.ready?'正在偵測 Player…':state.live?'第一版不支援直播':state.track?`✓ 偵測到${state.track.kind==='asr' || /^a\./.test(state.track.vssId)?'自動':'人工'}英文 CC`:'沒有可用的英文 CC');
  $('#controls').hidden=(!state.tracks?.length&&!state.hasPlayable&&!state.hasCache) || state.live;
  const select=$('#track'), signature=state.tracks.map(t=>t.sourceTrackId).join('|');
  if(select.dataset.signature!==signature){select.replaceChildren(...state.tracks.map(t=>new Option(`${t.name || t.languageCode}（${t.kind==='asr' || /^a\./.test(t.vssId)?'自動':'人工'}）`,t.sourceTrackId)));select.dataset.signature=signature;}
  select.value=state.track?.sourceTrackId || '';select.disabled=active||busy;
  $('#mode').value=state.pref.mode;$('#progress').hidden=!active;$('#progress').value=job?.progress || 0;
  $('#counts').textContent=job?.totalCues?`${job.translatedCues} / ${job.totalCues} 段 · ${job.progress}%`:'';
  if(state.partial&&active&&state.hasPlayable)$('#status').textContent=`中文字幕已可播放 · 目前位置已準備 ${state.bufferedSeconds} 秒\n其餘字幕在背景翻譯，無需等整片完成。`;
  if(state.waitingForSubtitles)$('#status').textContent='正在等待中文字幕緩衝，準備好後會自動播放…';
  if(state.playbackError)$('#status').textContent=state.playbackError;
  if(state.autoTranslateBlockedReason&&!active&&!state.hasCache&&!state.hasPlayable&&!state.job)$('#status').textContent=state.autoTranslateBlockedReason;
  if(state.nativeChinese)$('#status').textContent='影片已有原生中文字幕，已略過 GPT 翻譯。請在播放器選擇中文字幕。';
  const terms=state.diagnostics?.terminologyStatus;
  $('#terminology').textContent=terms==='searching'?'GPT-6 正在搜尋中文專有名詞，字幕先使用中文翻譯或音譯。':terms==='ready'?'GPT-6 術語搜尋完成，字幕將套用中文詞彙表。':terms==='failed'?(state.diagnostics?.warnings || []).find(w=>w.includes('術語搜尋未完成')) || 'GPT-6 術語搜尋未完成，目前使用中文翻譯或音譯。':'';
  $('#start').disabled=active||busy||!state.track||state.nativeChinese||(!account&&!state.hasCache);$('#start').textContent=state.hasCache?'顯示已儲存字幕':!account?.planEnabled?'先連接 ChatGPT':['error','cancelled'].includes(job?.status)?'繼續翻譯':'開始翻譯';
  $('#cancel').hidden=!active;$('#subtitleVisibility').hidden=!state.videoId;$('#toggle').textContent=state.pref.enabled?'關閉 AI 字幕':'開啟 AI 字幕';$('#toggle').disabled=busy;$('#toggle').setAttribute('aria-pressed',String(Boolean(state.pref.enabled)));$('#visibilityStatus').textContent=state.pref.enabled?'只控制顯示，不會停止翻譯。':'AI 字幕已關閉；翻譯可繼續進行。';$('#exports').hidden=!state.hasCache;
  $('#timing').hidden=state.nativeChinese&&!state.importedSubtitles;
  if(!offsetEditing)showOffset(state.pref.subtitleOffsetMs);
}
function showOffset(value,keepInput=false){const offset=normalizeSubtitleOffset(value);$('#subtitleOffset').value=String(offset/1000);if(!keepInput)$('#offsetSeconds').value=String(offset/1000);$('#offsetLabel').textContent=subtitleOffsetLabel(offset);$('#subtitleOffset').setAttribute('aria-valuetext',subtitleOffsetLabel(offset));}
function adjustOffset(seconds,immediate=false,keepInput=false){
  if(!state?.videoId)return;
  clearTimeout(offsetTimer);const sequence=++offsetSequence,videoId=state.videoId,value=Number(seconds)*1000;
  if(seconds===''||!Number.isFinite(value)||Math.abs(value)>MAX_SUBTITLE_OFFSET_MS){offsetEditing=false;offsetSaving=false;showError('請輸入 -600 至 600 秒，可使用小數。');return;}
  const subtitleOffsetMs=normalizeSubtitleOffset(value);offsetEditing=true;offsetSaving=true;showOffset(subtitleOffsetMs,keepInput);
  const save=async()=>{try{await tabMessage(tabId,MSG.CONTENT_PREF,{videoId,pref:{subtitleOffsetMs}});if(sequence===offsetSequence)notice('');}catch(e){if(sequence===offsetSequence)showError(e.message);}finally{if(sequence===offsetSequence){offsetSaving=false;offsetEditing=document.activeElement===$('#offsetSeconds');await refresh();}}};
  if(immediate)save();else offsetTimer=setTimeout(save,200);
}
$('#subtitleOffset').addEventListener('input',e=>adjustOffset(e.target.value));
$('#subtitleOffset').addEventListener('change',e=>adjustOffset(e.target.value,true));
$('#offsetSeconds').addEventListener('focus',()=>{offsetEditing=true;});
$('#offsetSeconds').addEventListener('input',e=>{offsetEditing=true;if(e.target.value!==''&&e.target.validity.valid)adjustOffset(e.target.value,false,true);else{clearTimeout(offsetTimer);offsetSequence++;offsetSaving=false;}});
$('#offsetSeconds').addEventListener('change',e=>adjustOffset(e.target.value,true));
$('#offsetSeconds').addEventListener('blur',()=>{if(!offsetSaving){offsetEditing=false;render();}});
$('#resetOffset').addEventListener('click',()=>adjustOffset(0,true));
async function action(type,payload={}) {busy=true;render();try{await tabMessage(tabId,type,payload);notice('');}finally{busy=false;await refresh();}}
bindAction($('#start'),()=>!account?.planEnabled&&!state.hasCache?signIn():action(MSG.CONTENT_START));bindAction($('#cancel'),()=>action(MSG.CANCEL));
bindAction($('#toggle'),()=>action(MSG.CONTENT_PREF,{pref:{enabled:!state.pref.enabled}}));
bindAction($('#options'),()=>send(MSG.OPTIONS));
bindAction($('#setup'),()=>send(MSG.OPTIONS));
async function signIn(){if(account?.companionReady===false){await send(MSG.OPTIONS);return;}const button=$('#signIn');button.disabled=true;notice('正在開啟 OpenAI 登入…');try{await send(MSG.SIGN_IN,{enablePlan:account?.signedIn&&!account.planEnabled});notice('請在新分頁完成登入與授權，完成後回到影片即可。');}finally{button.disabled=false;}}
bindAction($('#signIn'),signIn);
function renderAccount(){const connected=Boolean(account?.planEnabled);$('#accountCard').classList.toggle('connected',connected);$('#accountBadge').classList.toggle('connected',connected);$('#accountTitle').textContent=connected?'ChatGPT 已連接':'連接你的 ChatGPT';$('#accountStatus').textContent=connected?`${account.account?.email||'目前帳號'} · 可使用方案用量`:account?.error||(account?.signedIn?'已登入，請授權使用 ChatGPT 方案。':'登入一次，之後開啟影片即可翻譯。');$('#signIn').hidden=connected;$('#signIn').disabled=false;$('#signIn').textContent=account?.companionReady===false?'查看安裝步驟':account?.signedIn?'授權使用 ChatGPT 方案':'Continue with ChatGPT';$('#setup').hidden=true;$('#accountHelp').hidden=connected;}
async function loadModels() {
  if(modelsLoading)return;modelsLoading=true;lastModelCheck=Date.now();
  try {
  account=await send(MSG.AUTH_STATUS);renderAccount();render();
  const accountId=account.account?.id||'';if(accountId!==lastAccountId){modelsReady=false;lastAccountId=accountId;}
  if(modelsReady&&account.planEnabled)return;
  const s=await send(MSG.SETTINGS);$('#reasoningEffort').value=s.reasoningEffort;$('#keyHint').textContent=`模型：${s.model}`;
  if(!account.planEnabled){modelsReady=false;$('#model').replaceChildren(new Option('登入後讀取可用模型',''));$('#model').disabled=true;$('#saveModel').disabled=true;$('#modelStatus').textContent='完成 ChatGPT 授權後即可調整。';return;}
  try {const models=await send(MSG.MODELS);const valid=fillModels($('#model'),models,s.model);modelsReady=true;$('#saveModel').disabled=!$('#model').value;$('#modelStatus').textContent=valid?'可直接選擇並套用帳號可用模型。':'目前模型不可用，請從選單選擇。';}
  catch(e){modelsReady=false;$('#modelStatus').textContent=e.message;$('#saveModel').disabled=true;}
  }finally{modelsLoading=false;}
}
$('#model').addEventListener('change',()=>{$('#saveModel').disabled=!$('#model').value;});
bindAction($('#saveModel'),async()=>{if(ACTIVE_STATUSES.includes(state?.job?.status)||state?.starting)throw new Error('請先取消目前翻譯，再更換模型。');const s=await send(MSG.SETTINGS);delete s.hasConnection;await send(MSG.SAVE,{settings:{...s,model:$('#model').value,reasoningEffort:$('#reasoningEffort').value}});modelsReady=false;await loadModels();await refresh();notice('模型已套用；未完成部分使用新設定繼續翻譯。');});
for(const format of ['srt','vtt','json'])bindAction($(`#${format}`),()=>action(MSG.EXPORT,{format,language:$('#language').value}));
$('#loadFile').addEventListener('click',()=>$('#subtitleFile').click());
$('#subtitleFile').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;if(file.size>10000000)throw new Error('字幕檔不可超過 10 MB。');await action(MSG.IMPORT_FILE,{filename:file.name,raw:await file.text()});notice('已載入本機字幕，不使用 GPT 額度。');}catch(e){showError(e.message);}finally{e.target.value='';}});
$('#mode').addEventListener('change',()=>action(MSG.CONTENT_PREF,{pref:{mode:$('#mode').value}}).catch(e=>showError(e.message)));
$('#track').addEventListener('change',()=>action(MSG.CONTENT_PREF,{sourceTrackId:$('#track').value}).catch(e=>showError(e.message)));
chrome.runtime.onMessage.addListener(m=>{if(m.target==='ui' && m.type===MSG.UPDATE)refresh();});
(async()=>{try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!videoIdFromUrl(tab?.url)&&platformFromUrl(tab?.url)!=='primevideo'){$('#title').textContent='';$('#status').textContent='請開啟 YouTube 或 Prime Video 影片頁面。';}else{tabId=tab.id;await refresh();}await loadModels();}catch(e){showError(e.message);}})();
const timer=setInterval(()=>{refresh();if(!modelsLoading&&Date.now()-lastModelCheck>=5000)loadModels().catch(e=>showError(e.message));},1000);window.addEventListener('pagehide',()=>clearInterval(timer));
