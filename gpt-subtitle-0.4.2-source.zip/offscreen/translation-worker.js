import { translateJob } from '../translation/translator.js';
import { requestJSON } from '../translation/openai-client.js';
let controller,activeJob;
self.onmessage=async({data})=>{
  if(data.type==='test') {
    try {const result=await requestJSON({connectionCode:data.connectionCode,settings:data.settings,instructions:'Reply with ok true.',input:'Connection test.',schema:{type:'object',properties:{ok:{type:'boolean'}},required:['ok'],additionalProperties:false},name:'connection_test',signal:AbortSignal.timeout(60000),config:{maxRetries:0,timeoutMs:60000}});if(result.ok!==true)throw new Error('ChatGPT 回應不符合測試格式。');self.postMessage({type:'test-done',ok:true});}
    catch(e){self.postMessage({type:'test-done',ok:false,error:String(e.message).slice(0,700)});}return;
  }
  if(data.type==='abort'){controller?.abort();return;}
  if(data.type==='priority'){if(activeJob&&Number.isFinite(data.playheadMs))activeJob.playheadMs=data.playheadMs;return;}
  if(data.type!=='run' || controller)return;
  controller=new AbortController();activeJob=data.job;
  try {await translateJob(data.job,data.connectionCode,controller.signal,p=>self.postMessage({type:'checkpoint',...p}));}
  finally {self.postMessage({type:'done',jobId:data.job.jobId});}
};
