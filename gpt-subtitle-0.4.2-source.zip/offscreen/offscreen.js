import { MSG } from '../shared/messages.js';
const workers=new Map();
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(sender.id!==chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('background/')) || message.target!=='offscreen')return;
  if(message.type===MSG.PING){respond({ok:true,data:{jobIds:[...workers.keys()]}});return;}
  if(message.type===MSG.PRIORITY){workers.get(message.jobId)?.worker.postMessage({type:'priority',playheadMs:message.playheadMs});respond({ok:true});return;}
  if(message.type===MSG.TEST) {
    const worker=new Worker(chrome.runtime.getURL('offscreen/translation-worker.js'),{type:'module'});
    worker.onmessage=({data})=>{if(data.type==='test-done'){respond(data);worker.terminate();}};
    worker.onerror=()=>{respond({ok:false,error:'連線測試 Worker 無法執行，請重新載入擴充功能。'});worker.terminate();};
    worker.postMessage({type:'test',connectionCode:message.connectionCode,settings:message.settings});return true;
  }
  if(message.type===MSG.ABORT){
    const entry=workers.get(message.jobId);if(!entry){respond({ok:true});return;}
    entry.cancelWaiters.push(respond);entry.worker.postMessage({type:'abort'});
    entry.abortTimer ||= setTimeout(()=>{entry.worker.terminate();workers.delete(message.jobId);entry.cancelWaiters.splice(0).forEach(reply=>reply({ok:true}));},2500);
    return true;
  }
  if(message.type!==MSG.RUN)return;
  if(workers.has(message.job.jobId)){respond({ok:true});return;}
  const worker=new Worker(chrome.runtime.getURL('offscreen/translation-worker.js'),{type:'module'});
  const entry={worker,cancelWaiters:[]};workers.set(message.job.jobId,entry);
  worker.onmessage=({data})=>{
    if(data.type==='done'){clearTimeout(entry.abortTimer);worker.terminate();workers.delete(data.jobId);entry.cancelWaiters.splice(0).forEach(reply=>reply({ok:true}));}
    chrome.runtime.sendMessage({type:MSG.CHECKPOINT,jobId:data.jobId,workerError:null}).catch(()=>{});
  };
  worker.onerror=()=>{clearTimeout(entry.abortTimer);workers.delete(message.job.jobId);worker.terminate();entry.cancelWaiters.splice(0).forEach(reply=>reply({ok:true}));chrome.runtime.sendMessage({type:MSG.CHECKPOINT,jobId:message.job.jobId,workerError:'背景翻譯意外中止，已保留進度，請按繼續翻譯。'}).catch(()=>{});};
  worker.postMessage({type:'run',job:message.job,connectionCode:message.connectionCode});respond({ok:true});
});
// A restored offscreen document asks the orchestrator to recover persisted jobs.
chrome.runtime.sendMessage({type:MSG.RECOVER}).catch(()=>{});
