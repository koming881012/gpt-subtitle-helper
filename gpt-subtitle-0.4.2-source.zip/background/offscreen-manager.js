import { MSG } from '../shared/messages.js';
let creating;
export async function ensureOffscreen() {
  if(creating) return creating;
  creating=(async()=>{
    const contexts=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[chrome.runtime.getURL('offscreen/offscreen.html')]});
    if(!contexts.length) await chrome.offscreen.createDocument({url:'offscreen/offscreen.html',reasons:['WORKERS'],justification:'在 Web Worker 中執行可持續、可取消的字幕翻譯及斷點保存。'});
    // Document creation resolves before module initialization in some Chrome versions.
    for(let i=0;i<20;i++) {try {const r=await chrome.runtime.sendMessage({target:'offscreen',type:MSG.PING});if(r?.ok)return;}catch{/* Wait for packaged module to initialize. */}await new Promise(r=>setTimeout(r,100));}
    throw new Error('背景翻譯視窗初始化失敗，請重新載入擴充功能。');
  })();
  try {await creating;} finally {creating=null;}
}
