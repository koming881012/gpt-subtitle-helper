import { listRecords, getRecord, putRecord } from './storage.js';
import { ACTIVE_STATUSES } from '../shared/constants.js';
import { publicTrack } from '../shared/utils.js';
export function publicJob(job) {
  if(!job) return null;
  const {jobId,videoId,sourceTrackId,status,totalCues,translatedCues,progress,createdAt,updatedAt,error,phase,model,promptVersion,warnings,playableCues,bufferedSeconds,terminologyStatus,firstBatchMs}=job;
  return {jobId,videoId,sourceTrackId,status,totalCues,translatedCues,progress,createdAt,updatedAt,error,phase,model,promptVersion,warnings,playableCues,bufferedSeconds,terminologyStatus,firstBatchMs,sourceTrack:publicTrack(job.sourceTrack)};
}
export async function findJob(videoId,sourceTrackId,key) {return (await listRecords('jobs')).filter(j=>j.videoId===videoId && (!sourceTrackId || j.sourceTrackId===sourceTrackId) && (!key || j.cacheKey===key)).sort((a,b)=>b.updatedAt-a.updatedAt)[0] || null;}
export async function saveJob(job) {job.updatedAt=Date.now();await putRecord('jobs',job);return job;}
export async function patchJob(jobId,patch) {const j=await getRecord('jobs',jobId);if(!j)throw new Error('找不到翻譯工作。');return saveJob({...j,...patch});}
export const activeJobs=async()=>(await listRecords('jobs')).filter(j=>ACTIVE_STATUSES.includes(j.status));
