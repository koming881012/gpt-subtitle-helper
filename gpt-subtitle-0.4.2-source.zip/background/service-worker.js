import { DEFAULT_SETTINGS, translationVersion, ACTIVE_STATUSES, normalizeSettings } from '../shared/constants.js';
import {selectCache} from './cache-selection.js';
import { MSG } from '../shared/messages.js';
import { cacheKey, trackId, videoIdFromUrl, userError } from '../shared/utils.js';
import { englishTracks,nativeChineseTracks } from '../content/caption-detector.js';
import { validateCaptionUrl, fetchCaptionSource } from '../content/caption-fetcher.js';
import { getRecord, listRecords, putRecord, clearCache, cacheStats } from './storage.js';
import { publicJob, findJob, saveJob, patchJob, activeJobs } from './job-manager.js';
import { ensureOffscreen } from './offscreen-manager.js';
import { companionRequest,COMPANION_URL,requireCompanion } from '../shared/companion.js';
import { VIDEO_PATTERNS,platformFromUrl,isPrimeVideoId,validatePrimeCaptionUrl } from '../shared/platforms.js';
import { parseCaptions } from '../content/caption-parser.js';
import {parseSubtitleFile} from '../export/subtitle-file.js';
import {safeFilename} from '../shared/utils.js';
import {normalizeSubtitleOffset,MAX_SUBTITLE_OFFSET_MS} from '../shared/subtitle-timing.js';
import {HANDOFF_KEY,connectionUrl,validateHandoff} from '../shared/connection-handoff.js';
import {COMPLETE_CONNECTION} from '../shared/messages.js';
const promptVersion=translationVersion;
function validateSource(track,meta,source) {
  if(!isPrimeVideoId(meta.videoId)){validateCaptionUrl(track.baseUrl,meta.videoId);return;}
  validatePrimeCaptionUrl(track.baseUrl);
  if(!source||source.format!=='primevideo-timed-captions'||typeof source.raw!=='string'||source.raw.length>10000000)throw new Error('請回到 Prime Video 播放頁取得英文字幕後再開始。');
  parseCaptions(source.raw,meta.duration);
}
let mutations=Promise.resolve(),recovering;
const serial=fn=>{const next=mutations.then(fn,fn);mutations=next.catch(()=>{});return next;};
const trusted=sender=>sender.id===chrome.runtime.id && typeof sender.url==='string' && sender.url.startsWith(chrome.runtime.getURL(''));
const offscreenSender=sender=>trusted(sender) && sender.url===chrome.runtime.getURL('offscreen/offscreen.html');
async function settings() {
  const s=await chrome.storage.local.get(['settings','modelChoiceVersion']);
  const value=normalizeSettings(s.settings || DEFAULT_SETTINGS);
  // 使用者本次指定 Luna / medium；只遷移一次，之後保留使用者自行選擇。
  if((s.modelChoiceVersion||0)<2){Object.assign(value,{model:DEFAULT_SETTINGS.model,reasoningEffort:'medium',terminologyEnabled:false});await chrome.storage.local.set({settings:value,modelChoiceVersion:2});}
  return value;
}
async function connectionCode() {return (await chrome.storage.local.get('connectionCode')).connectionCode || '';}
async function authStatus() {const code=await connectionCode();if(!code){try{await requireCompanion({attempts:1});return {signedIn:false,planEnabled:false,companionReady:true};}catch{return {signedIn:false,planEnabled:false,companionReady:false,error:'請先安裝並啟動 Windows 連線助手，再按登入。'};}}try{return {...await companionRequest('/status',code),companionReady:true};}catch(e){return {signedIn:false,planEnabled:false,companionReady:e.status===401,error:e.status===401?'本機連線需要重新連接，按登入即可修復。':e.message};}}
async function requirePlan() {const code=await connectionCode(),a=await authStatus();if(!a.planEnabled)throw new Error(a.error||'請先在設定使用 ChatGPT 登入並授權方案額度。');return code;}
async function modelCatalog() {const code=await requirePlan();const r=await companionRequest('/models',code);return (r.models||[]).filter(m=>m.visibility==='list').map(m=>({slug:m.slug,display_name:m.display_name}));}
async function pref(videoId) {
  const key=`pref:${videoId}`,value=(await chrome.storage.local.get(key))[key] || {enabled:true};
  if(!value.subtitleModeVersion){Object.assign(value,{mode:'zh',subtitleModeVersion:1});await chrome.storage.local.set({[key]:value});}
  value.subtitleOffsetMs=normalizeSubtitleOffset(value.subtitleOffsetMs);
  return value;
}
async function broadcast(type,data) {
  const tabs=await chrome.tabs.query({url:VIDEO_PATTERNS});
  await Promise.allSettled(tabs.map(t=>chrome.tabs.sendMessage(t.id,{type,...data})));
  chrome.runtime.sendMessage({type,target:'ui',...data}).catch(()=>{});
}
async function run(job) {
  const code=await requirePlan();
  if(job.accountId&&(await authStatus()).account?.id!==job.accountId)throw new Error('此工作屬於另一個 ChatGPT 帳號，請切回原帳號再繼續。');
  const models=await modelCatalog();if(!models.some(m=>m.slug===job.settings.model))throw new Error(`帳號目前無法使用 ${job.settings.model}，請在插件小視窗選擇可用模型並按「套用模型」。`);
  await ensureOffscreen();
  const r=await chrome.runtime.sendMessage({target:'offscreen',type:MSG.RUN,job,connectionCode:code});
  if(!r?.ok)throw new Error('背景翻譯無法啟動。');
}
async function recover() {
  if(recovering)return recovering;
  recovering=(async()=>{
    for(const job of await activeJobs()) {
      const current=await settings();job.modelsUsed=[...new Set([...(job.modelsUsed||[job.model]),current.model])];job.settings=current;job.model=current.model;await saveJob(job);
      try {await run(job);}catch(e){await patchJob(job.jobId,{status:'error',error:userError(e),phase:'翻譯中斷，可繼續'});}
    }
  })();
  try{await recovering;}finally{recovering=null;}
}
async function activeVideoTab(tabId) {
  if(tabId) {const tab=await chrome.tabs.get(tabId);if(videoIdFromUrl(tab.url)||platformFromUrl(tab.url)==='primevideo')return tab;throw new Error('請開啟 YouTube 或 Prime Video 影片頁面。');}
  const all=await chrome.tabs.query({url:VIDEO_PATTERNS});
  return all.filter(t=>videoIdFromUrl(t.url)).sort((a,b)=>Number(b.active)-Number(a.active)||(b.lastAccessed||0)-(a.lastAccessed||0))[0];
}
async function verifyContent(sender,videoId) {
  let origin;try{origin=new URL(sender.url || sender.tab?.url).origin;}catch{}
  if(!sender.tab || sender.id!==chrome.runtime.id || !platformFromUrl(origin) || (sender.frameId!==undefined && sender.frameId!==0))throw new Error('不允許的影片訊息來源。');
  // SPA 導航後 sender.url 可能仍是注入時網址，必須核對目前分頁網址。
  const current=await chrome.tabs.get(sender.tab.id);
  if(platformFromUrl(origin)==='primevideo'){
    if(platformFromUrl(current.url)!=='primevideo'||!isPrimeVideoId(videoId))throw new Error('目前影片已切換，請重新操作。');
    const response=await chrome.tabs.sendMessage(sender.tab.id,{type:MSG.CONTENT_STATE});
    if(response?.data?.videoId!==videoId)throw new Error('目前 Prime Video 影片已切換，請重新操作。');
    return;
  }
  if(videoIdFromUrl(current.url)!==videoId)throw new Error('目前影片已切換，請重新操作。');
}
async function lookup(meta,track) {
  const s=await settings(), ck=cacheKey({...meta,promptVersion:promptVersion(meta)},track||{},s);
  const active=(await activeJobs()).find(j=>j.videoId===meta.videoId);
  const cache=selectCache(await listRecords('cache'),meta,track,ck);
  return {cache,job:publicJob(active || await findJob(meta.videoId,null,cache?.key||ck)),pref:await pref(meta.videoId),settings:{...s,hasConnection:Boolean(await connectionCode())}};
}
async function start(message,sender) {
  const {meta,track}=message;await verifyContent(sender,meta?.videoId);
  if(nativeChineseTracks(meta.captionTracks).length)throw new Error('影片已有原生中文字幕，已略過 GPT 翻譯。請在播放器選擇中文字幕。');
  if(meta.isLive)throw new Error('第一版不支援直播或直播錄影字幕。');
  if(!englishTracks([track]).length)throw new Error('這支影片沒有可用英文 CC。');
  const version=promptVersion(meta),s=await settings(), ck=cacheKey({...meta,promptVersion:version},track,s);
  const cached=selectCache(await listRecords('cache'),meta,track,ck);if(cached&&!cached.partial)return {cache:cached};
  const active=(await activeJobs()).find(j=>j.videoId===meta.videoId);if(active)return {job:publicJob(active)};
  const previous=await findJob(meta.videoId,null,cached?.key||ck);
  if(previous&&previous.status!=='completed')return resume({...message,jobId:previous.jobId},sender);
  if(!cached?.sourceCues?.length)validateSource(track,meta,message.source);
  await requirePlan();
  const job={jobId:crypto.randomUUID(),platform:isPrimeVideoId(meta.videoId)?'primevideo':'youtube',videoId:meta.videoId,title:String(meta.title).slice(0,500),duration:Number(meta.duration),sourceTrack:track,sourceTrackId:trackId(track),cacheKey:ck,model:s.model,promptVersion:version,settings:s,status:'fetching',totalCues:0,translatedCues:0,progress:0,phase:'正在取得英文字幕…',createdAt:Date.now(),updatedAt:Date.now(),error:null,results:{},prefetchedSource:message.source || null};
  if(cached?.partial&&cached.sourceCues?.length){Object.assign(job,{cacheKey:cached.key,promptVersion:cached.promptVersion,sourceCues:cached.sourceCues,rawSource:cached.rawSource,cacheRevision:cached.revision||0,prefetchedSource:null,glossary:cached.glossary||[]});if(cached.translatedCues.some(c=>Number.isInteger(c.startWord))){job.wordRanges=cached.translatedCues.map(c=>({start:c.startWord,end:c.endWord}));job.sentenceCues=cached.translatedCues;}else job.results=Object.fromEntries(cached.translatedCues.map(c=>[c.id,c.zh]));}
  job.accountId=(await authStatus()).account?.id;
  job.playheadMs=Number.isFinite(message.playheadMs)?Math.max(0,Math.min(meta.duration*1000,message.playheadMs)):0;
  await saveJob(job);
  try{await run(job);}catch(e){await patchJob(job.jobId,{status:'error',error:userError(e),phase:'背景工作啟動失敗'});throw e;}
  await broadcast(MSG.UPDATE,{videoId:job.videoId,job:publicJob(job)});return {job:publicJob(job)};
}
async function resume(message,sender) {
  const job=await getRecord('jobs',message.jobId);if(!job)throw new Error('找不到可繼續的翻譯工作。');
  if(!trusted(sender))await verifyContent(sender,job.videoId);
  if(message.meta?.videoId===job.videoId&&nativeChineseTracks(message.meta.captionTracks).length)throw new Error('影片已有原生中文字幕，已略過 GPT 翻譯。請在播放器選擇中文字幕。');
  if(job.status==='completed')return {job:publicJob(job)};
  const active=(await activeJobs()).find(j=>j.videoId===job.videoId && j.jobId!==job.jobId);if(active)throw new Error('這支影片已有翻譯工作進行中。');
  await requirePlan();
  if(ACTIVE_STATUSES.includes(job.status))return {job:publicJob(job)};
  const nextSettings=await settings();job.modelsUsed=[...new Set([...(job.modelsUsed||[job.model]),nextSettings.model])];job.settings=nextSettings;job.model=nextSettings.model;
  if(!trusted(sender) && message.track && trackId(message.track)===job.sourceTrackId) {if(isPrimeVideoId(job.videoId)){validatePrimeCaptionUrl(message.track.baseUrl);if(!job.sourceCues?.length)validateSource(message.track,job,message.source);}else validateCaptionUrl(message.track.baseUrl,job.videoId);job.sourceTrack=message.track;}
  if(!job.sourceCues?.length && message.source)job.prefetchedSource=message.source;
  if(Number.isFinite(message.playheadMs))job.playheadMs=Math.max(0,Math.min(job.duration*1000,message.playheadMs));
  Object.assign(job,{status:job.sourceCues?.length?'translating':'fetching',error:null,phase:'正在繼續翻譯…'});await saveJob(job);
  try{await run(job);}catch(e){await patchJob(job.jobId,{status:'error',error:userError(e)});throw e;}
  return {job:publicJob(job)};
}
export async function route(m,sender) {
  if(m.target==='offscreen' || m.target==='ui')return undefined;
  if(sender.id!==chrome.runtime.id)throw new Error('不允許的訊息來源。');
  const t=trusted(sender);
  if(m.type===MSG.CHECKPOINT) {
    if(!offscreenSender(sender))throw new Error('不允許的背景通知。');
    let job=await getRecord('jobs',m.jobId);if(!job)return;
    if(m.workerError)job=await patchJob(job.jobId,{status:'error',error:m.workerError});
    if(job.status==='completed')await serial(async()=>{const p=await pref(job.videoId);await chrome.storage.local.set({[`pref:${job.videoId}`]:{...p,sourceTrackId:job.sourceTrackId}});});
    await broadcast(MSG.UPDATE,{videoId:job.videoId,job:publicJob(job)});return publicJob(job);
  }
  if(m.type===MSG.RECOVER) {if(!offscreenSender(sender))throw new Error('不允許的背景通知。');recover().catch(console.error);return true;}
  if(m.type===MSG.SETTINGS)return {...await settings(),hasConnection:Boolean(await connectionCode())};
  if(m.type===MSG.OPTIONS){await chrome.runtime.openOptionsPage();return true;}
  if(m.type===MSG.LOOKUP) {await verifyContent(sender,m.meta?.videoId);return lookup(m.meta,m.track);}
  if(m.type===MSG.START)return serial(()=>start(m,sender));
  if(m.type===MSG.RESUME)return serial(()=>resume(m,sender));
  if(m.type===MSG.PRIORITY) {
    const job=await getRecord('jobs',m.jobId);if(!job)return false;await verifyContent(sender,job.videoId);
    if(!ACTIVE_STATUSES.includes(job.status)||!Number.isFinite(m.playheadMs))return false;
    const playheadMs=Math.max(0,Math.min(job.duration*1000,m.playheadMs));
    await chrome.runtime.sendMessage({target:'offscreen',type:MSG.PRIORITY,jobId:job.jobId,playheadMs});return true;
  }
  if(m.type===MSG.PREF) {
    return serial(async()=>{
    if(!t)await verifyContent(sender,m.videoId);
    const p={...await pref(m.videoId),...m.pref};
    if(!['zh','en','both-zh','both-en','split-en','split-zh'].includes(p.mode))throw new Error('字幕顯示模式不正確。');
    if(!Number.isFinite(p.subtitleOffsetMs)||Math.abs(p.subtitleOffsetMs)>MAX_SUBTITLE_OFFSET_MS)throw new Error('字幕時間調整必須介於提前 10 分鐘與延後 10 分鐘。');
    p.subtitleOffsetMs=normalizeSubtitleOffset(p.subtitleOffsetMs);
    await chrome.storage.local.set({[`pref:${m.videoId}`]:{enabled:Boolean(p.enabled),mode:p.mode,sourceTrackId:p.sourceTrackId,subtitleModeVersion:1,subtitleOffsetMs:p.subtitleOffsetMs}});await broadcast(MSG.PREF_CHANGED,{videoId:m.videoId,pref:p});return p;
    });
  }
  if(m.type===MSG.FETCH) {await verifyContent(sender,m.videoId);if(isPrimeVideoId(m.videoId))throw new Error('Prime Video 字幕由目前播放器取得。');return fetchCaptionSource(m.track,m.videoId,AbortSignal.timeout(30000));}
  if(m.type===MSG.CANCEL) {
    const j=await getRecord('jobs',m.jobId);if(!j)throw new Error('找不到翻譯工作。');if(!t)await verifyContent(sender,j.videoId);
    if(!ACTIVE_STATUSES.includes(j.status))return publicJob(j);
    await ensureOffscreen();await chrome.runtime.sendMessage({target:'offscreen',type:MSG.ABORT,jobId:j.jobId});
    const current=await getRecord('jobs',j.jobId);
    if(current.status!=='completed' && current.status!=='cancelled')await patchJob(j.jobId,{status:'cancelled',phase:'翻譯已取消，可繼續',error:null});
    await broadcast(MSG.UPDATE,{videoId:j.videoId,job:publicJob(await getRecord('jobs',j.jobId))});return true;
  }
  if(m.type===MSG.IMPORT_FILE){await verifyContent(sender,m.meta?.videoId);return serial(async()=>{
    const cues=parseSubtitleFile(m.raw,m.format,m.meta);for(const j of await activeJobs())if(j.videoId===m.meta.videoId)await route({type:MSG.CANCEL,jobId:j.jobId},sender);
    const cache={key:`local-file:${m.meta.videoId}`,videoId:m.meta.videoId,title:String(m.meta.title||'').slice(0,500),platform:platformFromUrl(sender.tab.url||sender.url),imported:true,partial:false,translatedCues:cues,sourceCues:cues.map(c=>({...c,text:c.en||c.zh})),translatedAt:Date.now(),revision:Date.now(),warnings:[]};await putRecord('cache',cache);await broadcast(MSG.INVALIDATE,{videoId:m.meta.videoId});return {cache};
  });}
  if(m.type===MSG.SAVE_FILE){await verifyContent(sender,m.videoId);if(!['srt','vtt','json'].includes(m.format)||typeof m.raw!=='string'||m.raw.length>10000000)throw new Error('字幕檔格式或大小不正確。');const language=['zh-TW','en','bilingual'].includes(m.language)?m.language:'zh-TW',filename=`${safeFilename(m.title)}.${m.format==='json'?'ytgpt':language}.${m.format}`;return chrome.downloads.download({url:`data:application/octet-stream;charset=utf-8,${encodeURIComponent(m.raw)}`,filename,saveAs:true});}
  if(!t)throw new Error('此操作只允許擴充功能設定頁面。');
  if(m.type===MSG.STATE || m.type===MSG.DIAG) {
    const tab=await activeVideoTab(m.tabId);if(!tab)return null;
    try{return (await chrome.tabs.sendMessage(tab.id,{type:MSG.CONTENT_STATE}))?.data || null;}catch{throw new Error('請重新整理影片頁面以載入擴充功能。');}
  }
  if(m.type===MSG.SAVE) {const before=await settings(),s=normalizeSettings(m.settings);await chrome.storage.local.set({settings:s});await broadcast(MSG.SETTINGS_CHANGED,{settings:s,cacheIdentityChanged:before.model!==s.model || before.reasoningEffort!==s.reasoningEffort || before.terminologyModel!==s.terminologyModel});return s;}
  if(m.type===MSG.LIST_JOBS)return (await listRecords('jobs')).sort((a,b)=>b.updatedAt-a.updatedAt).map(publicJob);
  if(m.type===MSG.CONNECT) {if((await activeJobs()).length)throw new Error('請先取消背景翻譯再更換連線碼。');if(typeof m.connectionCode!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(m.connectionCode.trim()))throw new Error('請貼上本機程式提供的連線碼。');await companionRequest('/status',m.connectionCode.trim());await chrome.storage.local.set({connectionCode:m.connectionCode.trim()});return authStatus();}
  if(m.type===MSG.AUTH_STATUS)return authStatus();
  if(m.type===MSG.LOCAL_PAGE){await requireCompanion();await chrome.tabs.create({url:COMPANION_URL});return true;}
  if(m.type===MSG.SIGN_IN){if((await activeJobs()).length)throw new Error('請先取消背景翻譯再登入其他帳號。');await requireCompanion();let code=await connectionCode();if(code){try{await companionRequest('/status',code);}catch(e){if(e.status!==401)throw e;code='';}}if(!code){const request=crypto.randomUUID(),tab=await chrome.tabs.create({url:'about:blank'});try{await chrome.storage.session.set({[HANDOFF_KEY]:{request,tabId:tab.id,expiresAt:Date.now()+5*60*1000,newAccount:Boolean(m.newAccount),enablePlan:Boolean(m.enablePlan)}});await chrome.tabs.update(tab.id,{url:connectionUrl(chrome.runtime.id,request)});}catch(e){await chrome.storage.session.remove(HANDOFF_KEY);await chrome.tabs.remove(tab.id);throw e;}return true;}const r=await companionRequest('/auth/start',code,{newAccount:Boolean(m.newAccount),enablePlan:Boolean(m.enablePlan)});if(new URL(r.url).origin!=='https://auth.openai.com')throw new Error('登入網址不符。');await chrome.tabs.create({url:r.url});return true;}
  if(m.type===MSG.SELECT_ACCOUNT){if((await activeJobs()).length)throw new Error('請先取消背景翻譯再切換帳號。');return companionRequest('/auth/select',await connectionCode(),{id:m.id});}
  if(m.type===MSG.SIGN_OUT){if((await activeJobs()).length)throw new Error('請先取消背景翻譯再登出。');return companionRequest('/auth/logout',await connectionCode());}
  if(m.type===MSG.MODELS)return modelCatalog();
  if(m.type===MSG.TEST) {
    const code=await requirePlan(),s=await settings();const models=await modelCatalog();if(!models.some(x=>x.slug===s.model))throw new Error('目前 ChatGPT 帳號無法使用這個模型，請到設定更換模型。');
    await ensureOffscreen();
    const result=await chrome.runtime.sendMessage({target:'offscreen',type:MSG.TEST,connectionCode:code,settings:await settings()});
    if(!result?.ok)throw new Error(result?.error || 'API 連線測試失敗。');return true;
  }
  if(m.type===MSG.STATS)return cacheStats();
  if(m.type===MSG.CLEAR) {
    return serial(async()=>{const tab=m.current?await activeVideoTab(m.tabId):null,videoId=tab?(platformFromUrl(tab.url)==='primevideo'?(await chrome.tabs.sendMessage(tab.id,{type:MSG.CONTENT_STATE}))?.data?.videoId:videoIdFromUrl(tab.url)):null;if(m.current&&!videoId)throw new Error('找不到目前影片。');if((await activeJobs()).some(j=>!videoId||j.videoId===videoId))throw new Error('請先取消相關翻譯工作再清除快取。');await clearCache(videoId);await broadcast(MSG.INVALIDATE,{videoId});return true;});
  }
  throw new Error('未知的擴充功能訊息。');
}
export async function completeConnection(message,sender) {
  return serial(async()=>{
    const pending=(await chrome.storage.session.get(HANDOFF_KEY))[HANDOFF_KEY];
    validateHandoff(message,sender,pending,chrome.runtime.id);
    if((await activeJobs()).length)throw new Error('請先取消背景翻譯再重新連接。');
    await companionRequest('/status',message.connectionCode);
    await chrome.storage.local.set({connectionCode:message.connectionCode});
    await chrome.storage.session.remove(HANDOFF_KEY);
    const result=await companionRequest('/auth/start',message.connectionCode,{newAccount:pending.newAccount,enablePlan:pending.enablePlan});
    if(new URL(result.url).origin!=='https://auth.openai.com')throw new Error('登入網址不符。');
    return {url:result.url};
  });
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message.target==='offscreen' || message.target==='ui')return;
  (message.type===COMPLETE_CONNECTION?completeConnection(message,sender):route(message,sender)).then(data=>respond({ok:true,data})).catch(e=>respond({ok:false,error:userError(e)}));return true;
});
chrome.runtime.onInstalled.addListener(details=>{chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});chrome.storage.local.remove('apiKey');recover().catch(console.error);if(details.reason==='install')chrome.runtime.openOptionsPage().catch(console.error);});
chrome.runtime.onStartup.addListener(()=>recover().catch(console.error));
chrome.commands.onCommand.addListener(async command=>{const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});if(tab?.id)chrome.tabs.sendMessage(tab.id,{type:MSG.CONTENT_PREF,command}).catch(()=>{});});
chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(console.error);
recover().catch(console.error);
