import {trackId} from '../shared/utils.js';
const kind=t=>t?.kind==='asr'||/^a\./.test(t?.vssId||'')?'asr':'manual';
export function compatibleTrack(a,b) {
  if(!a||!b)return false;
  return a.languageCode?.toLowerCase()===b.languageCode?.toLowerCase()&&kind(a)===kind(b)&&(a.vssId&&b.vssId?a.vssId===b.vssId:trackId(a)===trackId(b));
}
export function selectCache(records,meta,track,key) {
  const candidates=records.filter(r=>r.videoId===meta.videoId&&r.translatedCues?.length&&(r.imported||!track||compatibleTrack(r.sourceTrack,track)));
  return candidates.sort((a,b)=>Number(Boolean(b.imported))-Number(Boolean(a.imported))||Number(!b.partial)-Number(!a.partial)||Number(b.key===key)-Number(a.key===key)||(b.translatedCues.length-a.translatedCues.length)||(b.translatedAt||0)-(a.translatedAt||0))[0]||null;
}
