let dbPromise;
export function openDB() {
  if(!dbPromise) dbPromise=new Promise((resolve,reject)=>{
    const req=indexedDB.open('ytgpt-subtitles',1);
    req.onupgradeneeded=()=>{const db=req.result;db.createObjectStore('cache',{keyPath:'key'});db.createObjectStore('jobs',{keyPath:'jobId'});};
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>{dbPromise=null;reject(req.error);};
  });
  return dbPromise;
}
async function transaction(store,mode,operation) {
  const db=await openDB();
  return new Promise((resolve,reject)=>{const tx=db.transaction(store,mode),request=operation(tx.objectStore(store));let value;request.onsuccess=()=>{value=request.result;};tx.oncomplete=()=>resolve(value);tx.onerror=()=>reject(tx.error || request.error);tx.onabort=()=>reject(tx.error || new Error('儲存已中止'));});
}
export const getRecord=(store,key)=>transaction(store,'readonly',s=>s.get(key));
export const putRecord=(store,value)=>transaction(store,'readwrite',s=>s.put(value));
export const listRecords=store=>transaction(store,'readonly',s=>s.getAll());
export const deleteRecord=(store,key)=>transaction(store,'readwrite',s=>s.delete(key));
export const clearRecords=store=>transaction(store,'readwrite',s=>s.clear());
export async function clearCache(videoId) {for(const store of ['cache','jobs']){if(!videoId){await clearRecords(store);continue;}for(const r of await listRecords(store))if(r.videoId===videoId)await deleteRecord(store,r[store==='cache'?'key':'jobId']);}}
export async function cacheStats() {const all=await listRecords('cache');return {videos:new Set(all.map(x=>x.videoId)).size,entries:all.length,bytes:new TextEncoder().encode(JSON.stringify(all)).byteLength};}
