export function playableSeconds(cues,playheadMs) {
  let end=playheadMs;
  for(const cue of cues){if(cue.endMs<=end)continue;if(cue.startMs>end+1500)break;end=cue.endMs;}
  return Math.max(0,Math.floor((end-playheadMs)/1000));
}
