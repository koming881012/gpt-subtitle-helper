export function fillModels(select,models,current) {
  const available=models.filter(m=>typeof m.slug==='string' && /^[a-zA-Z0-9._:-]{1,100}$/.test(m.slug));
  const options=available.map(m=>new Option(m.display_name || m.slug,m.slug));
  if(!available.some(m=>m.slug===current)){const missing=new Option(`${current}（帳號目前不可用，請選擇）`,'');missing.disabled=true;options.unshift(missing);}
  select.replaceChildren(...options);select.value=available.some(m=>m.slug===current)?current:'';
  select.disabled=!available.length;
  return available.some(m=>m.slug===current);
}
