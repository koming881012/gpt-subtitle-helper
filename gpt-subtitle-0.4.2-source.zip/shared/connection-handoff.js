import {COMPANION_URL} from './companion.js';

export const HANDOFF_KEY='pendingConnection';
export function connectionUrl(extensionId,request) {
  const url=new URL(COMPANION_URL);
  url.searchParams.set('extension',extensionId);url.searchParams.set('request',request);
  return url.href;
}
export function validateHandoff(message,sender,pending,extensionId,now=Date.now()) {
  if(!pending||pending.expiresAt<=now||sender.id!==extensionId||sender.tab?.id!==pending.tabId)throw new Error('連線要求已失效，請回插件重新按登入。');
  const url=new URL(sender.url);
  if(url.origin!==COMPANION_URL||url.pathname!=='/'||url.searchParams.get('extension')!==extensionId||url.searchParams.get('request')!==pending.request||message.request!==pending.request)throw new Error('連線來源不符。');
  if(typeof message.connectionCode!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(message.connectionCode))throw new Error('連線資料不符。');
}
