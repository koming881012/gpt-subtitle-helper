export const DEFAULT_MODEL = 'gpt-5.6-luna';
export const PROMPT_VERSION = 'prompt-v2-progressive-sentences';
export const FAST_PROMPT_VERSION = 'prompt-v3-fast-timed';
export const translationVersion=meta=>meta.platform==='primevideo'||meta.videoId?.startsWith('prime:')?`${PROMPT_VERSION}-prime-timed-v1`:FAST_PROMPT_VERSION;
export const TRANSLATION_CONFIG = Object.freeze({ fullTextChars: 24000, fullTextCues: 350, maxTranscriptChars: 1200000, chunkSize: 120, chunkChars: 16000, contextCues: 12, maxRetries: 4, timeoutMs: 240000 });
export const DEFAULT_STYLE = Object.freeze({ zhSize: 30, enSize: 23, zhColor: '#ffffff', enColor: '#eeeeee', font: 'system-ui, "PingFang TC", "Microsoft JhengHei", sans-serif', outline: 2, background: false, opacity: 50, zhWeight: 600, enWeight: 500, lineHeight: 1.3, width: 80, bottom: 9, top: 7 });
export const DEFAULT_SETTINGS = Object.freeze({ model: DEFAULT_MODEL, terminologyModel:'gpt-6-astra', terminologyEnabled:false, reasoningEffort: 'medium', autoTranslate:true, pauseForSubtitles:true, targetLanguage: 'zh-TW', style: DEFAULT_STYLE });
export const MODES = Object.freeze({ zh: '繁體中文', en: '英文', 'both-zh': '中英雙語（中文在上）', 'both-en': '中英雙語（英文在上）', 'split-en': '上下分開（英文在上）', 'split-zh': '上下分開（中文在上）' });
export const ACTIVE_STATUSES = ['fetching', 'analyzing', 'translating', 'assembling'];
export function normalizeSettings(value = {}) {
  const s = { ...DEFAULT_SETTINGS, ...value, style: { ...DEFAULT_STYLE, ...value.style }, targetLanguage: 'zh-TW' };
  s.autoTranslate=Boolean(s.autoTranslate);
  s.pauseForSubtitles=Boolean(s.pauseForSubtitles);s.terminologyEnabled=Boolean(s.terminologyEnabled);
  if (typeof s.model !== 'string' || !/^[a-zA-Z0-9._:-]{1,100}$/.test(s.model)) throw new Error('Model ID 格式不正確。');
  if(typeof s.terminologyModel!=='string'||!/^gpt-6[\w.:-]*$/.test(s.terminologyModel))throw new Error('術語搜尋需使用 GPT-6 系列 Model ID。');
  if (!['low', 'medium', 'high'].includes(s.reasoningEffort)) throw new Error('Reasoning Effort 格式不正確。');
  const limits = { zhSize:[14,60], enSize:[14,60], outline:[0,3], opacity:[0,100], zhWeight:[400,700], enWeight:[400,700], lineHeight:[1,2], width:[50,90], bottom:[0,30], top:[0,30] };
  for (const [key, [min,max]] of Object.entries(limits)) { const n=Number(s.style[key]); s.style[key]=Number.isFinite(n)?Math.min(max,Math.max(min,n)):DEFAULT_STYLE[key]; }
  for (const key of ['zhColor','enColor']) if (!/^#[0-9a-f]{6}$/i.test(s.style[key])) s.style[key]=DEFAULT_STYLE[key];
  s.style.background = Boolean(s.style.background);
  s.style.font = String(s.style.font).slice(0,200);
  return s;
}
