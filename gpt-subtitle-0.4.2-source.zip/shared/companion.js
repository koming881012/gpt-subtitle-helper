export const COMPANION_URL='http://127.0.0.1:8766';
export async function requireCompanion({fetchImpl=fetch,attempts=25,delayMs=400}={}) {
  const deadline=Date.now()+10000;
  for(let attempt=0;attempt<attempts;attempt++) {
    const remaining=deadline-Date.now();if(remaining<=0)break;
    try {const r=await fetchImpl(`${COMPANION_URL}/health`,{signal:AbortSignal.timeout(Math.min(1500,remaining)),cache:'no-store',redirect:'error'});if(!r.ok)throw new Error();const b=await r.json();if(b.app==='youtube-gpt-subtitle-companion'&&b.ready===true)return;}
    catch{}
    if(attempt+1<attempts)await new Promise(resolve=>setTimeout(resolve,Math.max(0,Math.min(delayMs,deadline-Date.now()))));
  }
  throw Object.assign(new Error('本機連線尚未恢復，配對與登入仍會保留。請稍候再試；若持續無法連線，執行一次「啟動Plus連線.cmd」修復自動啟動。'),{code:'COMPANION_UNAVAILABLE'});
}
export async function companionRequest(path,connectionCode,payload={}) {
  await requireCompanion();
  let r;
  try {r=await fetch(`${COMPANION_URL}${path}`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${connectionCode}`},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000),redirect:'error'});}
  catch {throw Object.assign(new Error('本機連線暫時中斷，配對與登入仍會保留，背景程式會自動恢復。'),{code:'COMPANION_UNAVAILABLE'});}
  const data=await r.json();if(!r.ok)throw Object.assign(new Error(data.error?.message || '本機連線失敗。'),{status:r.status});return data;
}
