import { platformFromUrl,primeTitleId } from './platforms.js';
export function videoIdFromUrl(url) { try { const u=new URL(url);if(platformFromUrl(url)==='primevideo'){const id=primeTitleId(url);return id?`prime:${id}`:null;} return u.origin==='https://www.youtube.com' && u.pathname==='/watch' && /^[\w-]{11}$/.test(u.searchParams.get('v')||'') ? u.searchParams.get('v'):null; } catch { return null; } }
export function trackId(track) { return [track.languageCode,track.vssId || track.name,track.kind || 'manual'].join(':'); }
export function cacheKey(meta, track, settings) { const parts=[meta.platform || (meta.videoId?.startsWith('prime:')?'primevideo':'youtube'),meta.videoId,track.languageCode,trackId(track),settings.targetLanguage,settings.model,settings.reasoningEffort,meta.promptVersion];if(meta.promptVersion!=='prompt-v1')parts.push(settings.terminologyModel || 'gpt-6-astra');return JSON.stringify(parts); }
export function publicTrack(t) { return t ? {languageCode:t.languageCode,name:t.name,kind:t.kind || 'manual',vssId:t.vssId,sourceTrackId:trackId(t)}:null; }
export function safeFilename(title) { return String(title || 'YouTube').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/[. ]+$/,'').slice(0,120) || 'YouTube'; }
export function log(...args) { console.info('[YouTubeGPT]', ...args); }
export function userError(error) { return String(error?.message || error || '未知錯誤').slice(0,700); }
