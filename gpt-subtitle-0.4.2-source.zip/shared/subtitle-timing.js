export const MAX_SUBTITLE_OFFSET_MS=600000;
export function normalizeSubtitleOffset(value=0) {
  const offset=Number(value);
  if(!Number.isFinite(offset))return 0;
  return Math.max(-MAX_SUBTITLE_OFFSET_MS,Math.min(MAX_SUBTITLE_OFFSET_MS,Math.round(offset/100)*100));
}
// Positive offset delays display: video 12s shows the original subtitle at 10s.
export function subtitleTimeMs(videoTimeSeconds,offsetMs=0) {
  return Number(videoTimeSeconds)*1000-normalizeSubtitleOffset(offsetMs);
}
export function subtitleOffsetLabel(offsetMs) {
  const offset=normalizeSubtitleOffset(offsetMs);if(!offset)return '不調整（0 秒）';
  const seconds=Math.abs(offset)/1000,minutes=Math.floor(seconds/60),remainder=+(seconds%60).toFixed(1);
  return `${offset>0?'延後':'提前'} ${minutes?`${minutes} 分 `:''}${remainder} 秒`;
}
