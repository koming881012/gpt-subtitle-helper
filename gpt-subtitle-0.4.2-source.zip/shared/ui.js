import { MODES } from './constants.js';
export const $=selector=>document.querySelector(selector);
export function modeOptions(select) {for(const [value,label] of Object.entries(MODES))select.add(new Option(label,value));}
export function showError(message) {const el=$('#notice');el.textContent=message;el.className='notice error';}
export function notice(message) {const el=$('#notice');el.textContent=message;el.className='notice';}
export async function tabMessage(tabId,type,payload={}) {const r=await chrome.tabs.sendMessage(tabId,{type,...payload});if(!r?.ok)throw new Error(r?.error || '影片頁面未回應，請重新整理影片頁面。');return r.data;}
export async function bindAction(element,handler) {element.addEventListener('click',async()=>{try{await handler();}catch(e){showError(e.message);}});}
