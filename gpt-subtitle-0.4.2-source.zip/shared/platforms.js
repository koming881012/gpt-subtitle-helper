export const VIDEO_PATTERNS = ['https://www.youtube.com/*', 'https://www.primevideo.com/*', 'https://primevideo.com/*'];
export function platformFromUrl(value) {
  try { const u=new URL(value); if(u.protocol!=='https:')return null;
    if(u.hostname==='www.youtube.com')return 'youtube';
    if(['www.primevideo.com','primevideo.com'].includes(u.hostname))return 'primevideo';
  } catch {}
  return null;
}
export function primeTitleId(value) {
  try { const u=new URL(value);if(platformFromUrl(value)!=='primevideo')return null;
    const query=u.searchParams.get('gti') || u.searchParams.get('asin');
    if(/^[A-Z0-9]{10,32}$/i.test(query || ''))return query.toUpperCase();
    const path=u.pathname.match(/\/(?:detail|dp)\/(?:[^/]+\/)?([A-Z0-9]{10,32})(?:\/|$)/i);
    return path?path[1].toUpperCase():null;
  } catch {return null;}
}
export function isPrimeVideoId(value) {return /^prime:[A-Z0-9]{10,32}$/.test(value || '');}
export function validatePrimeCaptionUrl(value) {
  const u=new URL(value);
  if(u.protocol!=='https:' || u.username || u.password || u.port || !/(?:^|\.)(?:aiv-cdn\.net|pv-cdn\.net|aiv-delivery\.net|cloudfront\.net|media-amazon\.com|amazonvideo\.com|primevideo\.com)$/.test(u.hostname))throw new Error('Prime Video 字幕來源不受支援。');
  return u;
}
