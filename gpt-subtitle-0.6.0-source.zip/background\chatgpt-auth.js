// 插件內建的 Sign in with ChatGPT（取代舊版 Windows 連線助手）。
// 登入在 OpenAI 官方頁面完成；授權回傳到 loopback 網址時由插件攔截，插件從不接觸密碼。
// 憑證只存在 chrome.storage.local（僅限擴充功能自身頁面讀取），不送往 OpenAI 以外的地方。
export const AUTH_ORIGIN='https://auth.openai.com';
export const RESOURCE='https://api.openai.com/v1';
export const REDIRECT_URI='http://127.0.0.1:8766/auth/callback';
export const AUTH_KEY='chatgptAuth';
export const PENDING_KEY='chatgptPendingLogin';
const SCOPE='openid profile email offline_access resource.invoke chatgpt.tokens.use.direct';
const TOKEN_URL=`${AUTH_ORIGIN}/api/accounts/oauth/token`,REVOKE_URL=`${AUTH_ORIGIN}/api/accounts/oauth/revoke`;
const PENDING_TTL=10*60*1000;
const PERMANENT_REFRESH_ERRORS=['invalid_grant','invalid_refresh_token','token_expired','refresh_token_expired','refresh_token_invalidated','refresh_token_reused'];

const b64url=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const random=()=>b64url(crypto.getRandomValues(new Uint8Array(32)));
async function challenge(verifier){return b64url(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)));}
function decodePart(part){const text=atob(part.replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(part.length/4)*4,'='));return JSON.parse(new TextDecoder().decode(Uint8Array.from(text,c=>c.charCodeAt(0))));}
export function hasPlan(scopes=[]) {return scopes.includes('chatgpt.tokens.use.direct')&&scopes.includes('resource.invoke');}
export class AuthError extends Error {constructor(message,{code='',status=0}={}){super(message);this.code=code;this.status=status;}}

// ID token 直接由官方 token 端點經 TLS 取得（OIDC Core 3.1.3.7），驗證 issuer／audience／nonce／期限即可。
export function verifyIdentity(jwt,{clientId,nonce,subject,now=Date.now()/1000}) {
  const parts=String(jwt||'').split('.');if(parts.length!==3)throw new AuthError('登入身分格式不正確。');
  let p;try{p=decodePart(parts[1]);}catch{throw new AuthError('登入身分格式不正確。');}
  const aud=Array.isArray(p.aud)?p.aud:[p.aud];
  if(p.iss!==AUTH_ORIGIN||!aud.includes(clientId)||!Number.isFinite(p.exp)||p.exp<=now||p.nonce!==nonce||typeof p.sub!=='string'||!p.sub||(p.nbf&&p.nbf>now+30)||(subject&&p.sub!==subject))throw new AuthError('登入身分、有效期限或 nonce 驗證失敗，請重新登入。');
  if(aud.length>1&&p.azp!==clientId)throw new AuthError('登入 audience 不符。');
  return p;
}

export class ChatGPTAuth {
  constructor({local=chrome.storage.local,session=chrome.storage.session,fetchImpl=(...a)=>fetch(...a)}={}) {this.local=local;this.session=session;this.fetch=fetchImpl;this.refreshing=null;this.lastError='';}
  async read() {const v=(await this.local.get(AUTH_KEY))[AUTH_KEY]||{};v.accounts||=[];if(!v.hostId){v.hostId=`urn:uuid:${crypto.randomUUID()}`;await this.write(v);}return v;}
  async write(v) {await this.local.set({[AUTH_KEY]:v});}
  account(v) {return v.accounts.find(a=>a.id===v.active)||null;}
  async status() {
    const v=await this.read(),a=this.account(v);
    return {signedIn:Boolean(a?.access_token),planEnabled:Boolean(a?.access_token&&hasPlan(a.scopes)),account:a?{id:a.id,email:a.email}:null,accounts:v.accounts.map(x=>({id:x.id,email:x.email})),error:this.lastError||v.lastError||''};
  }
  async start({newAccount=false,enablePlan=false,tabId=null}={}) {
    const v=await this.read(),a=newAccount?null:this.account(v),state=random(),nonce=random(),verifier=random();
    await this.session.set({[PENDING_KEY]:{state,nonce,verifier,accountId:a?.id||null,tabId,created:Date.now()}});
    this.lastError='';if(v.lastError){delete v.lastError;await this.write(v);}
    const q=new URLSearchParams({client_id:a?.client_id||'dynamic_agent_client',ext_agent_host_id:v.hostId,response_type:'code',redirect_uri:REDIRECT_URI,scope:SCOPE,resource:RESOURCE,state,nonce,code_challenge_method:'S256',code_challenge:await challenge(verifier)});
    if(!a)q.set('agent_name_hint','YouTube GPT 中文字幕助手');
    if(a?.id_token)q.set('id_token_hint',a.id_token);
    if(enablePlan)q.set('prompt','consent');
    return `${AUTH_ORIGIN}/api/accounts/authorize?${q}`;
  }
  async setPendingTab(tabId) {const p=(await this.session.get(PENDING_KEY))[PENDING_KEY];if(p){p.tabId=tabId;await this.session.set({[PENDING_KEY]:p});}}
  async pending() {return (await this.session.get(PENDING_KEY))[PENDING_KEY]||null;}
  async token(fields) {
    let r,b={};
    try{r=await this.fetch(TOKEN_URL,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({...fields,resource:RESOURCE}),signal:AbortSignal.timeout(30000),redirect:'error',credentials:'omit'});}
    catch{throw new AuthError('無法連到 OpenAI 登入服務，請檢查網路後再試。',{code:'network'});}
    try{b=await r.json();}catch{}
    if(!r.ok)throw new AuthError('ChatGPT 登入或更新失敗，請重新登入。',{code:typeof b.error==='string'?b.error:b.error?.code,status:r.status});
    return b;
  }
  // 由插件攔截到的授權回傳網址完成登入。
  async callback(callbackUrl) {
    const url=new URL(callbackUrl),q=url.searchParams;
    if(`${url.origin}${url.pathname}`!==REDIRECT_URI)throw new AuthError('登入回傳網址不符。');
    const p=await this.pending();
    if(!p||q.get('state')!==p.state||Date.now()-p.created>PENDING_TTL)throw new AuthError('登入要求已失效或逾時，請回插件重新按登入。');
    await this.session.remove(PENDING_KEY);
    const v=await this.read(),previous=v.accounts.find(x=>x.id===p.accountId)||null;
    try {
      if(q.has('error'))throw new AuthError('登入授權未完成，未使用任何方案額度。');
      const clientId=q.get('client_id')||previous?.client_id;
      if(!q.get('code')||!clientId||clientId==='dynamic_agent_client'||(previous&&clientId!==previous.client_id))throw new AuthError('登入 client ID 不符。');
      const t=await this.token({grant_type:'authorization_code',client_id:clientId,code:q.get('code'),code_verifier:p.verifier,redirect_uri:REDIRECT_URI});
      const identity=verifyIdentity(t.id_token,{clientId,nonce:p.nonce,subject:previous?.subject});
      if(String(t.token_type).toLowerCase()!=='bearer'||!t.access_token||!t.refresh_token||!(t.expires_in>0))throw new AuthError('登入憑證不完整。');
      const a={id:`${clientId}:${identity.sub}`,client_id:clientId,subject:identity.sub,email:String(identity.email||identity.sub),id_token:t.id_token,access_token:t.access_token,refresh_token:t.refresh_token,scopes:String(t.scope||'').split(/\s+/),expiresAt:Date.now()+t.expires_in*1000};
      const next=await this.read();next.accounts=next.accounts.filter(x=>x.id!==a.id);next.accounts.push(a);next.active=a.id;
      next.lastError=hasPlan(a.scopes)?'':'已登入，但還沒授權使用 ChatGPT 方案用量。';await this.write(next);this.lastError=next.lastError;
      return this.status();
    }catch(e){this.lastError=e.message;const next=await this.read();next.lastError=e.message;await this.write(next);throw e;}
  }
  async select(id) {const v=await this.read();if(!v.accounts.some(x=>x.id===id))throw new AuthError('找不到帳號。');v.active=id;await this.write(v);return this.status();}
  // 取得可用的 access token；過期前 1 分鐘自動更新。refresh token 會輪替，所以同一時間只允許一個更新請求，
  // 其他請求等它完成後重新讀取新的 token。
  async access(force=false) {
    for(;;) {
      if(this.refreshing){await this.refreshing.catch(()=>{});force=false;}
      const v=await this.read(),a=this.account(v);
      if(!a?.access_token||!hasPlan(a.scopes))throw new AuthError(v.lastError||'請先用 ChatGPT 登入並授權方案用量。',{status:401,code:'signed_out'});
      if(!force&&a.expiresAt>Date.now()+60000)return {token:a.access_token,accountId:a.id};
      if(this.refreshing)continue;
      this.refreshing=this.refresh(a).finally(()=>{this.refreshing=null;});
      await this.refreshing;force=false;
    }
  }
  async refresh(a) {
    try {
      const t=await this.token({grant_type:'refresh_token',client_id:a.client_id,refresh_token:a.refresh_token});
      if(!t.access_token||!(t.expires_in>0))throw new AuthError('更新憑證不完整。');
      const next=await this.read(),current=next.accounts.find(x=>x.id===a.id);if(!current)return;
      Object.assign(current,{access_token:t.access_token,refresh_token:t.refresh_token||current.refresh_token,expiresAt:Date.now()+t.expires_in*1000});
      if(t.scope!==undefined)current.scopes=String(t.scope).split(/\s+/);
      await this.write(next);
    }catch(e){
      if(PERMANENT_REFRESH_ERRORS.includes(e.code)){const next=await this.read(),current=next.accounts.find(x=>x.id===a.id);if(current){for(const k of ['access_token','refresh_token','id_token'])delete current[k];next.lastError='ChatGPT 登入已過期，請重新登入。';await this.write(next);}}
      throw e;
    }
  }
  async logout() {
    if(this.refreshing)await this.refreshing.catch(()=>{});
    const v=await this.read(),a=this.account(v);await this.session.remove(PENDING_KEY);if(!a)return {revoked:true};
    let revoked=false;
    for(let n=0;n<3&&(a.refresh_token||a.access_token);n++){
      try{const r=await this.fetch(REVOKE_URL,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({token:a.refresh_token||a.access_token,token_type_hint:a.refresh_token?'refresh_token':'access_token',client_id:a.client_id}),signal:AbortSignal.timeout(10000),redirect:'error',credentials:'omit'});if(r.ok){revoked=true;break;}if(r.status<500)break;}catch{}
      await new Promise(resolve=>setTimeout(resolve,300*2**n));
    }
    for(const k of ['access_token','refresh_token','id_token'])delete a[k];await this.write(v);return {revoked};
  }
}
