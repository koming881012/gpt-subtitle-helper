import { MSG } from '../shared/messages.js';
const workers=new Map();
// 轉送 Worker 的用量紀錄與憑證請求；回傳 true 表示訊息已處理。
function relay(worker,data) {
  if(data.type==='usage'){chrome.runtime.sendMessage({type:MSG.USAGE,usage:data.usage}).catch(()=>{});return true;}
  if(data.type==='access'){
    chrome.runtime.sendMessage({type:MSG.ACCESS_TOKEN,force:data.force}).then(r=>worker.postMessage(r?.ok?{type:'access-result',id:data.id,ok:true,token:r.data.token,accountId:r.data.accountId}:{type:'access-result',id:data.id,ok:false,error:r?.error,code:r?.code})).catch(e=>worker.postMessage({type:'access-result',id:data.id,ok:false,error:e.message}));
    return true;
  }
  return false;
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(sender.id!==chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('background/')) || message.target!=='offscreen')return;
  if(message.type===MSG.PING){respond({ok:true,data:{jobIds:[...workers.keys()]}});return;}
  if(message.type===MSG.PRIORITY){workers.get(message.jobId)?.worker.postMessage({type:'priority',playheadMs:message.playheadMs});respond({ok:true});return;}
  if(message.type===MSG.TEST) {
    const worker=new Worker(chrome.runtime.getURL('offscreen/translation-worker.js'),{type:'module'});
    worker.onmessage=({data})=>{if(relay(worker,data))return;if(data.type==='test-done'){respond(data);worker.terminate();}};
    worker.onerror=()=>{respond({ok:false,error:'連線測試 Worker 無法執行，請重新載入擴充功能。'});worker.terminate();};
    worker.postMessage({type:'test',settings:message.settings});return true;
  }
  if(message.type===MSG.ABORT){
    const entry=workers.get(message.jobId);if(!entry){respond({ok:true});return;}
    entry.cancelWaiters.push(respond);entry.worker.postMessage({type:'abort'});
    entry.abortTimer ||= setTimeout(()=>{entry.worker.terminate();workers.delete(message.jobId);entry.cancelWaiters.splice(0).forEach(reply=>reply({ok:true}));},2500);
    return true;
  }
  if(message.type!==MSG.RUN)return;
  if(workers.has(message.job.jobId)){respond({ok:true});return;}
  const worker=new Worker(chrome.runtime.getURL('offscreen/translation-worker.js'),{type:'module'});
  const entry={worker,cancelWaiters:[]};workers.set(message.job.jobId,entry);
  worker.onmessage=({data})=>{
    if(relay(worker,data))return;
    if(data.type==='done'){clearTimeout(entry.abortTimer);worker.terminate();workers.delete(data.jobId);entry.cancelWaiters.splice(0).forEach(reply=>reply({ok:true}));}
    chrome.runtime.sendMessage({type:MSG.CHECKPOINT,jobId:data.jobId,workerError:null}).catch(()=>{});
  };
  worker.onerror=()=>{clearTimeout(entry.abortTimer);workers.delete(message.job.jobId);worker.terminate();entry.cancelWaiters.splice(0).forEach(reply=>reply({ok:true}));chrome.runtime.sendMessage({type:MSG.CHECKPOINT,jobId:message.job.jobId,workerError:'背景翻譯意外中止，已保留進度，請按繼續翻譯。'}).catch(()=>{});};
  worker.postMessage({type:'run',job:message.job});respond({ok:true});
});
// A restored offscreen document asks the orchestrator to recover persisted jobs.
chrome.runtime.sendMessage({type:MSG.RECOVER}).catch(()=>{});
