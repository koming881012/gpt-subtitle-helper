// gpt-5.6-luna → GPT-5.6 Luna；帳號模型清單有 display_name 時優先使用。
export function modelLabel(slug,models=[]) {
  const value=String(slug||'');if(!value)return '';
  const listed=models.find(m=>m.slug===value)?.display_name;if(listed)return listed;
  const [family,version,...rest]=value.split('-');
  if(!/^gpt$/i.test(family)||!version)return value;
  return [`GPT-${version}`,...rest.map(part=>part.charAt(0).toUpperCase()+part.slice(1))].join(' ');
}
export const EFFORT_LABELS=Object.freeze({low:'快速',medium:'標準',high:'精細'});
export function formatTokens(value) {
  const n=Number(value)||0;
  if(n>=1e6)return `${(n/1e6).toFixed(n>=1e7?0:1)}M`;
  if(n>=1e3)return `${(n/1e3).toFixed(n>=1e4?0:1)}K`;
  return String(n);
}
