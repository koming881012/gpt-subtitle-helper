import { PROMPT_VERSION,FAST_PROMPT_VERSION } from '../shared/constants.js';
import { requestJSON } from './openai-client.js';
import { TRANSLATION_INSTRUCTIONS, CONTEXT_INSTRUCTIONS } from './translation-prompt.js';
import { TRANSLATION_SCHEMA, CONTEXT_SCHEMA, validateTranslation, validateContext } from './translation-schema.js';
import { planBatches, transcript, batchInput } from './transcript-context.js';
import { parseCaptions, validateCues } from '../content/caption-parser.js';
import { fetchCaptionSource } from '../content/caption-fetcher.js';
import { getRecord, putRecord } from '../background/storage.js';
import { log } from '../shared/utils.js';
import { translateProgressively } from './progressive-translator.js';
import { translateTimedCaptions } from './timed-translator.js';
import {translateFastTimed} from './fast-timed.js';
export async function translateJob(job,access,signal,notify,{request=requestJSON,fetchSource=fetchCaptionSource,save=putRecord,read=getRecord}={}) {
  if(job.platform==='primevideo'||job.promptVersion===FAST_PROMPT_VERSION)return translateFastTimed(job,access,signal,notify,{request,save,read});
  if(job.promptVersion!=='prompt-v1')return translateProgressively(job,access,signal,notify,{request,fetchSource,save,read});
  const checkpoint=async(patch)=>{Object.assign(job,patch,{updatedAt:Date.now()});await save('jobs',job);notify({jobId:job.jobId});};
  try {
    if(!job.sourceCues?.length) {
      await checkpoint({status:'fetching',phase:'正在取得英文字幕…',error:null});
      const source=job.prefetchedSource || await fetchSource(job.sourceTrack,job.videoId,signal);
      job.sourceCues=parseCaptions(source.raw,job.duration);job.rawSource=source.raw;delete job.prefetchedSource;
      job.sourceFormat=source.format;job.warnings=[...validateCues(job.sourceCues,job.duration).warnings,...(source.warnings || []).map(s=>String(s).slice(0,300))];
      log('caption fetched',`${job.sourceCues.length} cues parsed`);
      await checkpoint({totalCues:job.sourceCues.length,phase:`已取得 ${job.sourceCues.length} 段字幕`});
    }
    const plan=planBatches(job.sourceCues);job.mode=plan.mode;job.batches=plan.batches;job.results ||= {};
    const call=async(instructions,input,schema,name)=>request({access,accountId:job.accountId,settings:job.settings,instructions,input,schema,name,signal,onRetry:(attempt,message)=>notify({jobId:job.jobId,retry:attempt,message})});
    if(plan.mode==='context' && !job.context) {
      await checkpoint({status:'analyzing',phase:'正在分析全文…'});
      const context=validateContext(await call(CONTEXT_INSTRUCTIONS,JSON.stringify({videoTitle:job.title,fullTranscript:transcript(job.sourceCues)}),CONTEXT_SCHEMA,'subtitle_context'));
      await checkpoint({context});
    }
    if(plan.mode==='full')await checkpoint({status:'analyzing',phase:'正在分析全文並翻譯…'});
    for(let b=0;b<plan.batches.length;b++) {
      if(signal.aborted)throw new DOMException('Aborted','AbortError');
      const batch=plan.batches[b], all=job.sourceCues.slice(batch.start,batch.end);
      let missing=all.filter(c=>!Object.hasOwn(job.results,c.id));if(!missing.length)continue;
      await checkpoint({status:'translating',phase:`正在翻譯… 第 ${b+1} / ${plan.batches.length} 批`,batchIndex:b});
      // Valid partial output is persisted; subsequent calls target only missing IDs.
      for(let repair=0;missing.length && repair<4;repair++) {
        let validated;
        try {validated=validateTranslation(await call(TRANSLATION_INSTRUCTIONS,batchInput(job,batch,missing),TRANSLATION_SCHEMA,'subtitle_translation'),missing,{allowMissing:true});}
        catch(e) {if(e.name==='AbortError' || e.retryable!==undefined || repair===3)throw e;continue;}
        for(const t of validated.translations)job.results[t.id]=t.translation.trim();
        missing=validated.missing;
        await checkpoint({translatedCues:Object.keys(job.results).length,progress:Math.floor(Object.keys(job.results).length/job.totalCues*100)});
      }
      if(missing.length)throw new Error(`第 ${b+1} 批翻譯缺少 ${missing.length} 段字幕，可繼續翻譯。`);
    }
    if(signal.aborted)throw new DOMException('Aborted','AbortError');
    await checkpoint({status:'assembling',phase:'正在整理中文字幕…'});
    const translations=job.sourceCues.map(c=>({id:c.id,translation:job.results[c.id]}));validateTranslation({translations},job.sourceCues);
    const translatedCues=job.sourceCues.map(c=>({id:c.id,startMs:c.startMs,durationMs:c.durationMs,endMs:c.endMs,en:c.text,zh:job.results[c.id]}));
    const cache={key:job.cacheKey,videoId:job.videoId,title:job.title,sourceTrack:job.sourceTrack,model:job.model,promptVersion:PROMPT_VERSION,translatedAt:Date.now(),sourceCues:job.sourceCues,translatedCues,rawSource:job.rawSource,warnings:job.warnings};
    await save('cache',cache);
    // Completed text lives only in cache; clearing cache removes that completed transcript.
    for(const field of ['sourceCues','rawSource','results','context','batches','prefetchedSource'])delete job[field];
    await checkpoint({status:'completed',phase:'✓ 翻譯完成，字幕已開啟',progress:100,error:null});
  } catch(e) {
    const latest=await read('jobs',job.jobId);
    const cancelled=signal.aborted || latest?.status==='cancelled';
    await checkpoint({status:cancelled?'cancelled':'error',phase:cancelled?'翻譯已取消，可從目前進度繼續':`第 ${(job.batchIndex || 0)+1} 批翻譯失敗`,error:cancelled?null:String(e.message).slice(0,700)});
  }
  return job;
}
