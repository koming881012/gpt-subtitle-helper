import { MSG,send } from '../shared/messages.js';
import { REDIRECT_URI } from '../background/chatgpt-auth.js';
const $=s=>document.querySelector(s);
function show(tone,eyebrow,headline,detail='') {$('#card').className=`card ${tone}`;$('#eyebrow').textContent=eyebrow;$('#headline').textContent=headline;$('#detail').textContent=detail;}
$('#close').addEventListener('click',()=>window.close());
$('#retry').addEventListener('click',async()=>{try{await send(MSG.SIGN_IN);window.close();}catch(e){$('#detail').textContent=e.message;}});
(async()=>{
  // 網址參數只轉交背景頁完成換發；換發後立即清掉網址列中的授權碼。
  const search=location.search;history.replaceState(null,'',location.pathname);
  try {
    const result=await send(MSG.AUTH_CALLBACK,{url:`${REDIRECT_URI}${search}`});
    if(result.planEnabled){show('ok','✓ 登入完成',`已連接 ${result.account?.email||'你的 ChatGPT 帳號'}`,'回到 YouTube 或 Prime Video 影片就能使用中文字幕。這個分頁會自動關閉。');$('#close').hidden=false;setTimeout(()=>window.close(),4000);}
    else {show('warn','還差一步','已登入，但還沒授權使用 ChatGPT 方案用量。','按「重新登入」並在 OpenAI 頁面允許使用方案用量。');$('#retry').hidden=false;$('#retry').textContent='授權使用方案用量';$('#retry').onclick=async()=>{await send(MSG.SIGN_IN,{enablePlan:true});window.close();};}
  }catch(e){show('error','登入沒有完成',e.message,'可以回到插件再按一次登入；不會使用任何方案用量。');$('#retry').hidden=false;}
})();
