import {test} from 'node:test';
import assert from 'node:assert/strict';
import {AutoTranslationGate} from '../content/auto-translate.js';
import {normalizeSettings} from '../shared/constants.js';
import {nativeChineseTracks,englishTracks} from '../content/caption-detector.js';
const state=()=>({meta:{platform:'youtube',videoId:'e4NAz2TWA4I',audioLanguage:'en'},track:{languageCode:'en',vssId:'en'},settings:{...normalizeSettings(),hasConnection:true},pref:{enabled:true},cache:null,job:null,starting:false});
test('自動翻譯每個影片／字幕／模型只啟動一次，兩平台互相隔離',()=>{
  const gate=new AutoTranslationGate(),s=state();
  assert.equal(gate.take(s),true);assert.equal(gate.take(s),false);
  assert.equal(gate.take({...s,meta:{...s.meta,platform:'primevideo',videoId:'prime:ABCDEFGHIJ'}}),true);
  assert.equal(gate.take({...s,settings:{...s.settings,model:'gpt-6-sol'}}),true);
  assert.equal(gate.take({...s,track:{...s.track,vssId:'en-US'}}),true);
});
test('未就緒、字幕關閉、完整快取與進行中工作不自動翻譯',()=>{
  const s=state();
  for(const patch of [{meta:null},{meta:{...s.meta,isLive:true}},{track:null},{starting:true},{pref:{enabled:false}},{settings:{...s.settings,hasConnection:false}},{settings:{...s.settings,autoTranslate:false}},{cache:{partial:false}},{job:{status:'translating'}}]) {
    const gate=new AutoTranslationGate();assert.equal(gate.take({...s,...patch}),false);assert.equal(gate.take(s),true);
  }
  assert.equal(normalizeSettings().autoTranslate,true);assert.equal(normalizeSettings({autoTranslate:false}).autoTranslate,false);
});
test('新一次觀看會續翻部分進度；同次觀看取消後不自行再啟動',()=>{const s={...state(),cache:{partial:true},job:{status:'cancelled'}};const gate=new AutoTranslationGate();assert(gate.take(s));assert(!gate.take(s));assert(new AutoTranslationGate().take(s));});

test('非英文及未知音訊語言不因英文 ASR 而自動翻譯；稍後確認英文仍可啟動',()=>{
  for(const audioLanguage of ['zh-TW','ja','es',null,undefined]){const s=state(),gate=new AutoTranslationGate();s.track={...s.track,kind:'asr',vssId:'a.en'};s.meta.audioLanguage=audioLanguage;assert(!gate.take(s));s.meta.audioLanguage='en-US';assert(gate.take(s));}
  const s=state();delete s.meta.audioLanguage;s.meta.platform='primevideo';s.meta.videoId='prime:ABCDEFGHIJ';assert(new AutoTranslationGate().take(s));
});
test('YouTube 自動翻譯成英文的字幕不能當原生英文來源，保留真正英文 ASR',()=>{
  const tracks=[{languageCode:'en',kind:'asr',vssId:'a.en'},{languageCode:'en',isAutoTranslated:true},{languageCode:'en',baseUrl:'https://www.youtube.com/api/timedtext?lang=ja&tlang=en'},{languageCode:'en',name:'English (auto-translated)'}];
  assert.equal(englishTracks(tracks).length,1);assert.equal(englishTracks(tracks)[0].vssId,'a.en');
});

test('兩平台有原生人工中文字幕時不啟動；自動生成與自動翻譯不能冒充人工字幕',()=>{
  for(const platform of ['youtube','primevideo'])for(const languageCode of ['zh','zh-TW','zh-Hans','zh_Hant','cmn','yue']) {
    const s=state();s.meta={...s.meta,platform,captionTracks:[s.track,{languageCode,kind:'manual'}]};assert.equal(new AutoTranslationGate().take(s),false);
  }
  for(const chinese of [{kind:'asr'},{vssId:'a.zh'},{name:'中文 (自動產生)'},{name:'Chinese (auto-translated)'},{isAutoTranslated:true},{baseUrl:'https://example.test/timedtext?lang=en&tlang=zh-TW'},{kind:'forced'}]){
    const s=state();s.meta.captionTracks=[s.track,{languageCode:'zh',...chinese}];assert.equal(nativeChineseTracks(s.meta.captionTracks).length,0);assert.equal(new AutoTranslationGate().take(s),true);
  }
});
test('平台未標音訊語言但有英文 ASR 字幕軌時，判定為英文影片可自動翻譯',()=>{
  const s=state();delete s.meta.audioLanguage;s.track={...s.track,kind:'asr',vssId:'a.en'};s.meta.captionTracks=[{languageCode:'en',kind:'asr',vssId:'a.en'}];
  assert(new AutoTranslationGate().take(s));
  s.meta.audioLanguage='ja';assert(!new AutoTranslationGate().take(s));
});
test('影片已有人工中文字幕時只略過自動翻譯，不阻擋手動',()=>{
  const s=state();s.meta.captionTracks=[s.track,{languageCode:'zh-Hant',vssId:'.zh-Hant'}];assert(!new AutoTranslationGate().take(s));
});
