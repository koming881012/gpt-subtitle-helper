import test from 'node:test';
import assert from 'node:assert/strict';
import {captionWords,sentenceWindow,pauseWindow,compactWords,sentenceInput,validateSentences,playableSeconds,timeSubtitles,tidyChinese} from '../translation/sentence-subtitles.js';
import {parseCaptions} from '../content/caption-parser.js';
test('台灣字幕慣例：句末不留句號；程式語言與縮寫可保留；超長回饋指出來源詞與詞數',()=>{
  const words=captionWords([{id:0,startMs:0,endMs:2000,text:'He said hello to me.'}]),window={start:0,end:words.length,isFinalWindow:true};
  const output={sentences:[{startWord:0,endWord:words.length,en:'He said, “Hello.”',zh:'他說：「你好」。'}]};
  assert.equal(validateSentences(output,words,window).cues[0].zh,'他說：「你好」');
  for(const zh of ['C 語言的指標','用 C++ 寫的 API','iOS 與 GPU','Go 是一種程式語言','用 Docker 部署'])assert.doesNotThrow(()=>validateSentences({sentences:[{...output.sentences[0],zh}]},words,window));
  assert.throws(()=>validateSentences({sentences:[{...output.sentences[0],zh:'He said hello 你好'}]},words,window),/大多還是英文/);
  assert.throws(()=>validateSentences({sentences:[{...output.sentences[0],zh:'這部優튜布影片'}]},words,window),/韓文或日文/);
  assert.doesNotThrow(()=>validateSentences({sentences:[{...output.sentences[0],zh:'你正透過 Python 網頁應用程式看這部 YouTube 影片'}]},words,window));
  assert.doesNotThrow(()=>validateSentences({sentences:[{...output.sentences[0],zh:'字'.repeat(60)}]},words,window,{lenient:true}));
  const bad=structuredClone(output);bad.sentences[0].en='hello '.repeat(40);assert.throws(()=>validateSentences(bad,words,window),/startWord 0.*40 詞/);
  assert.equal(tidyChinese(' 好。 '),'好');assert.equal(tidyChinese('真的嗎？'),'真的嗎？');
});
test('YouTube 自動字幕使用每個詞的真實時間，不是平均分配',()=>{
  const raw=JSON.stringify({events:[{tStartMs:120,dDurationMs:4360,segs:[{utf8:'C'},{utf8:' A',tOffsetMs:679},{utf8:' statically',tOffsetMs:880},{utf8:' typed',tOffsetMs:1400}]},{tStartMs:2550,dDurationMs:1930,aAppend:1,segs:[{utf8:'\n'}]},{tStartMs:2560,dDurationMs:3920,segs:[{utf8:'programming'},{utf8:' language',tOffsetMs:480}]}]});
  const words=captionWords(parseCaptions(raw));
  assert.deepEqual(words.map(w=>w.text),['C','A','statically','typed','programming','language']);
  assert.deepEqual(words.map(w=>w.startMs),[120,799,1000,1520,2560,3040]);
  assert.equal(words[3].endMs,2560);assert.equal(words[5].endMs,4240);
});
test('顯示時間：提早出現、短字幕有最短停留、補掉短空檔，且不和下一段重疊',()=>{
  const timed=timeSubtitles([{id:'a',startMs:1000,endMs:1300,zh:'好'},{id:'b',startMs:1500,endMs:3000,zh:'這是一段比較長的中文字幕內容'},{id:'c',startMs:6000,endMs:7000,zh:'下一句'}]);
  assert.equal(timed[0].startMs,880);assert.equal(timed[0].endMs,1380);
  assert.equal(timed[1].startMs,1380);assert(timed[1].endMs>=3000&&timed[1].endMs<=6000);
  assert.equal(timed[2].startMs,5880);for(let i=1;i<timed.length;i++)assert(timed[i].startMs>=timed[i-1].endMs);
});
import {translateProgressively} from '../translation/progressive-translator.js';
import {researchTerminology,sanitizeGlossary,termRevisionRanges} from '../translation/terminology.js';
import {DEFAULT_SETTINGS,PROMPT_VERSION} from '../shared/constants.js';
import {cacheKey} from '../shared/utils.js';
const source=Array.from({length:30},(_,id)=>({id,text:'This is a complete sentence about the board game.',startMs:id*5000,endMs:(id+1)*5000,durationMs:5000}));
const newJob=()=>({jobId:'progressive-test',videoId:'video',title:'Test',duration:150,sourceCues:structuredClone(source),sourceTrack:{languageCode:'en'},cacheKey:'test-cache',model:DEFAULT_SETTINGS.model,promptVersion:PROMPT_VERSION,settings:{...structuredClone(DEFAULT_SETTINGS),terminologyEnabled:true},playheadMs:75000,translatedCues:0});
const memory=()=>{const data={jobs:new Map(),cache:new Map()};return {data,save:async(store,value)=>data[store].set(store==='cache'?value.key:value.jobId,structuredClone(value)),read:async(store,key)=>structuredClone(data[store].get(key))};};

test('平行分段：從播放位置附近的停頓開始，在句末或停頓處切開，已翻與分派中的範圍不重複',()=>{
  const words=captionWords(source),blocked=new Uint8Array(words.length);
  const first=pauseWindow(words,blocked,75000,40);assert.equal(words[first.start].startMs,70000);assert(/.$/.test(words[first.end-1].text));assert(first.isFinalWindow);
  blocked.fill(1,first.start,first.end);const second=pauseWindow(words,blocked,75000,120);assert.equal(second.start,first.end);
  blocked.fill(1,second.start,second.end);const third=pauseWindow(words,blocked,75000,120);assert(third.start<first.start||third.start>=second.end);
});
test('精簡輸入：id:詞、只在停頓標秒數、只附本批出現的名詞且不附網址',()=>{
  const words=captionWords([{id:0,startMs:0,endMs:2000,text:'Play Nemesis now'},{id:1,startMs:3000,endMs:4000,text:'then rest'}]);
  assert.equal(compactWords(words,0,words.length),'‖0.0 0:Play 1:Nemesis 2:now ‖3.0 3:then 4:rest');
  const input=JSON.parse(sentenceInput({title:'T',glossary:[{source:'Nemesis',target:'復仇女神號',meaning:'桌遊',urls:['https://x']},{source:'Python',target:'Python',urls:[]}]},words,{start:0,end:words.length}));
  assert.deepEqual(input.glossary,[{source:'Nemesis',target:'復仇女神號',meaning:'桌遊'}]);assert(!JSON.stringify(input).includes('https'));
});
test('播放位置變更優先翻譯新位置；搜尋模型有獨立快取',()=>{
  const words=captionWords(source),first=sentenceWindow(words,[],0,true);
  const sought=sentenceWindow(words,[{start:first.start,end:20}],125000);
  assert(words[sought.start].startMs>=115000);
  const meta={videoId:'video',promptVersion:PROMPT_VERSION},track={languageCode:'en'};
  assert.notEqual(cacheKey(meta,track,DEFAULT_SETTINGS),cacheKey(meta,track,{...DEFAULT_SETTINGS,terminologyModel:'gpt-6-sol'}));
  assert.equal(playableSeconds([{startMs:0,endMs:12000},{startMs:12000,endMs:22000}],5000),17);
  assert.equal(playableSeconds([{startMs:10000,endMs:22000}],0),0);
});
const wordIds=p=>typeof p.words==='string'?[...p.words.matchAll(/(?:^| )(\d+):/g)].map(m=>Number(m[1])):p.words.map(w=>w.id);
function response(input){const p=JSON.parse(input),ids=wordIds(p),sentences=[];for(let start=ids[0];start<ids.at(-1)+1;start+=10)sentences.push({startWord:start,endWord:Math.min(start+10,ids.at(-1)+1),en:'This is a complete sentence.',zh:'這是完整且容易閱讀的句子。'});return {sentences};}
test('句子字幕保留來源詞範圍，阻擋遺漏、英文名稱、過長與未完成句',()=>{
  const words=captionWords(source),window=sentenceWindow(words,[],0,true),output=response(JSON.stringify({words:words.slice(window.start,window.end)}));
  const validated=validateSentences(output,words,window);assert.equal(validated.end,window.end);assert.equal(validated.cues[0].startMs,0);assert(playableSeconds(validated.cues,0)>30);
  for(const change of [s=>s.zh='Using Nemesis now.',s=>s.zh='字'.repeat(50)+'。',s=>s.en=' ',s=>s.startWord+=10]){const bad=structuredClone(output);change(bad.sentences[0]);assert.throws(()=>validateSentences(bad,words,window));}
  const next=sentenceWindow(words,[{start:window.start,end:window.end}],0);assert.equal(next.start,window.end);
  // 編號只差幾個詞時自動對齊，不讓整批失敗。
  const off=structuredClone(output);off.sentences[0].startWord++;assert.equal(validateSentences(off,words,window).cues[0].startWord,window.start);
});
test('未完成整片前保存可播字幕；首批優先播放位置，取消後能保留並續翻',async()=>{
  const store=memory(),job=newJob(),controller=new AbortController();let calls=0,firstStart;
  const request=async({input})=>{calls++;if(calls===1){firstStart=wordIds(JSON.parse(input))[0];return response(input);}while(!store.data.cache.get(job.cacheKey))await new Promise(r=>setTimeout(r,2));const partial=store.data.cache.get(job.cacheKey);assert(partial.partial);assert(partial.translatedCues.length);assert(partial.translatedCues[0].startMs>=64000);controller.abort();throw new DOMException('Aborted','AbortError');};
  await translateProgressively(job,'test',controller.signal,()=>{}, {...store,request,research:async()=>[]});assert(firstStart>0);assert.equal(job.status,'cancelled');assert(store.data.cache.get(job.cacheKey).partial);const previous=structuredClone(job.wordRanges);
  const resumed=await store.read('jobs',job.jobId);await translateProgressively(resumed,'test',new AbortController().signal,()=>{}, {...store,request:async({input})=>{const first=wordIds(JSON.parse(input))[0];assert(!previous.some(r=>first>=r.start&&first<r.end));return response(input);},research:async()=>[]});
  const complete=store.data.cache.get(job.cacheKey);assert.equal(resumed.status,'completed',resumed.error);assert.equal(complete.partial,false);assert.equal(resumed.translatedCues,30);assert.equal(complete.translatedCues[0].startMs,0);assert.equal(complete.translatedCues.at(-1).endMs,150000);assert.equal(new Set(complete.translatedCues.map(c=>c.id)).size,complete.translatedCues.length);
});
test('背景術語搜尋不擋首批；完成後校正暫用譯名，搜尋失敗仍保留字幕並提示',async()=>{
  const store=memory(),job=newJob();let resolveResearch,researchReady=false,requests=0,sawPartial=false;
  const research=()=>new Promise(resolve=>{resolveResearch=resolve;});
  await translateProgressively(job,'test',new AbortController().signal,()=>{const cache=store.data.cache.get(job.cacheKey);if(cache?.partial&&!researchReady){sawPartial=true;researchReady=true;resolveResearch([{source:'Game',target:'遊戲',urls:[]}]);}}, {...store,research,request:async({input})=>{requests++;const p=JSON.parse(input);if(job.terminologyStatus==='ready')assert(p.glossary.length);return response(input);}});
  assert(sawPartial);assert.equal(job.terminologyStatus,'ready');assert.equal(store.data.cache.get(job.cacheKey).glossary[0].target,'遊戲');assert.equal(job.status,'completed');
  const failed=newJob();await translateProgressively(failed,'test',new AbortController().signal,()=>{}, {...memory(),research:async()=>{throw new Error('方案使用量已達限制');},request:async({input})=>response(input)});assert.equal(failed.status,'completed',failed.error);assert.equal(failed.terminologyStatus,'failed');assert(failed.warnings?.some(s=>s.includes('搜尋未完成')));
});
test('GPT-6 搜尋必須有實際 tool 紀錄與全繁中詞彙；不能拿模型猜測冒充查證',async()=>{
  const job=newJob();const request=async a=>{assert.equal(a.settings.model,'gpt-6-astra');assert(a.webSearch);a.onResponse({output:[{type:'web_search_call',status:'completed'}]});return {glossary:[{source:'Nemesis',meaning:'一款合作科幻桌遊',category:'game',usage:'chinese',target:'復仇女神號',urls:['https://example.com/rules']}]};};
  const [nemesis]=await researchTerminology(job,'test',null,request);assert.equal(nemesis.target,'復仇女神號');assert.equal(nemesis.meaning,'一款合作科幻桌遊');
  let instructions='';await researchTerminology(job,'test',null,async a=>{instructions=a.instructions;return request(a);});
  assert.match(instructions,/依前後文確定它在這部影片裡到底指什麼/);assert.match(instructions,/用 meaning 的情境去搜尋/);
  await assert.rejects(researchTerminology(job,'test',null,async()=>({glossary:[]})),/搜尋紀錄/);
});
test('術語表：依搜尋判斷的通用說法決定保留原文或用中文（含音譯）；沒有佐證不採用；拒絕韓日文與缺少本片意思',async()=>{
  const term=(source,usage,target,urls=[],category='other')=>({source,meaning:`${source} 在本片的意思`,category,usage,target,urls});
  const glossary=sanitizeGlossary([term('Python','original','Python',[],'programming'),term('Guido van Rossum','chinese','吉多·范羅蘇姆',['https://zh.wikipedia.org/wiki/x'],'person'),term('Monty Python','chinese','蒙提·派森',['https://zh.wikipedia.org/wiki/y'],'work'),term('Docker','chinese','碼頭工人',[],'product'),term('Uber','original','優步',['https://example.com'],'product'),term('python','original','Python')]);
  assert.deepEqual(glossary.map(g=>[g.source,g.target,g.usage]),[['Python','Python','original'],['Guido van Rossum','吉多·范羅蘇姆','chinese'],['Monty Python','蒙提·派森','chinese'],['Docker','Docker','original'],['Uber','Uber','original']]);
  assert(glossary.every(g=>g.meaning.includes('本片')));
  const job=newJob(),search=r=>a=>{a.onResponse({output:[{type:'web_search_call',status:'completed'}]});return r;};
  await assert.rejects(researchTerminology(job,'test',null,search({glossary:[term('YouTube','chinese','優튜브',['https://example.com'],'product')]})),/繁體中文/);
  await assert.rejects(researchTerminology(job,'test',null,search({glossary:[{...term('Go','original','Go'),meaning:''}]})),/通用說法/);
});
test('術語表到了只重翻用到該名詞且譯法不同的段落，不整片重翻',()=>{
  const ranges=[{start:0,end:10},{start:10,end:20},{start:20,end:30}];
  const cues=[{startWord:0,endWord:10,en:'Python is a language.',zh:'派森是一種語言'},{startWord:10,endWord:20,en:'Python is popular.',zh:'Python 很熱門'},{startWord:20,endWord:30,en:'It was created in 1991.',zh:'它在 1991 年推出'}];
  assert.deepEqual(termRevisionRanges(ranges,cues,[{source:'Python',target:'Python'}]),[{start:0,end:10}]);
  assert.deepEqual(termRevisionRanges(ranges,cues,[]),[]);
});
