import { MSG,send } from '../shared/messages.js';
import { DEFAULT_STYLE,PROMPT_VERSION } from '../shared/constants.js';
import { $,bindAction,showError,notice,modeOptions,tabMessage } from '../shared/ui.js';
import { subtitleLines } from '../content/subtitle-renderer.js';
import { fillModels } from '../shared/model-select.js';
import { VIDEO_PATTERNS } from '../shared/platforms.js';
let settings, current=null,diag={},saveQueue=Promise.resolve(),diagTab=null,authLoading=null,modelAccount='';
const fields=[
 ['zhSize','中文大小 px','number',14,60,1],['enSize','原文大小 px','number',14,60,1],['zhColor','中文顏色','color'],['enColor','原文顏色','color'],['font','字幕字體','text'],['outline','黑色描邊','select',[[0,'無'],[1,'細'],[2,'中'],[3,'粗']]],['background','半透明黑底','checkbox'],['opacity','背景不透明度 %','number',0,100,1],['zhWeight','中文粗細','select',[[400,'一般'],[500,'適中'],[600,'稍粗'],[700,'粗體']]],['enWeight','英文粗細','select',[[400,'一般'],[500,'適中'],[600,'稍粗'],[700,'粗體']]],['lineHeight','行距','number',1,2,0.05],['width','最大寬度 %','number',50,90,1],['bottom','底部距離 %','number',0,30,1],['top','頂部距離 %','number',0,30,1]
];
for(const [name,title,type,min,max,step] of fields) {
  const label=document.createElement('label');label.textContent=title;
  const input=document.createElement(type==='select'?'select':'input');input.id=`style-${name}`;
  if(type==='select')for(const [value,text] of min)input.add(new Option(text,value));
  else {input.type=type;if(min!==undefined){input.min=min;input.max=max;input.step=step;}}
  label.append(input);$('#styleFields').append(label);
  input.addEventListener('input',()=>{if(type==='number' && !input.validity.valid)return;settings.style[name]=type==='checkbox'?input.checked:['number','select'].includes(type)?Number(input.value):input.value;preview();queueSave().catch(e=>showError(e.message));});
}
modeOptions($('#currentMode'));
$('#version').textContent=`${chrome.runtime.getManifest().version} 版`;
function fillStyle() {for(const [name,,type] of fields){const el=$(`#style-${name}`);if(type==='checkbox')el.checked=settings.style[name];else el.value=settings.style[name];}preview();}
function preview() {
  const s=settings.style,lines=subtitleLines([{en:'Context makes subtitles feel natural.',zh:'有了上下文，字幕讀起來就自然了。'}],$('#currentMode').value || 'both-en');
  for(const [box,list] of [[$('#previewTop'),lines.top],[$('#previewBottom'),lines.bottom]]) {
    box.replaceChildren();box.style.width=`${s.width}%`;box.style.fontFamily=s.font;box.style.lineHeight=String(s.lineHeight);
    for(const {lang,text} of list){const el=document.createElement('div');el.className='ytgpt-line';el.textContent=text;el.style.fontSize=`${lang==='zh'?s.zhSize:s.enSize}px`;el.style.color=lang==='zh'?s.zhColor:s.enColor;el.style.fontWeight=String(lang==='zh'?s.zhWeight:s.enWeight);el.style.textShadow=s.outline?`${s.outline}px 0 1px black, -${s.outline}px 0 1px black, 0 ${s.outline}px 1px black, 0 -${s.outline}px 1px black`:'none';el.style.background=s.background?`rgba(0,0,0,${s.opacity/100})`:'transparent';box.append(el);}
  }
  $('#previewTop').style.top=`${s.top}%`;$('#previewBottom').style.bottom=`${s.bottom}%`;
}
function queueSave() {const value=structuredClone(settings);delete value.hasConnection;saveQueue=saveQueue.catch(()=>{}).then(()=>send(MSG.SAVE,{settings:value})).then(()=>notice('設定已儲存並套用。'));return saveQueue;}
$('#autoTranslate').addEventListener('change',()=>{settings.autoTranslate=$('#autoTranslate').checked;queueSave().catch(e=>showError(e.message));});
for(const key of ['pauseForSubtitles','terminologyEnabled'])$('#'+key).addEventListener('change',()=>{settings[key]=$('#'+key).checked;queueSave().catch(e=>showError(e.message));});
async function readAuthStatus() {
  const a=await send(MSG.AUTH_STATUS);$('#authStatus').textContent=a.planEnabled?`已連接：${a.account.email} · 可使用 ChatGPT 方案用量`:a.error||(a.signedIn?'已登入，請授權使用 ChatGPT 方案。':'尚未登入。按下方按鈕，用 ChatGPT 帳號登入。');
  $('#connectionBadge').textContent=a.planEnabled?'已連接':a.signedIn?'等待授權':'尚未登入';$('#authStatus').classList.toggle('connected',a.planEnabled);$('#signIn').hidden=a.signedIn;$('#signIn').disabled=false;$('#enablePlan').hidden=!a.signedIn||a.planEnabled;$('#signOut').hidden=!a.signedIn;$('#selectAccount').disabled=!(a.accounts?.length);
  $('#accounts').replaceChildren(...(a.accounts||[]).map(x=>new Option(x.email,x.id)));if(a.account)$('#accounts').value=a.account.id;
  if(a.planEnabled&&modelAccount!==a.account.id){try{const models=await send(MSG.MODELS);const valid=fillModels($('#availableModels'),models,$('#model').value.trim());modelAccount=a.account.id;$('#modelStatus').textContent=valid?'帳號可用模型已載入。':'目前模型不可用，請選擇帳號可用模型。';}catch(e){$('#modelStatus').textContent=e.message;}}
  else if(!a.planEnabled){modelAccount='';$('#availableModels').disabled=true;$('#modelStatus').textContent='連線恢復或完成登入後會自動讀取可用模型。';}
}
async function authStatus() {if(authLoading)return authLoading;authLoading=readAuthStatus();try{return await authLoading;}finally{authLoading=null;}}
$('#availableModels').addEventListener('change',()=>{if($('#availableModels').value)$('#model').value=$('#availableModels').value;});
async function signIn(options={}){const button=options.enablePlan?$('#enablePlan'):$('#signIn');button.disabled=true;notice('正在開啟 OpenAI 登入…');try{await send(MSG.SIGN_IN,options);notice('請在新分頁完成登入與授權。完成後可直接回影片，這裡會自動更新。');}finally{button.disabled=false;}}
bindAction($('#signIn'),()=>signIn());
bindAction($('#addAccount'),()=>send(MSG.SIGN_IN,{newAccount:true}));
bindAction($('#enablePlan'),()=>signIn({enablePlan:true}));
bindAction($('#refreshAuth'),authStatus);
bindAction($('#selectAccount'),async()=>{await send(MSG.SELECT_ACCOUNT,{id:$('#accounts').value});await authStatus();});
bindAction($('#signOut'),async()=>{const r=await send(MSG.SIGN_OUT);await authStatus();notice(r.revoked?'已登出並撤銷 ChatGPT 授權。':'已登出本機；遠端撤銷未確認，請至 ChatGPT 設定中移除此應用授權。');});
async function saveModel() {const next={...settings,model:$('#model').value.trim(),reasoningEffort:$('#reasoningEffort').value};const value=await send(MSG.SAVE,{settings:next});settings={...value,hasConnection:settings.hasConnection};notice('模型設定已儲存。');}
bindAction($('#saveModel'),saveModel);
bindAction($('#test'),async()=>{const button=$('#test');button.disabled=true;notice('正在測試（會使用少量 ChatGPT 方案額度）…');try{await saveModel();await send(MSG.TEST);notice('✓ 模型與 ChatGPT 方案連線成功。');}finally{button.disabled=false;}});
bindAction($('#resetStyle'),()=>{settings.style={...DEFAULT_STYLE};fillStyle();return queueSave();});
$('#currentMode').addEventListener('change',async()=>{preview();if(!current)return;try{await tabMessage(diagTab,MSG.CONTENT_PREF,{pref:{mode:$('#currentMode').value}});notice('目前影片顯示模式已套用。');}catch(e){showError(e.message);}});
async function stats() {const s=await send(MSG.STATS);$('#cacheStats').textContent=`已儲存 ${s.videos} 支影片 · ${s.entries} 份翻譯 · 約 ${(s.bytes/1024/1024).toFixed(2)} MB`;}
bindAction($('#clearCurrent'),async()=>{await send(MSG.CLEAR,{current:true,tabId:diagTab});await stats();await diagnostics();notice('目前影片快取已清除。');});
bindAction($('#clearAll'),async()=>{await send(MSG.CLEAR);await stats();await diagnostics();notice('所有字幕快取已清除。');});
async function diagnostics() {
  const tabs=await chrome.tabs.query({url:VIDEO_PATTERNS});const tab=tabs.sort((a,b)=>Number(b.active)-Number(a.active)||(b.lastAccessed||0)-(a.lastAccessed||0))[0];diagTab=tab?.id;
  try{current=await send(MSG.DIAG,{tabId:diagTab});diag=current?.diagnostics || {extensionVersion:chrome.runtime.getManifest().version,model:settings.model,promptVersion:PROMPT_VERSION,jobStatus:'idle',error:'尚未開啟可讀取的 YouTube 或 Prime Video 影片頁面。'};}catch(e){current=null;diag={error:e.message};}
  $('#diagnostics').textContent=JSON.stringify(diag,null,2);$('#videoLabel').textContent=current?`目前影片：${current.title || current.videoId}`:'目前沒有可讀取的影片；可先調整外觀預览。';
  $('#currentMode').value=current?.pref.mode || 'both-en';preview();
  const jobs=await send(MSG.LIST_JOBS);const select=$('#jobs');select.replaceChildren(...jobs.filter(j=>j.status!=='completed').map(j=>new Option(`${j.videoId} · ${j.status} · ${j.progress}%`,j.jobId)));
}
bindAction($('#refreshDiag'),diagnostics);
bindAction($('#copyDiag'),async()=>{await diagnostics();await navigator.clipboard.writeText(JSON.stringify(diag,null,2));notice('診斷資訊已複製。');});
bindAction($('#resumeJob'),async()=>{if(!$('#jobs').value)throw new Error('沒有可繼續的工作。');await send(MSG.RESUME,{jobId:$('#jobs').value});await diagnostics();notice('已繼續背景翻譯。');});
bindAction($('#cancelJob'),async()=>{if(!$('#jobs').value)throw new Error('沒有可取消的工作。');await send(MSG.CANCEL,{jobId:$('#jobs').value});await diagnostics();notice('已取消工作並保留進度。');});
(async()=>{try{settings=await send(MSG.SETTINGS);$('#model').value=settings.model;$('#reasoningEffort').value=settings.reasoningEffort;for(const key of ['autoTranslate','pauseForSubtitles','terminologyEnabled'])$('#'+key).checked=settings[key];fillStyle();await authStatus();await stats();await diagnostics();}catch(e){showError(e.message);}})();
let authTimer,authStopped=false;
async function pollAuth() {try{if(!document.hidden)await authStatus();}catch(e){$('#authStatus').textContent=e.message;}finally{if(!authStopped)authTimer=setTimeout(pollAuth,5000);}}
authTimer=setTimeout(pollAuth,5000);
window.addEventListener('focus',()=>{if(settings)authStatus().catch(e=>{$('#authStatus').textContent=e.message;});});
window.addEventListener('pagehide',()=>{authStopped=true;clearTimeout(authTimer);});
