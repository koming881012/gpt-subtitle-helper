import { DEFAULT_SETTINGS, ACTIVE_STATUSES, PROMPT_VERSION } from '../shared/constants.js';
import { MSG,send } from '../shared/messages.js';
import { currentVideoId,findVideoElement,findPlayer,watchNavigation,isPrime } from './platform-detector.js';
import { validatePrimeCaptionUrl } from '../shared/platforms.js';
import { primeCaptionSource } from './prime-caption-parser.js';
import { englishTracks,sourceTracks,nativeChineseTracks } from './caption-detector.js';
import { languageName } from '../shared/languages.js';
import { fetchVideoCaptionSource } from './caption-source.js';
import { fetchTranscriptSource } from './transcript-source.js';
import { SubtitleRenderer } from './subtitle-renderer.js';
import { SubtitleSync } from './subtitle-sync.js';
import { log,publicTrack,safeFilename } from '../shared/utils.js';
import { toSRT } from '../export/srt.js';
import { toVTT } from '../export/vtt.js';
import { playableSeconds } from '../shared/subtitle-buffer.js';
import { AutoTranslationGate,autoTranslationLanguageNotice } from './auto-translate.js';
import {SubtitleBufferController,availableSubtitleSeconds} from './subtitle-buffer-controller.js';
import {subtitleBackup} from '../export/subtitle-file.js';
import {subtitleTimeMs} from '../shared/subtitle-timing.js';
import {modelLabel,EFFORT_LABELS} from '../shared/model-label.js';
const CHANNEL='ytgpt-player-bridge-v1';
const BILINGUAL=['both-en','both-zh','split-en','split-zh'];
let lastBilingual='both-en';
const extensionVersion=chrome.runtime.getManifest().version;
document.documentElement?.setAttribute('data-ytgpt-extension-version',extensionVersion);
let state={videoId:null,meta:null,tracks:[],track:null,job:null,cache:null,pref:{enabled:true,mode:'zh'},settings:DEFAULT_SETTINGS,error:null};
let epoch=0,startSequence=0,renderer=null,sync=null,control=null,playerObserver=null,playerTimer=null,requestTimer=null,fetchController=null,starting=false,refreshing=false,priorityVideo=null,bufferController=null,lastPriority=0;
const prioritize=()=>{if(state.job&&ACTIVE_STATUSES.includes(state.job.status))send(MSG.PRIORITY,{jobId:state.job.jobId,playheadMs:Math.max(0,subtitleTimeMs(priorityVideo?.currentTime || 0,state.pref.subtitleOffsetMs))}).catch(()=>{});};
const trackPlayhead=()=>{if(Date.now()-lastPriority>3000){lastPriority=Date.now();prioritize();}};
const requests=new Map();
const autoTranslation=new AutoTranslationGate();
function maybeAutoTranslate(){if(contextAlive()&&autoTranslation.take({...state,starting}))act(()=>start({automatic:true})).catch(()=>{});}
let contextExpired=false,stopNavigation=null;
function contextAlive() {
  if(contextExpired)return false;
  if(chrome.runtime.id)return true;
  contextExpired=true;epoch++;
  const host=control?.parentElement;
  cleanup();stopNavigation?.();
  for(const request of requests.values()){clearTimeout(request.timer);request.resolve(null);}requests.clear();
  if(host?.isConnected){const notice=document.createElement('p'),reload=document.createElement('button');notice.id='ytgpt-reload-notice';notice.textContent='字幕插件已更新，請重新整理此影片頁面。';reload.textContent='重新整理影片';reload.addEventListener('click',()=>location.reload());notice.append(reload);host.prepend(notice);}
  return false;
}
function bridge(type='REQUEST',payload={},signal) {return new Promise((resolve,reject)=>{
  const id=crypto.randomUUID(),cancel=()=>{if(type==='YOUTUBE_SOURCE')window.postMessage({channel:CHANNEL,type:'CANCEL_SOURCE',requestId:id},location.origin);};
  const finish=(value,error)=>{clearTimeout(timer);requests.delete(id);signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
  const abort=()=>{cancel();finish(null,signal.reason || new DOMException('Aborted','AbortError'));};
  const timer=setTimeout(()=>{cancel();finish(null,type==='REQUEST'?null:new Error('播放器字幕讀取逾時，請重新整理影片後再試。'));},type==='REQUEST'?1500:type==='YOUTUBE_SOURCE'?22000:35000);
  requests.set(id,{resolve:value=>finish(value),reject:error=>finish(null,error),timer});signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted){abort();return;}
  window.postMessage({channel:CHANNEL,type,requestId:id,...payload},location.origin);
});}
window.addEventListener('message',event=>{if(event.source!==window || event.origin!==location.origin || event.data?.channel!==CHANNEL || event.data.type!=='RESPONSE')return;const req=requests.get(event.data.requestId);if(req){event.data.error?req.reject(new Error(event.data.error)):req.resolve(event.data.data);}});
function cleanup() {
  sync?.destroy();renderer?.destroy();bufferController?.destroy();bufferController=null;control?.remove();playerObserver?.disconnect();clearInterval(playerTimer);clearTimeout(requestTimer);fetchController?.abort();
  sync=null;renderer=null;control=null;playerObserver=null;playerTimer=null;starting=false;startSequence++;
  priorityVideo?.removeEventListener('seeked',prioritize);priorityVideo?.removeEventListener('timeupdate',trackPlayhead);priorityVideo=null;
}
function snapshot() {return {platform:isPrime()?'primevideo':'youtube',videoId:state.videoId,title:state.meta?.title || '',tracks:state.tracks.map(publicTrack),track:publicTrack(state.track),job:state.job,hasCache:Boolean(state.cache&&!state.cache.partial),hasPlayable:Boolean(state.cache?.translatedCues?.length),partial:Boolean(state.cache?.partial),waitingForSubtitles:Boolean(bufferController?.held),playbackError:bufferController?.resumeError||null,importedSubtitles:Boolean(state.cache?.imported),bufferedSeconds:Math.floor(availableSubtitleSeconds(state.cache,subtitleTimeMs(findVideoElement()?.currentTime || 0,state.pref.subtitleOffsetMs),(state.meta?.duration||0)*1000)),cueCount:state.cache?.sourceCues?.length || state.job?.totalCues || 0,pref:state.pref,model:state.settings.model,promptVersion:state.cache?.promptVersion||state.job?.promptVersion||PROMPT_VERSION,error:state.error,live:state.meta?.isLive,ready:Boolean(state.meta),nativeChinese:Boolean(nativeChineseTracks(state.meta?.captionTracks).length),audioLanguage:state.meta?.audioLanguage||null,autoTranslateBlockedReason:state.settings.autoTranslate&&state.track?autoTranslationLanguageNotice(state.meta,state.track):'',starting};}
function diagnostics() {const s=snapshot();return {extensionVersion,videoId:s.videoId,audioLanguage:s.audioLanguage,audioLanguageSource:state.meta?.audioLanguageSource||null,autoTranslateBlockedReason:s.autoTranslateBlockedReason,captionTrack:s.track,cueCount:s.cueCount,cacheStatus:s.hasCache?'hit':s.hasPlayable?'partial':'miss',bufferedSeconds:s.bufferedSeconds,terminologyStatus:s.job?.terminologyStatus || state.cache?.terminologyStatus || null,model:s.model,promptVersion:s.promptVersion,jobId:s.job?.jobId || null,jobStatus:s.job?.status || 'idle',error:s.error || s.job?.error || null,warnings:[...new Set([...(state.cache?.warnings || []),...(s.job?.warnings || [])])]};}
// Prime Video 仍只翻英文；YouTube 可用英文或日文，並優先選影片原音語言的字幕。
const tracksFor=meta=>isPrime()?englishTracks(meta.captionTracks):sourceTracks(meta.captionTracks,meta);
// 來源語言：翻譯完成後以內容判斷的結果為準（YouTube 標的語言可能錯），否則用字幕軌標示。
const trackLanguage=()=>languageName(state.cache?.sourceLanguage||state.track?.languageCode||'en');
function statusText() {
  if(state.error)return state.error;
  if(bufferController?.resumeError)return bufferController.resumeError;
  if(bufferController?.held)return '正在等待中文字幕緩衝，準備好後會自動播放…';
  if(!state.meta)return isPrime()?'正在等待 Prime Video 英文字幕；若已開始播放仍未偵測到，請重新整理影片頁面。':'正在偵測影片與字幕…';
  if(state.meta.isLive)return '第一版不支援直播字幕';
  if(starting)return `正在取得${trackLanguage()}字幕…`;
  if(state.cache?.partial&&ACTIVE_STATUSES.includes(state.job?.status))return `已可顯示中文字幕 · 目前位置已準備 ${snapshot().bufferedSeconds} 秒，背景繼續翻譯 · ${state.job.progress}%`;
  if(state.job && ACTIVE_STATUSES.includes(state.job.status))return `${state.job.phase} ${state.job.progress}% · ${state.job.translatedCues} / ${state.job.totalCues}`;
  if(state.job?.error)return state.job.error;
  if(state.job?.status==='cancelled')return '已取消，可從目前進度繼續';
  if(state.cache?.partial)return '已載入部分中文字幕，可接續翻譯';
  if(state.cache)return `✓ 已載入本機中文字幕 · 字幕${state.pref.enabled?'已開啟':'已關閉'}`;
  if(state.track&&nativeChineseTracks(state.meta?.captionTracks).length)return '這支影片已有中文字幕，已略過自動翻譯。可在播放器 CC 選中文，或按「仍用 GPT 翻譯」產生台灣用語字幕。';
  if(state.settings.autoTranslate&&state.track&&autoTranslationLanguageNotice(state.meta,state.track))return autoTranslationLanguageNotice(state.meta,state.track);
  return state.track?`${state.track.autoGenerated?'YouTube 自動':'人工'}${trackLanguage()} CC ✓`:'這支影片沒有可翻譯的英文或日文 CC';
}
function mount() {
  if(!contextAlive())return;
  const video=findVideoElement(),player=findPlayer(video);if(!video||!player){sync?.destroy();renderer?.destroy();sync=null;renderer=null;return;}
  if(priorityVideo!==video){priorityVideo?.removeEventListener('seeked',prioritize);priorityVideo?.removeEventListener('timeupdate',trackPlayhead);priorityVideo=video;video.addEventListener('seeked',prioritize);video.addEventListener('timeupdate',trackPlayhead);bufferController?.replaceVideo(video,player);}
  if(!bufferController)bufferController=new SubtitleBufferController(video,()=>({...state,starting}),()=>updateControl(),player);
  if(renderer?.player!==player || sync?.video && sync.video!==video) {sync?.destroy();renderer?.destroy();renderer=null;sync=null;}
  if(!renderer)renderer=new SubtitleRenderer(player,state.settings.style,state.pref.mode);
  if(!control?.isConnected) {
    control?.remove();control=document.createElement('div');control.id='ytgpt-control';const root=control.attachShadow({mode:'open'});
    root.innerHTML=`<style>:host{color:#edf2fa;font:13px/1.5 system-ui,"Microsoft JhengHei",sans-serif}*{box-sizing:border-box}button,select{font:inherit;background:#202b3c;color:#edf2fa;border:1px solid #46556d;border-radius:9px;padding:7px 12px;cursor:pointer}button:hover{background:#2e3c51}button:disabled{opacity:.5;cursor:default}.primary{background:#a7d0ff;color:#102947;font-weight:700;border-color:#a7d0ff}.primary:hover{background:#c3dfff}details.panel{background:rgba(16,21,31,.96);border:1px solid #344156;border-radius:12px;padding:8px 14px;max-width:520px;box-shadow:0 6px 22px #0003}details.panel>summary{cursor:pointer;font-weight:600;min-height:26px;display:flex;align-items:center;gap:8px;list-style:none}details.panel>summary::-webkit-details-marker{display:none}.mark{display:inline-grid;place-items:center;width:22px;height:22px;border-radius:6px;background:#a7d0ff;color:#102947;font-size:13px;font-weight:800}.badge{font-size:12px;font-weight:600;color:#a7b4c8;border:1px solid #344156;border-radius:999px;padding:0 8px}.badge.ok{color:#91dfb9;border-color:#2f5246}.badge.busy{color:#a7d0ff;border-color:#405673}.badge.warn{color:#ffd99a;border-color:#6b5228}.badge:empty{display:none}.chev{margin-left:auto;color:#a7b4c8;font-size:11px}details.panel[open] .chev{transform:rotate(180deg)}.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0}p{margin:8px 0;color:#b7c6da}#status{color:#edf2fa;white-space:pre-wrap}.muted{color:#a7b4c8;font-size:12px}.muted:empty{display:none}.bar{height:6px;border-radius:6px;background:#344156;overflow:hidden}.bar i{display:block;height:100%;width:0;background:#a7d0ff;transition:width .3s}.seg{display:inline-flex;border:1px solid #46556d;border-radius:9px;overflow:hidden}.seg button{border:0;border-radius:0;padding:6px 12px}.seg button+button{border-left:1px solid #46556d}.seg button[aria-checked=true]{background:#a7d0ff;color:#102947;font-weight:700}details.more{border-top:1px solid #344156;margin-top:6px;padding-top:4px}details.more>summary{cursor:pointer;color:#a7b4c8;padding:4px 0}select{max-width:100%}label{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}:focus-visible{outline:3px solid #93c5fd;outline-offset:2px}[hidden]{display:none!important}</style><details class="panel"><summary><span class="mark" aria-hidden="true">中</span>AI 字幕<span id="badge" class="badge"></span><span class="chev" aria-hidden="true">▼</span></summary><p id="status" role="status"></p><div id="bar" class="bar" hidden><i id="bar-fill"></i></div><div class="row"><button id="sign-in" class="primary" hidden>用 ChatGPT 登入</button><button id="start" class="primary">產生繁中字幕</button><button id="cancel">停止</button></div><div class="row"><div class="seg" role="radiogroup" aria-label="字幕顯示"><button data-mode="zh" role="radio">中文</button><button data-mode="both" role="radio">雙語</button><button data-mode="en" role="radio">原文</button></div><button id="toggle" aria-pressed="true">隱藏 AI 字幕</button></div><p id="model" class="muted"></p><p id="terminology" class="muted"></p><details class="more"><summary>更多：字幕來源、下載、設定</summary><label>原文字幕來源<select id="track" aria-label="原文字幕來源"></select></label><div class="row"><button id="save-srt">另存繁中 SRT</button><button id="save-json">備份字幕</button><button id="load-file">載入字幕檔</button><button id="options">⚙ 設定</button></div><input id="subtitle-file" type="file" accept=".srt,.vtt,.json" hidden><p id="file-status" class="muted"></p></details></details>`;
    const clickAction=fn=>{act(fn).catch(()=>{});};
    root.querySelector('#start').addEventListener('click',()=>clickAction(start));root.querySelector('#cancel').addEventListener('click',()=>clickAction(cancel));
    root.querySelector('#sign-in').addEventListener('click',()=>clickAction(()=>send(MSG.SIGN_IN)));
    root.querySelector('#toggle').addEventListener('click',()=>clickAction(()=>setPref({enabled:!state.pref.enabled})));
    root.querySelector('#options').addEventListener('click',()=>clickAction(()=>send(MSG.OPTIONS)));
    for(const b of root.querySelectorAll('.seg button'))b.addEventListener('click',()=>clickAction(()=>setPref({mode:b.dataset.mode==='both'?(BILINGUAL.includes(state.pref.mode)?state.pref.mode:lastBilingual):b.dataset.mode,enabled:true})));
    root.querySelector('#track').addEventListener('change',e=>clickAction(()=>chooseTrack(e.target.value)));
    root.querySelector('#save-json').addEventListener('click',()=>clickAction(()=>exportSubtitle('json','bilingual')));
    root.querySelector('#save-srt').addEventListener('click',()=>clickAction(()=>exportSubtitle('srt','zh')));
    root.querySelector('#load-file').addEventListener('click',()=>root.querySelector('#subtitle-file').click());
    root.querySelector('#subtitle-file').addEventListener('change',e=>{const file=e.target.files[0];e.target.value='';clickAction(()=>importSubtitle(file));});
  }
  const below=document.querySelector('ytd-watch-flexy #below');
  if(isPrime()){control.classList.add('ytgpt-prime-control');if(control.parentElement!==player)player.append(control);}
  else if(below&&control.parentElement!==below)below.prepend(control);
  else if(!control.isConnected){const host=player.closest('#player') || player.closest('ytd-player') || player;host.insertAdjacentElement('afterend',control);}
  updateControl();apply();
}
function updateControl() {
  if(!contextAlive()||!control?.isConnected)return;const root=control.shadowRoot,busy=starting || ACTIVE_STATUSES.includes(state.job?.status);
  const failed=Boolean(state.error||state.job?.error&&!busy),progress=state.job?.progress || 0,connected=state.settings.hasConnection!==false;
  root.querySelector('#status').textContent=!connected&&!state.cache&&state.track?`用 ChatGPT 登入後，就能把這支影片的${trackLanguage()}字幕翻成中文。`:statusText();
  const badge=root.querySelector('#badge');[badge.textContent,badge.className]=state.cache&&!state.cache.partial?['✓ 已就緒','badge ok']:busy?[`翻譯中 ${progress}%`,'badge busy']:failed?['需要處理','badge warn']:state.job?.status==='cancelled'?['已暫停','badge warn']:!connected&&state.track?['需要登入','badge warn']:state.track?['可翻譯','badge']:['',''];
  root.querySelector('#bar').hidden=!busy;root.querySelector('#bar-fill').style.width=`${progress}%`;
  root.querySelector('#sign-in').hidden=connected||Boolean(state.cache);
  const startButton=root.querySelector('#start');startButton.disabled=busy || !state.track || state.meta?.isLive;startButton.hidden=!connected&&!state.cache||Boolean(state.cache&&!state.cache.partial&&state.pref.enabled);
  startButton.textContent=busy?`翻譯中… ${progress}%`:['error','cancelled'].includes(state.job?.status)?'繼續翻譯':state.cache&&!state.cache.partial?'顯示中文字幕':nativeChineseTracks(state.meta?.captionTracks).length?'仍用 GPT 翻譯':'產生繁中字幕';
  root.querySelector('#cancel').hidden=!busy;
  const toggle=root.querySelector('#toggle');toggle.hidden=!state.videoId;toggle.textContent=state.pref.enabled?'隱藏 AI 字幕':'顯示 AI 字幕';toggle.setAttribute('aria-pressed',String(Boolean(state.pref.enabled)));
  if(BILINGUAL.includes(state.pref.mode))lastBilingual=state.pref.mode;
  for(const b of root.querySelectorAll('.seg button'))b.setAttribute('aria-checked',String(b.dataset.mode==='both'?BILINGUAL.includes(state.pref.mode):b.dataset.mode===state.pref.mode));
  const model=state.cache?.imported||!connected&&!state.cache?'':busy?state.job?.model||state.settings.model:state.cache?.model||state.settings.model;
  root.querySelector('#model').textContent=model?`${busy?'正在使用':state.cache?'翻譯模型':'將使用'} ${modelLabel(model)}${!state.cache||busy?` · ${EFFORT_LABELS[state.settings.reasoningEffort]||''}`:''}（你的 ChatGPT 方案）`:'';
  const terms=diagnostics();root.querySelector('#terminology').textContent=terms.terminologyStatus==='searching'?'正在搜尋中文專有名詞…':terms.terminologyStatus==='ready'?'已套用中文專有名詞表。':terms.terminologyStatus==='failed'?'專有名詞搜尋未完成，字幕使用一般譯名。':'';
  root.querySelector('#track').disabled=busy;
  root.querySelector('#save-json').hidden=root.querySelector('#save-srt').hidden=!state.cache||Boolean(state.cache.partial);
  root.querySelector('#file-status').textContent=state.cache?.imported?'已載入本機字幕檔，不使用 GPT 額度。':state.cache?`字幕已存在這台電腦${state.cache.partial?'；其餘接續翻譯。':'，再次觀看不重翻。'}`:'';
  const trackSelect=root.querySelector('#track');const signature=state.tracks.map(t=>t.sourceTrackId).join('|');
  if(trackSelect.dataset.signature!==signature){trackSelect.replaceChildren(...state.tracks.map(t=>new Option(`${t.name || t.languageCode}（${t.autoGenerated?'自動':'人工'}）`,t.sourceTrackId)));trackSelect.dataset.signature=signature;}
  trackSelect.value=state.track?.sourceTrackId || '';
}
function apply() {
  if(!contextAlive()||!renderer)return;renderer.configure(state.settings.style,state.pref.mode);renderer.setEnabled(Boolean(state.cache && state.pref.enabled));
  const video=findVideoElement();
  if(state.cache && !sync && video)sync=new SubtitleSync(video,state.cache.translatedCues,cues=>renderer?.render(cues),()=>renderer?.player.classList.contains('ad-showing') || renderer?.player.classList.contains('ad-interrupting'),()=>state.pref.subtitleOffsetMs);
  sync?.update();
  bufferController?.check();
}
async function refreshCache(token=epoch) {
  if(!state.meta)return;
  const videoId=state.videoId,track=state.track,result=await send(MSG.LOOKUP,{meta:state.meta,track});
  if(token!==epoch || videoId!==state.videoId || track?.sourceTrackId!==state.track?.sourceTrackId)return;
  if((result.cache?.revision || 0)<(state.cache?.revision || 0))return;
  if(result.job?.jobId===state.job?.jobId&&(result.job?.updatedAt || 0)<(state.job?.updatedAt || 0))return;
  sync?.destroy();sync=null;Object.assign(state,result);state.settings=result.settings;updateControl();mount();
}
async function chooseTrack(id) {const track=state.tracks.find(t=>t.sourceTrackId===id);if(!track)return;state.track=track;state.cache=null;state.job=null;state.error=null;sync?.destroy();sync=null;renderer?.render([]);renderer?.setEnabled(false);await setPref({sourceTrackId:id});await refreshCache();maybeAutoTranslate();}
async function detect(id) {
  if(!contextAlive())return;
  if(id!==state.videoId) {epoch++;cleanup();state={videoId:id,meta:null,tracks:[],track:null,job:null,cache:null,pref:{enabled:true,mode:'zh'},settings:state.settings,error:null};}
  if(!id)return;
  const token=epoch;if(refreshing){requestTimer=setTimeout(()=>detect(currentVideoId()),200);return;}refreshing=true;
  try {
    const meta=await bridge();if(token!==epoch)return;
    if(!meta || meta.videoId!==id){mount();requestTimer=setTimeout(()=>detect(currentVideoId()),1500);return;}
    const previous=state.meta;state.meta=meta;
    if(previous&&meta.sourceRevision!==previous.sourceRevision){const freshTracks=tracksFor(meta);state.track=freshTracks.find(t=>t.sourceTrackId===state.track?.sourceTrackId)||freshTracks[0]||null;state.tracks=freshTracks;}
    if(!previous || !state.tracks.length) {
      state.tracks=tracksFor(meta);state.track=state.tracks[0] || null;state.error=null;
      log('video detected',id);if(state.track)log(`${state.track.autoGenerated?'auto':'human'} caption detected`,state.track.languageCode);
      const initial=await send(MSG.LOOKUP,{meta,track:state.track});if(token!==epoch)return;state.pref=initial.pref;const saved=state.tracks.find(t=>t.sourceTrackId===state.pref.sourceTrackId);if(saved)state.track=saved;await refreshCache(token);
    }
    mount();
    maybeAutoTranslate();
    if(!playerObserver){let scheduled=false;playerObserver=new MutationObserver(()=>{if(!scheduled){scheduled=true;requestAnimationFrame(()=>{scheduled=false;if(token===epoch)mount();});}});playerObserver.observe(document.querySelector('ytd-watch-flexy') || document.body,{childList:true,subtree:true});playerTimer=setInterval(()=>{if(token===epoch)mount();},2000);}
  } catch(e){if(token===epoch){state.error=e.message;updateControl();}}
  finally {refreshing=false;}
}
async function start({automatic=false}={}) {
  if(starting || ACTIVE_STATUSES.includes(state.job?.status))return;
  if(state.cache&&!state.cache.partial){await setPref({enabled:true});return;}
  const token=epoch,attempt=++startSequence;let meta=state.meta,track=state.track;if(!track)throw new Error('這支影片沒有可翻譯的英文或日文 CC。');
  state.error=null;starting=true;updateControl();
  try {
    await setPref({enabled:true});
    if(token!==epoch || attempt!==startSequence)return;
    // Refresh signed track URLs immediately before retrieval, including after SPA navigation.
    const fresh=await bridge();
    if(token!==epoch || attempt!==startSequence)return;
    if(fresh?.videoId===meta.videoId){const tracks=tracksFor(fresh);meta=fresh;track=tracks.find(t=>t.sourceTrackId===track.sourceTrackId)||tracks[0]||null;state.meta=meta;state.tracks=tracks;state.track=track;}
    if(automatic&&(nativeChineseTracks(meta.captionTracks).length||autoTranslationLanguageNotice(meta,track)))return;
    if(!track)throw new Error('這支影片沒有可翻譯的英文或日文 CC。');
    let result;
    const resume=['cancelled','error'].includes(state.job?.status);
    let source=null;
    if(!resume || !state.job.totalCues) {
      fetchController=new AbortController();
      if(isPrime()){validatePrimeCaptionUrl(track.baseUrl);const response=await bridge('PRIME_SOURCE',{videoId:meta.videoId,url:track.baseUrl},fetchController.signal);source=primeCaptionSource(response.raw,meta.duration);}
      else {for(let attempt=0;attempt<2;attempt++){try{source=await fetchVideoCaptionSource(track,meta,fetchController.signal,{transcript:(t,m,s)=>fetchTranscriptSource(t,m,s,{segments:()=>bridge('TRANSCRIPT_DATA',{videoId:m.videoId},s)}),player:(t,m,s)=>bridge('YOUTUBE_SOURCE',{videoId:m.videoId,track:{languageCode:t.languageCode,name:t.name,kind:t.kind||'',vssId:t.vssId}},s)});break;}catch(e){if(e.code!=='CAPTION_NOT_READY'||attempt===1)throw e;const updated=await bridge();if(updated?.videoId===meta.videoId){meta=updated;track=tracksFor(updated).find(t=>t.sourceTrackId===track.sourceTrackId)||track;}}}}
      if(token!==epoch || attempt!==startSequence)return;
    }
    const playheadMs=Math.max(0,subtitleTimeMs(findVideoElement()?.currentTime || 0,state.pref.subtitleOffsetMs));
    if(automatic&&(nativeChineseTracks(meta.captionTracks).length||autoTranslationLanguageNotice(meta,track)))return;
    result=resume?await send(MSG.RESUME,{jobId:state.job.jobId,meta,track,source,playheadMs}):await send(MSG.START,{meta,track,source,playheadMs});
    if(token!==epoch || attempt!==startSequence){if(result.job && attempt!==startSequence && token===epoch)await send(MSG.CANCEL,{jobId:result.job.jobId});return;}
    if(result.cache)state.cache=result.cache;else state.job=result.job;
  } finally {if(token===epoch && attempt===startSequence){starting=false;updateControl();mount();}}
}
async function cancel() {const token=epoch;startSequence++;fetchController?.abort();if(state.job?.jobId){await send(MSG.CANCEL,{jobId:state.job.jobId});await refreshCache(token);}if(token===epoch){starting=false;updateControl();}}
async function setPref(patch) {const id=state.videoId,token=epoch;const value=await send(MSG.PREF,{videoId:id,pref:patch});if(token===epoch){state.pref=value;updateControl();apply();if(patch.subtitleOffsetMs!==undefined)prioritize();}}
async function act(fn) {const token=epoch;try{return await fn();}catch(e){if(token!==epoch||e.name==='AbortError'||e.code==='VIDEO_CHANGED')return;state.error=e.message;updateControl();throw e;}}
async function exportSubtitle(format,language) {
  if(!state.cache||state.cache.partial)throw new Error('字幕仍在背景翻譯，全部完成後才能匯出。');
  const data=format==='json'?subtitleBackup(state.cache,state.meta):format==='vtt'?toVTT(state.cache.translatedCues,language):toSRT(state.cache.translatedCues,language);
  await send(MSG.SAVE_FILE,{videoId:state.videoId,title:state.meta.title,format,language:language==='zh'?'zh-TW':language,raw:data});return true;
}
async function importSubtitle(file){if(!file)return;if(file.size>10000000)throw new Error('字幕檔不可超過 10 MB。');const token=epoch,meta=state.meta||{videoId:state.videoId,title:document.title,duration:findVideoElement()?.duration};if(!meta.videoId)throw new Error('請先開啟影片。');const raw=await file.text();if(token!==epoch)return;const result=await send(MSG.IMPORT_FILE,{meta,raw,format:file.name.split('.').at(-1).toLowerCase()});if(token!==epoch)return;state.meta=meta;state.cache=result.cache;state.error=null;sync?.destroy();sync=null;await setPref({enabled:true,mode:'zh'});mount();}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(sender.id!==chrome.runtime.id)return;
  if(m.type===MSG.SETTINGS_CHANGED){const hasConnection=m.settings.hasConnection??state.settings.hasConnection;state.settings={...m.settings,hasConnection};updateControl();apply();if(m.cacheIdentityChanged){state.error=null;refreshCache().then(maybeAutoTranslate).catch(e=>{state.error=e.message;updateControl();});}else maybeAutoTranslate();return;}
  if(m.type===MSG.PREF_CHANGED && m.videoId===state.videoId){const offsetChanged=state.pref.subtitleOffsetMs!==m.pref.subtitleOffsetMs;state.pref=m.pref;apply();updateControl();if(offsetChanged)prioritize();return;}
  if(m.type===MSG.CONTENT_STATE){respond({ok:true,data:{...snapshot(),diagnostics:diagnostics()}});return;}
  if(m.type===MSG.UPDATE && m.videoId===state.videoId) {
    if(m.job?.jobId===state.job?.jobId&&(m.job.updatedAt||0)<(state.job.updatedAt||0))return;
    state.job=m.job;state.error=null;updateControl();if(m.job?.playableCues || m.job?.status==='completed')refreshCache().catch(e=>{state.error=e.message;updateControl();});return;
  }
  if(m.type===MSG.INVALIDATE && (!m.videoId || m.videoId===state.videoId)){sync?.destroy();sync=null;state.cache=null;renderer?.render([]);renderer?.setEnabled(false);refreshCache().catch(()=>{});return;}
  let action;
  if(m.type===MSG.CONTENT_START)action=start;
  if(m.type===MSG.CANCEL)action=cancel;
  if(m.type===MSG.EXPORT)action=()=>exportSubtitle(m.format,m.language);
  if(m.type===MSG.IMPORT_FILE)action=()=>importSubtitle({size:new TextEncoder().encode(m.raw||'').length,name:m.filename,text:async()=>m.raw});
  if(m.type===MSG.CONTENT_PREF)action=()=>{
    if(m.videoId&&m.videoId!==state.videoId)throw new Error('影片已切換，請重新調整目前影片的字幕時間。');
    if(m.command==='toggle-subtitles')return setPref({enabled:!state.pref.enabled});
    if(m.command==='cycle-mode'){const modes=['zh','both-en','en'];return setPref({mode:modes[(modes.indexOf(state.pref.mode)+1)%3]});}
    if(m.sourceTrackId)return chooseTrack(m.sourceTrackId);return setPref(m.pref || {});
  };
  if(action){act(action).then(data=>respond({ok:true,data})).catch(e=>respond({ok:false,error:e.message}));return true;}
});
send(MSG.SETTINGS).then(s=>{state.settings=s;apply();}).catch(()=>{});
stopNavigation=watchNavigation(id=>detect(id));
