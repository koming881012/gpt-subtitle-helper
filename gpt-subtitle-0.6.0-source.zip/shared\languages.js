// 可翻譯的來源語言。內部欄位沿用 en（原文）／zh（中文），en 不一定是英文。
export const SOURCE_LANGUAGES=Object.freeze({en:'英文',ja:'日文'});
export const languageName=code=>SOURCE_LANGUAGES[baseLanguage(code)]||String(code||'未知語言');
export function baseLanguage(code) {return String(code||'').toLowerCase().split(/[-_.]/)[0];}
export const isSourceLanguage=code=>Object.hasOwn(SOURCE_LANGUAGES,baseLanguage(code));
const KANA=/[\p{Script=Hiragana}\p{Script=Katakana}ー]/gu,HAN=/\p{Script=Han}/gu,HANGUL=/\p{Script=Hangul}/gu,LATIN=/[A-Za-z]/g;
export const hasKana=text=>/[\p{Script=Hiragana}\p{Script=Katakana}]/u.test(String(text||''));
const ENGLISH_COMMON=new Set(['the','and','to','of','that','is','it','you','we','this','with','for','have','are','was','from','they','will','can','your','my','but','not','so','a','in','i','what','just','be','on','do']);
// 依字幕「內容」判斷語言，不依 YouTube 標的語言（ASR 語言可能標錯，或其實是 AI 配音音軌的轉錄）。
export function detectTextLanguage(text) {
  const sample=String(text||'').slice(0,20000),count=re=>(sample.match(re)||[]).length;
  const kana=count(KANA),han=count(HAN),hangul=count(HANGUL),latin=count(LATIN);
  if(kana+han+hangul+latin<20)return null;
  if(hangul>(kana+han)&&hangul>latin/3)return 'ko';
  if(kana+han>latin/3)return kana>=(kana+han)*0.12?'ja':'zh';
  const words=sample.toLowerCase().match(/[a-z']+/g)||[],common=words.filter(w=>ENGLISH_COMMON.has(w));
  return new Set(common).size>=4&&common.length>=words.length*0.12?'en':'other';
}
export const detectCueLanguage=cues=>detectTextLanguage(cues.map(c=>c.text).join('\n'));
// 日文沒有空格：先用瀏覽器內建的斷詞，再把助詞、標點黏回前一個詞，切成適合斷句的短詞塊。
const segmenter=typeof Intl!=='undefined'&&Intl.Segmenter?new Intl.Segmenter('ja',{granularity:'word'}):null;
export function japaneseChunks(text) {
  const out=[];let glue=true;
  const pieces=segmenter?[...segmenter.segment(String(text))].map(s=>({text:s.segment,word:s.isWordLike})):String(text).split(/(\s+)/).map(t=>({text:t,word:true}));
  for(const piece of pieces) {
    const t=piece.text.replace(/\s+/g,'');
    if(!t){glue=false;continue;}
    const prev=out.at(-1),particle=/^[\p{Script=Hiragana}ー]{1,3}$/u.test(t);
    if(prev&&glue&&(!piece.word||particle&&!/[。！？!?]$/.test(prev))&&[...prev].length<14)out[out.length-1]=prev+t;
    else out.push(t);
    glue=true;
  }
  // 再併成約一個短語（最多 JA_CHUNK_CHARS 字）：詞塊太細時模型容易數錯編號，也浪費 token。句末標點後一定斷開。
  const merged=[];
  for(const chunk of out){const prev=merged.at(-1);if(prev&&!/[。！？!?」』]$/.test(prev)&&[...prev+chunk].length<=JA_CHUNK_CHARS)merged[merged.length-1]=prev+chunk;else merged.push(chunk);}
  return merged;
}
export const JA_CHUNK_CHARS=8;
// 詞塊切法改變時加一：已存的詞編號（翻譯進度）就對不上，要重新斷句。
export const JA_WORDS_VERSION=2;
export const tokenize=(text,lang)=>lang==='ja'?japaneseChunks(text):String(text).trim().split(/\s+/).filter(Boolean);
export const joinWords=(list,lang)=>list.join(lang==='ja'?'':' ');
