import test from 'node:test';
import assert from 'node:assert/strict';
import {transcriptSource,fetchTranscriptSource} from '../content/transcript-source.js';
import {parseCaptions} from '../content/caption-parser.js';
import {fetchVideoCaptionSource} from '../content/caption-source.js';
const rows=[{timestamp:'0:00',text:'Welcome & friends'},{timestamp:'0:06',text:'English auto generated captions'},{timestamp:'0:18',text:'Thank you'}];
test('原生轉錄稿產生可供既有翻譯流程讀取的完整來源與時間精度提示',()=>{
  const source=transcriptSource(rows,20),cues=parseCaptions(source.raw,20);
  assert.equal(source.format,'youtube-transcript-dom');assert.equal(source.warnings.length,1);assert.equal(cues.length,3);assert.equal(cues[1].text,rows[1].text);assert.equal(cues[0].endMs,6000);assert.equal(cues[2].endMs,20000);
  assert(transcriptSource(rows.slice(0,2),300).warnings.some(w=>w.includes('早於')));
  assert.equal(parseCaptions(transcriptSource([{timestamp:'1:10',text:'A late introduction.'},{timestamp:'4:30',text:'Speech ends before the long music outro.'}],600).raw).length,2);
  assert.throws(()=>transcriptSource([{timestamp:'0:65',text:'bad'}],20),/時間戳/);
  assert.throws(()=>transcriptSource([rows[0],rows[2],rows[1]],20),/時間軸/);
  assert.throws(()=>transcriptSource(rows.map(r=>({...r,text:''})),20),/空白/);
});
function panelFixture({search='',label='英文 (自動產生)',modern=false,sourceRows=rows,busy=false}={}) {
  let currentRows=sourceRows,clicks=0;
  const p={getClientRects:()=>[{}],closest:()=>null,matches:()=>modern,querySelector:s=>s.includes('#transcript-search-box-input')?{value:search}:s.endsWith('#label-text')?label?{textContent:label}:null:s==='[aria-busy="true"]'&&busy?{}:null,querySelectorAll:()=>currentRows.map(r=>({querySelector:s=>({textContent:s.includes('.segment-timestamp')?r.timestamp:r.text})}))};
  const button={textContent:'Show transcript',getClientRects:()=>[{}],closest:()=>null,click:()=>{clicks++;if(doc.nextRows)currentRows=doc.nextRows;}};
  const doc={querySelector:()=>null,querySelectorAll:s=>s.includes('panel-content-visible')?[p]:s.includes('description-transcript')?[button]:[],get clicks(){return clicks;}};return doc;
}
test('自動啟動早於影片說明載入時，等待入口出現再展開轉錄稿',async()=>{
  const base=panelFixture(),started=Date.now();let expanded=0,opened=false;
  const doc={querySelector:()=>Date.now()-started>=300?{getClientRects:()=>[{}],closest:()=>null,click:()=>{expanded++;}}:null,querySelectorAll:s=>s.includes('panel-content-visible')?(opened?base.querySelectorAll(s):[]):s.includes('description-transcript')&&expanded?[{textContent:'Show transcript',getClientRects:()=>[{}],closest:()=>null,click:()=>{opened=true;}}]:[]};
  const result=await fetchTranscriptSource({name:'英文 (自動產生)'},{videoId:'delayed',duration:20},null,{doc,videoId:()=> 'delayed'});
  assert.equal(expanded,1);assert.equal(parseCaptions(result.raw).length,3);
});
test('YouTube hydration 替換已點擊的說明按鈕後，會展開新按鈕而非等到失敗',async()=>{
  const base=panelFixture();let stage=0,opened=false,clicks=0;
  const expand1={getClientRects:()=>[{}],closest:()=>null,click:()=>{stage=1;clicks++;}},expand2={getClientRects:()=>[{}],closest:()=>null,click:()=>{stage=2;clicks++;}};
  const doc={querySelector:()=>stage===0?expand1:expand2,querySelectorAll:s=>s.includes('panel-content-visible')?(opened?base.querySelectorAll(s):[]):stage===2?[{textContent:'Show transcript',getClientRects:()=>[{}],closest:()=>null,click:()=>{opened=true;}}]:[]};
  const result=await fetchTranscriptSource({name:'英文 (自動產生)'},{videoId:'hydration',duration:20},null,{doc,videoId:()=> 'hydration'});assert.equal(clicks,2);assert.equal(parseCaptions(result.raw).length,3);
});

test('新版側欄開啟說明後取得轉錄稿，即使字幕下載為空；支援中英文入口',async()=>{
  for(const label of ['說明，鍵盤快速鍵 (Shift + 1)','说明，键盘快捷键 (Shift + 1)','Description, keyboard shortcut (Shift + 1)']){
    const base=panelFixture({modern:true,label:''});let selected=false,opened=false,tabClicks=0,transcriptClicks=0;
    const tab={textContent:'',getAttribute:key=>key==='aria-label'?label:key==='aria-selected'?String(selected):null,getClientRects:()=>[{}],closest:()=>null,click:()=>{tabClicks++;selected=true;}};
    const button={textContent:'Show transcript',getClientRects:()=>[{}],closest:()=>null,click:()=>{transcriptClicks++;opened=true;}};
    // A hidden legacy expander must not mask the new side rail.
    const doc={querySelector:()=>({getClientRects:()=>[],closest:()=>null,click:()=>assert.fail('hidden expander')}),querySelectorAll:s=>s.includes('panel-content-visible')?(opened?base.querySelectorAll(s):[]):s.includes('yt-side-rail-view-model')?[tab]:s.includes('description-transcript')&&selected?[button]:[]};
    const track={languageCode:'en',name:'英文 (自動產生)'},meta={videoId:'x-a5Kn9p8WM',duration:20,captionTracks:[track]};
    const source=await fetchVideoCaptionSource(track,meta,null,{download:async()=>{throw new Error('YouTube 回傳空字幕或非字幕資料。');},transcript:(t,m,s)=>fetchTranscriptSource(t,m,s,{doc,videoId:()=>meta.videoId})});
    assert.equal(parseCaptions(source.raw).length,3);assert.equal(tabClicks,1);assert.equal(transcriptClicks,1);
  }
});

test('說明側欄已開啟、隱藏或停用時不反覆切換，也不點擊留言分頁',async()=>{
  const tab=(label,attrs={},visible=true)=>({textContent:'',getAttribute:key=>key==='aria-label'?label:attrs[key]??null,getClientRects:()=>visible?[{}]:[],closest:()=>null,click:()=>assert.fail('must not toggle')});
  const tabs=[tab('說明，鍵盤快速鍵 (Shift + 1)',{'aria-selected':'true'}),tab('Description',{'aria-disabled':'true'}),tab('說明',{},false),tab('留言，鍵盤快速鍵 (Shift + 2)')];
  const doc={querySelector:()=>null,querySelectorAll:s=>s.includes('yt-side-rail-view-model')?tabs:[]};
  await assert.rejects(fetchTranscriptSource({languageCode:'en'},{videoId:'abc'},AbortSignal.timeout(300),{doc,videoId:()=> 'abc'}),{name:'TimeoutError'});
});

test('SPA 轉錄稿首次開啟無效時自動重開，面板載入後不再點擊',async()=>{
  const base=panelFixture();let clicks=0,opened=false;
  const button={textContent:'Show transcript',getClientRects:()=>[{}],closest:()=>null,click:()=>{clicks++;if(clicks===2)opened=true;}};
  const doc={querySelector:()=>null,querySelectorAll:s=>s.includes('panel-content-visible')?(opened?base.querySelectorAll(s):[]):s.includes('description-transcript')?[button]:[]};
  const result=await fetchTranscriptSource({name:'英文 (自動產生)'},{videoId:'discarded-click',duration:20},null,{doc,videoId:()=> 'discarded-click'});
  assert.equal(clicks,2);assert.equal(parseCaptions(result.raw).length,3);
});
test('原生 DOM 備援會等待完整字幕穩定；拒絕搜尋結果、語言不符、SPA 與取消',async()=>{
  const meta={videoId:'abc',duration:20},track={name:'英文 (自動產生)'};
  const source=await fetchTranscriptSource(track,meta,new AbortController().signal,{doc:panelFixture(),videoId:()=>meta.videoId});assert.equal(parseCaptions(source.raw).length,3);
  await assert.rejects(fetchTranscriptSource(track,meta,null,{doc:panelFixture({search:'test'}),videoId:()=>meta.videoId}),/清空/);
  await assert.rejects(fetchTranscriptSource(track,meta,null,{doc:panelFixture({label:'日本語'}),videoId:()=>meta.videoId}),/語言/);
  await assert.rejects(fetchTranscriptSource(track,meta,null,{doc:panelFixture(),videoId:()=> 'other'}),/切換/);
  const cancelled=new AbortController();cancelled.abort();await assert.rejects(fetchTranscriptSource(track,meta,cancelled.signal,{doc:panelFixture(),videoId:()=>meta.videoId}),{name:'AbortError'});
});

test('新版章節轉錄稿支援無語言標籤、混合字幕語言並阻擋非英文及搜尋結果',async()=>{
  const track={name:'英文 (自動產生)',languageCode:'en'},meta={videoId:'modern',duration:20,captionTracks:[track]};
  const result=await fetchTranscriptSource(track,meta,null,{doc:panelFixture({modern:true,label:''}),videoId:()=>meta.videoId});assert.equal(parseCaptions(result.raw).length,3);
  await assert.rejects(fetchTranscriptSource(track,meta,null,{doc:panelFixture({modern:true,label:'',search:'game'}),videoId:()=>meta.videoId}),/清空/);
  const multi={...meta,captionTracks:[track,{languageCode:'fr'}]},englishRows=rows.map(r=>({...r,text:'This is the game that we have and you can play with your friends.'}));
  const verified=await fetchTranscriptSource(track,multi,null,{doc:panelFixture({modern:true,label:'',sourceRows:englishRows}),videoId:()=>meta.videoId});assert(verified.warnings.some(w=>w.includes('來源標籤')));
  await assert.rejects(fetchTranscriptSource(track,multi,null,{doc:panelFixture({modern:true,label:'',sourceRows:rows.map(r=>({...r,text:'こんにちは、このゲームについて説明します。'}))}),videoId:()=>meta.videoId}),/確認為英文/);
});

test('同一頁切換影片時重新開啟轉錄稿，不沿用前片段落；載入中不接受字幕',async()=>{
  const track={name:'英文 (自動產生)',languageCode:'en'},doc=panelFixture({modern:true,label:''});let id='first';
  const meta={videoId:id,duration:20,captionTracks:[track]};await fetchTranscriptSource(track,meta,null,{doc,videoId:()=>id});
  id='second';doc.nextRows=rows.map(r=>({...r,text:'These are the second video captions.'}));
  const fresh=await fetchTranscriptSource(track,{...meta,videoId:id},null,{doc,videoId:()=>id});assert.equal(doc.clicks,1);assert(parseCaptions(fresh.raw).every(c=>c.text==='These are the second video captions.'));
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),1400);
  await assert.rejects(fetchTranscriptSource(track,meta,controller.signal,{doc:panelFixture({busy:true}),videoId:()=>meta.videoId}),{name:'AbortError'});clearTimeout(timer);
});
import {segmentSource} from '../content/transcript-source.js';
test('攔到 YouTube 轉錄稿的毫秒時間時優先使用；行數差太多就退回面板時間戳',()=>{
  const rows=[{timestamp:'0:00',text:'hello there'},{timestamp:'0:02',text:'general kenobi'}];
  const precise=segmentSource([{startMs:120,endMs:2350,text:'hello there'},{startMs:2400,endMs:4100,text:'general kenobi'}],rows,10);
  assert.equal(precise.format,'youtube-transcript-api');assert.deepEqual(JSON.parse(precise.raw).events.map(e=>[e.tStartMs,e.dDurationMs]),[[120,2230],[2400,1700]]);
  assert.equal(segmentSource([],rows,10),null);assert.equal(segmentSource(Array.from({length:20},(_,i)=>({startMs:i*100,endMs:i*100+50,text:'x'})),rows,10),null);
});
