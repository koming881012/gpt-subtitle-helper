const ENTITIES = { amp:'&', lt:'<', gt:'>', quot:'"', apos:"'", nbsp:' ', '#39':"'" };
export function decodeEntities(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z][a-z0-9]+);/gi,(match,key)=>{
    if (key[0]==='#') { const n=key[1]?.toLowerCase()==='x'?parseInt(key.slice(2),16):parseInt(key.slice(1),10); return n>=0 && n<=0x10ffff && !(n>=0xd800 && n<=0xdfff)?String.fromCodePoint(n):match; }
    return ENTITIES[key.toLowerCase()] ?? match;
  });
}
export function cleanText(s) { return decodeEntities(s).replace(/\r\n?/g,'\n').split('\n').map(line=>line.replace(/[\t\u00a0 ]+/g,' ').trim()).join('\n').trim(); }
function cue(start,duration,text) { return {startMs:Number(start),durationMs:Number(duration),endMs:Number(start)+Number(duration),text:cleanText(text)}; }
export function parseJSON3(data) {
  if (!Array.isArray(data?.events)) throw new Error('JSON3 缺少 events。');
  const out=[];
  for (const e of data.events) {
    if (!Array.isArray(e.segs)) continue;
    const text=e.segs.map(s=>s.utf8 || '').join('');
    // ASR 會穿插只有換行的 aAppend 事件（約占一半），它們不是字幕內容，直接略過，以免被判定為過多空白段落。
    if(!cleanText(text))continue;
    // ASR 的 aAppend 是同一視窗的增補文字，只保留新文字及它的原始 event timing。
    const c=cue(e.tStartMs,e.dDurationMs ?? 0,text);
    // ASR 每個詞都有自己的 tOffsetMs；保留下來，斷句時用真實的詞時間，而不是平均分配。
    if(e.segs.some(s=>Number.isFinite(s.tOffsetMs))) {
      const words=e.segs.map(s=>({text:cleanText(s.utf8||''),offsetMs:Math.max(0,Number(s.tOffsetMs)||0)})).filter(w=>w.text);
      if(words.length&&words.every((w,i)=>i===0||w.offsetMs>=words[i-1].offsetMs))c.words=words;
    }
    out.push(c);
  }
  return out;
}
function attrs(s) { return Object.fromEntries([...s.matchAll(/([\w]+)\s*=\s*["']([^"']*)["']/g)].map(m=>[m[1],m[2]])); }
export function parseXML(raw) {
  if (/<!DOCTYPE|<!ENTITY/i.test(raw)) throw new Error('不支援含 DTD 的字幕 XML。');
  if (!/<(?:transcript|timedtext)\b/i.test(raw)) throw new Error('不是字幕 XML。');
  const out=[];
  const tags=/<(text|p)\b([^>]*)>([\s\S]*?)<\/\1>/g;
  for (const m of raw.matchAll(tags)) {
    const a=attrs(m[2]);
    const body=m[3].replace(/<br\s*\/?\s*>/gi,'\n').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]*>/g,'');
    out.push(m[1]==='text'?cue(Number(a.start)*1000,Number(a.dur)*1000,body):cue(a.t, a.d ?? 0,body));
  }
  return out;
}
export function validateCues(cues, durationSeconds=0) {
  if (!cues.length) throw new Error('字幕取得失敗：沒有字幕段落。');
  let prev=-1, empty=0, maxEnd=0;
  for (const c of cues) {
    if (![c.startMs,c.durationMs,c.endMs].every(Number.isFinite) || c.startMs<prev || c.startMs<0 || c.durationMs<0 || c.endMs!==c.startMs+c.durationMs) throw new Error('字幕取得失敗：時間軸異常。');
    prev=c.startMs; maxEnd=Math.max(maxEnd,c.endMs); if (!c.text) empty++;
  }
  if (empty/cues.length>0.25) throw new Error('字幕取得失敗：過多空白段落。');
  if (durationSeconds>0 && maxEnd>durationSeconds*1000+Math.max(10000,durationSeconds*100)) throw new Error('字幕取得失敗：字幕時間超出影片長度。');
  return { count:cues.length, maxEndMs:maxEnd, warnings:durationSeconds>60 && maxEnd<durationSeconds*1000*0.5?['最後字幕早於影片一半，可能是片尾無口白或來源不完整，請核對。']:[] };
}
export function parseCaptions(raw, durationSeconds=0) {
  const text=String(raw).trim();
  const cues=text.startsWith('{')?parseJSON3(JSON.parse(text)):parseXML(text);
  validateCues(cues,durationSeconds);
  return cues.filter(c=>c.text).map((c,id)=>({...c,id}));
}
