import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {detectTextLanguage,japaneseChunks,baseLanguage} from '../shared/languages.js';
import {sourceTracks,englishTracks,spokenLanguage} from '../content/caption-detector.js';
import {autoTranslationLanguageNotice,AutoTranslationGate} from '../content/auto-translate.js';
import {validateCaptionUrl} from '../content/caption-fetcher.js';
import {parseCaptions} from '../content/caption-parser.js';
import {captionWords,pauseWindow,sentenceInput,validateSentences,sentenceInstructions,SENTENCE_INSTRUCTIONS} from '../translation/sentence-subtitles.js';
import {sanitizeGlossary} from '../translation/terminology.js';
import {translateProgressively} from '../translation/progressive-translator.js';
import {normalizeSettings} from '../shared/constants.js';

// 實際取自 YouTube 日文自動字幕（JSON3）的結構：整句一段、沒有逐詞時間，中間穿插換行 aAppend。
const JA_ASR=JSON.stringify({events:[{tStartMs:0,dDurationMs:2096800,id:1},{tStartMs:719,dDurationMs:4761,wWinId:1,segs:[{utf8:'こんにちは。ゆっくり霊夢です。',acAsrConf:0}]},{tStartMs:3030,dDurationMs:2450,wWinId:1,aAppend:1,segs:[{utf8:'\n'}]},{tStartMs:3040,dDurationMs:5440,wWinId:1,segs:[{utf8:'こんにちは。ゆっくり魔理沙だぜ。',isSpeakerChange:1}]},{tStartMs:5470,dDurationMs:6000,wWinId:1,segs:[{utf8:'今日は稲荷神について解説していくぜ'}]}]});
const tracks=[{languageCode:'en',kind:'asr',vssId:'a.en',name:'英文 (自動產生)'},{languageCode:'ja',kind:'asr',vssId:'a.ja',name:'日文 (自動產生)'}];

test('依內容判斷字幕語言：日文、英文、中文、韓文',()=>{
  assert.equal(detectTextLanguage('こんにちは。ゆっくり霊夢です。今日は稲荷神について解説していくぜ'),'ja');
  assert.equal(detectTextLanguage('Hello, I am Yukkuri Reimu and today we will talk about what the fox is'),'en');
  assert.equal(detectTextLanguage('今天我們要來講解狐狸到底是什麼東西以及牠的歷史'),'zh');
  assert.equal(detectTextLanguage('안녕하세요 오늘은 여우에 대해서 설명하겠습니다 여러분'),'ko');
  assert.equal(detectTextLanguage('short'),null);
  assert.equal(baseLanguage('ja-JP'),'ja');
});
test('日文切成短詞塊：助詞與標點黏回前一個詞，不留空白',()=>{
  const chunks=japaneseChunks('こんにちは。ゆっくり霊夢です。 今日は稲荷神について');
  assert.equal(chunks.join(''),'こんにちは。ゆっくり霊夢です。今日は稲荷神について');
  assert(chunks.every(c=>c&&!/\s/.test(c)));
  assert(!chunks.includes('は'));assert(!chunks.includes('。'));
  // 約一個短語一塊，最多 8 字；句末標點後斷開。
  assert(chunks.every(c=>[...c].length<=12));assert(chunks.includes('こんにちは。'));
  assert.deepEqual(japaneseChunks('怖い、怖い、怖い。だからこれがおかしいって言ってんの。').slice(0,2),['怖い、怖い、','怖い。']);
});
test('日文影片優先日文字幕：AI 英文配音的英文自動字幕排後面',()=>{
  assert.equal(sourceTracks(tracks,{audioLanguage:'ja'})[0].vssId,'a.ja');
  assert.equal(sourceTracks(tracks,{title:'【ゆっくり解説】なぜ狐は神の使いに？'})[0].vssId,'a.ja');
  assert.equal(sourceTracks(tracks,{audioLanguage:'en'})[0].vssId,'a.en');
  // 只有一種語言的自動字幕時，那就是口說語言。
  assert.equal(spokenLanguage({captionTracks:[tracks[1]]}),'ja');
  assert.equal(spokenLanguage({captionTracks:tracks}),null);
  // 其他語言的自動字幕可能是標錯的日文，列在最後供手動選；自動翻譯成日文的不算。
  const list=sourceTracks([...tracks,{languageCode:'ko',kind:'asr',vssId:'a.ko'},{languageCode:'ja',isAutoTranslated:true},{languageCode:'fr',vssId:'.fr'}],{audioLanguage:'ja'});
  assert.deepEqual(list.map(t=>t.vssId),['a.ja','a.en','a.ko']);
  assert.deepEqual(englishTracks(tracks).map(t=>t.vssId),['a.en']);
});
test('自動翻譯：日文影片＋日文字幕會啟動；只有英文自動字幕時略過並說明',()=>{
  const meta={platform:'youtube',videoId:'QMaCLZ1XKE8',audioLanguage:'ja',captionTracks:tracks};
  assert.equal(autoTranslationLanguageNotice(meta,tracks[1]),'');
  assert.match(autoTranslationLanguageNotice(meta,tracks[0]),/原音是日文.*英文自動字幕/);
  assert.equal(autoTranslationLanguageNotice({...meta,audioLanguage:'ja'},{languageCode:'en',vssId:'.en'}),'');
  assert.match(autoTranslationLanguageNotice({...meta,audioLanguage:'ko'},tracks[1]),/非英文、非日文/);
  assert.match(autoTranslationLanguageNotice({...meta,audioLanguage:null},tracks[1]),/無法確認/);
  assert.equal(autoTranslationLanguageNotice({...meta,audioLanguage:null,title:'ゆっくり解説'},tracks[1]),'');
  const state={meta,track:tracks[1],settings:{...normalizeSettings(),hasConnection:true},pref:{enabled:true},cache:null,job:null,starting:false};
  assert(new AutoTranslationGate().take(state));
  assert(!new AutoTranslationGate().take({...state,track:tracks[0]}));
});
test('MAIN bridge：AI 配音音軌不算原音；「日文 (原文)」判定為原始音軌',async()=>{
  const script=await readFile(new URL('../content/page-bridge.js',import.meta.url),'utf8');
  let handler,answer;const id='QMaCLZ1XKE8';
  const r={videoDetails:{videoId:id,title:'【ゆっくり解説】',lengthSeconds:'2097'},streamingData:{adaptiveFormats:[{audioTrack:{displayName:'英文 (US)',id:'en-US.10',audioIsDefault:false,isAutoDubbed:true}},{audioTrack:{displayName:'日文 (原文)',id:'ja.4',audioIsDefault:true}}]},captions:{playerCaptionsTracklistRenderer:{captionTracks:[]}}};
  const window={addEventListener:(name,fn)=>{if(name==='message')handler=fn;},postMessage:m=>{answer=m;}};
  const location={href:`https://www.youtube.com/watch?v=${id}`,pathname:'/watch',origin:'https://www.youtube.com'};
  vm.runInContext(script,vm.createContext({window,location,URL,document:{getElementById:()=>({getPlayerResponse:()=>r}),querySelector:()=>null}}));
  handler({source:window,origin:location.origin,data:{channel:'ytgpt-player-bridge-v1',type:'REQUEST',requestId:'x'}});
  assert.equal(answer.data.audioLanguage,'ja');
  r.streamingData.adaptiveFormats[1].audioTrack.displayName='日文';
  handler({source:window,origin:location.origin,data:{channel:'ytgpt-player-bridge-v1',type:'REQUEST',requestId:'y'}});
  assert.equal(answer.data.audioLanguage,'ja');
});
test('日文字幕網址可取得，YouTube 自動翻譯（tlang）仍拒絕',()=>{
  const base='https://www.youtube.com/api/timedtext?v=QMaCLZ1XKE8&lang=ja&kind=asr';
  assert(validateCaptionUrl(base,'QMaCLZ1XKE8'));
  assert.throws(()=>validateCaptionUrl(base+'&tlang=zh-Hant','QMaCLZ1XKE8'));
  assert.throws(()=>validateCaptionUrl(base.replace('lang=ja','lang='),'QMaCLZ1XKE8'));
});
test('日文自動字幕斷詞：時間依字數分配、遞增且不超出 cue',()=>{
  const cues=parseCaptions(JA_ASR,2097),words=captionWords(cues,'ja');
  assert.equal(cues.length,3);
  assert.equal(words.map(w=>w.text).join(''),cues.map(c=>c.text).join(''));
  for(let i=1;i<words.length;i++)assert(words[i].startMs>=words[i-1].startMs);
  for(const w of words){const cue=cues[w.cueId];assert(w.startMs>=cue.startMs&&w.endMs>w.startMs);}
  // 第一個 cue 的最後一個詞要在下一個 cue（3040ms）之前結束。
  assert(words.filter(w=>w.cueId===0).every(w=>w.endMs<=3040));
  assert(pauseWindow(words,new Uint8Array(words.length),0,60));
  const input=JSON.parse(sentenceInput({title:'t',sourceLanguage:'ja'},words,{start:0,end:4}));
  assert(!/\s/.test(input.after));
});
test('日文提示詞與驗證：原文欄保留日文，中文欄不能有假名',()=>{
  assert.notEqual(sentenceInstructions('ja'),SENTENCE_INSTRUCTIONS);
  assert.match(sentenceInstructions('ja'),/日文原文/);
  const words=captionWords(parseCaptions(JA_ASR,2097),'ja'),window={start:0,end:words.length,isFinalWindow:true};
  const ok={sentences:[{startWord:0,endWord:words.length,en:'こんにちは。ゆっくり霊夢です。',zh:'大家好，我是悠哉靈夢'}]};
  assert.equal(validateSentences(ok,words,window,{lang:'ja'}).cues[0].en,'こんにちは。ゆっくり霊夢です。');
  assert.throws(()=>validateSentences({sentences:[{...ok.sentences[0],zh:'大家好，我是ゆっくり霊夢'}]},words,window,{lang:'ja'}),/日文字母/);
  assert.throws(()=>validateSentences({sentences:[{...ok.sentences[0],en:'あ'.repeat(70)}]},words,window,{lang:'ja'}),/日文字/);
});
test('日文專有名詞：target 用繁體字或英文原名，不換回含假名的原文',()=>{
  const out=sanitizeGlossary([{source:'霊夢',meaning:'角色',category:'person',usage:'original',target:'靈夢',urls:[]},{source:'ゆっくり',meaning:'系列',category:'term',usage:'chinese',target:'油庫里',urls:[]}],'ja');
  assert.deepEqual(out.map(g=>[g.target,g.usage]),[['靈夢','original'],['油庫里','original']]);
  assert.equal(sanitizeGlossary([{source:'Python',meaning:'語言',category:'programming',usage:'original',target:'派森',urls:[]}])[0].target,'Python');
});
test('翻譯工作：YouTube 標成英文、內容其實是日文時，改用日文提示詞並提示',async()=>{
  const saved=[];let instructions='';
  const job={jobId:'j',videoId:'QMaCLZ1XKE8',title:'t',duration:2097,cacheKey:'k',settings:normalizeSettings(),sourceTrack:{languageCode:'en',kind:'asr',vssId:'a.en'},prefetchedSource:{raw:JA_ASR,format:'json3'}};
  const request=async({instructions:text,input})=>{instructions=text;const w=JSON.parse(input).words.match(/(\d+):/g).map(x=>Number(x.slice(0,-1)));return {sentences:[{startWord:w[0],endWord:w.at(-1)+1,en:'こんにちは',zh:'大家好'}]};};
  await translateProgressively(job,{},new AbortController().signal,()=>{},{request,save:async(store,value)=>{saved.push([store,structuredClone(value)]);},read:async()=>null});
  assert.equal(job.status,'completed',job.error);
  assert.equal(job.sourceLanguage,'ja');assert.match(instructions,/日文字幕重新斷句/);
  const cache=saved.filter(([s])=>s==='cache').at(-1)[1];
  assert.equal(cache.sourceLanguage,'ja');assert(cache.warnings.some(w=>/標為英文，但內容是日文/.test(w)));
});
test('內容是中文或韓文的字幕不送翻譯',async()=>{
  const raw=JSON.stringify({events:[{tStartMs:0,dDurationMs:4000,segs:[{utf8:'안녕하세요 오늘은 여우에 대해서 설명하겠습니다 여러분'}]}]});
  const job={jobId:'j2',videoId:'QMaCLZ1XKE8',title:'t',duration:60,cacheKey:'k2',settings:normalizeSettings(),sourceTrack:{languageCode:'ja',kind:'asr',vssId:'a.ja'},prefetchedSource:{raw,format:'json3'}};
  await translateProgressively(job,{},new AbortController().signal,()=>{},{request:async()=>{throw new Error('不應呼叫');},save:async()=>{},read:async()=>null});
  assert.equal(job.status,'error');assert.match(job.error,/韓文|ko/);
});
test('模型分段編號數錯幾個詞時自動對齊；差太多才要求重試',()=>{
  const words=captionWords(parseCaptions(JA_ASR,2097),'ja'),n=words.length,window={start:0,end:n,isFinalWindow:true};
  const s=(a,b)=>({startWord:a,endWord:b,en:'こんにちは',zh:'大家好'});
  // 跳過一個詞、重複輸出前一段、最後少涵蓋一個詞：都自動修正。
  const fixed=validateSentences({sentences:[s(0,3),s(4,6),s(4,6),s(6,n-1)]},words,window,{lang:'ja'});
  assert.deepEqual(fixed.cues.map(c=>[c.startWord,c.endWord]),[[0,3],[3,6],[6,n]]);assert.equal(fixed.end,n);
  assert.throws(()=>validateSentences({sentences:[s(0,2),s(2+4,n)]},words,window,{lang:'ja'}),/startWord 2/);
  // 最後一次重試：差多少都對齊。
  assert.equal(validateSentences({sentences:[s(0,2),s(2+4,n)]},words,window,{lang:'ja',lenient:true}).end,n);
});
test('已準備秒數依已翻的詞計算：講話之間的空白不算缺字幕',async()=>{
  const {coveredSeconds}=await import('../shared/subtitle-buffer.js');
  const {availableSubtitleSeconds}=await import('../content/subtitle-buffer-controller.js');
  const {JA_WORDS_VERSION}=await import('../shared/languages.js');
  // 兩段話中間有 6 秒空白；原始字幕時間窗固定 3 秒，比講話長。
  const raw=JSON.stringify({events:[{tStartMs:0,dDurationMs:3000,segs:[{utf8:'こんにちは。'}]},{tStartMs:1000,dDurationMs:3000,segs:[{utf8:'今日は晴れです。'}]},{tStartMs:10000,dDurationMs:3000,segs:[{utf8:'よろしくお願いします。'}]},{tStartMs:20000,dDurationMs:3000,segs:[{utf8:'まだ翻訳していない。'}]}]});
  const cues=parseCaptions(raw,60),words=captionWords(cues,'ja'),last=words.findIndex(w=>w.cueId===3);
  assert.equal(coveredSeconds(words,[{start:0,end:last}],0,60000),20);
  assert.equal(coveredSeconds(words,[{start:0,end:last}],15000,60000),5);
  assert.equal(coveredSeconds(words,[{start:0,end:2}],0,60000),Math.floor(words[2].startMs/1000));
  assert.equal(coveredSeconds(words,[{start:0,end:words.length}],0,60000),60);
  const translatedCues=[{startWord:0,endWord:last,startMs:0,endMs:12500,zh:'你好'}];
  const cache={partial:true,sourceLanguage:'ja',wordVersion:JA_WORDS_VERSION,sourceCues:cues,translatedCues};
  assert.equal(availableSubtitleSeconds(cache,0,60000),20);
});
