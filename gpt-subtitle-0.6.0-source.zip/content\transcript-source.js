import { validateCues } from './caption-parser.js';
import { baseLanguage,detectTextLanguage,languageName } from '../shared/languages.js';

const normalize=s=>String(s || '').replace(/\s+/g,' ').trim();
const owners=new WeakMap();
const modernSelector='yt-section-list-renderer[data-target-id="PAmodern_transcript_view"][panel-content-visible]';
export function transcriptPanel(doc) {
  const visible=e=>e && e.getClientRects().length && !e.closest('[hidden], [visibility="ENGAGEMENT_PANEL_VISIBILITY_HIDDEN"]');
  return Array.from(doc.querySelectorAll(`ytd-transcript-renderer[panel-content-visible], ${modernSelector}`)).find(visible) || null;
}
export function transcriptRows(panel) {
  return Array.from(panel.querySelectorAll('ytd-transcript-segment-renderer, transcript-segment-view-model')).map(e=>({timestamp:normalize(e.querySelector('.segment-timestamp, .ytwTranscriptSegmentViewModelTimestamp')?.textContent),text:e.querySelector('.segment-text, [role="text"]')?.textContent || ''}));
}
const looksLike=(rows,lang)=>detectTextLanguage(rows.map(r=>r.text).join('\n'))===lang;
const LANGUAGE_LABELS={en:/^(English|英文|英語|英语)(?:\s|$)/i,ja:/^(Japanese|日文|日語|日语|日本語)(?:\s|$)/i};
export function transcriptSource(rows,durationSeconds) {
  if(!Array.isArray(rows) || !rows.length || rows.length>20000)throw new Error('YouTube 原生轉錄稿沒有完整字幕。');
  const starts=rows.map(row=>{
    const parts=normalize(row.timestamp).split(':');
    if(parts.length<2 || parts.length>3 || parts.some(p=>!/^\d+$/.test(p)) || parts.slice(1).some(p=>Number(p)>=60))throw new Error('YouTube 轉錄稿時間戳無法辨識。');
    return parts.reduce((seconds,p)=>seconds*60+Number(p),0)*1000;
  });
  const durationMs=Math.round(Number(durationSeconds)*1000);
  if(!Number.isFinite(durationMs) || durationMs<=0)throw new Error('YouTube 影片長度尚未就緒，請稍候再試。');
  const events=rows.map((row,i)=>({tStartMs:starts[i],dDurationMs:Math.max(0,(starts[i+1] ?? Math.min(durationMs,starts[i]+10000))-starts[i]),segs:[{utf8:String(row.text || '').trim()}]}));
  const {warnings}=validateCues(events.map(e=>({startMs:e.tStartMs,durationMs:e.dDurationMs,endMs:e.tStartMs+e.dDurationMs,text:e.segs[0].utf8})),durationSeconds);
  const raw=JSON.stringify({events});
  if(raw.length>10000000)throw new Error('字幕來源過大，未送出翻譯。');
  return {raw,format:'youtube-transcript-dom',warnings:['使用 YouTube 原生轉錄稿：時間戳精度為秒，結束時間依下一段起點推算。',...warnings]};
}

// 面板載入時 YouTube 回傳的逐行毫秒時間（由 page bridge 攔下）；比面板上只到「秒」的時間戳精準。
export function segmentSource(segments,rows,durationSeconds) {
  if(!Array.isArray(segments)||!segments.length||Math.abs(segments.length-rows.length)>Math.max(3,rows.length*0.2))return null;
  const events=segments.map(s=>({tStartMs:Math.round(s.startMs),dDurationMs:Math.max(0,Math.round(s.endMs-s.startMs)),segs:[{utf8:String(s.text).trim()}]}));
  const {warnings}=validateCues(events.map(e=>({startMs:e.tStartMs,durationMs:e.dDurationMs,endMs:e.tStartMs+e.dDurationMs,text:e.segs[0].utf8})),durationSeconds);
  return {raw:JSON.stringify({events}),format:'youtube-transcript-api',warnings:['使用 YouTube 轉錄稿：每行有毫秒時間，詞時間依行內平均估算。',...warnings]};
}
// 只關閉我們自己打開的轉錄稿面板，使用者原本開著的不動。
function closePanel(panel) {
  const host=panel?.closest?.('ytd-engagement-panel-section-list-renderer');
  const button=host?.querySelector('#visibility-button button, button[aria-label="關閉"], button[aria-label="关闭"], button[aria-label="Close"], button[aria-label="Close transcript"]');
  try{button?.click();}catch{}
}
export async function fetchTranscriptSource(track,meta,signal,{doc=document,videoId=()=>new URL(location.href).searchParams.get('v'),segments=async()=>null}={}) {
  const guard=()=>{signal?.throwIfAborted();if(videoId()!==meta.videoId){const e=new Error('影片已切換，已停止取得字幕。');e.code='VIDEO_CHANGED';throw e;}};
  const wait=()=>new Promise((resolve,reject)=>{const aborted=()=>{clearTimeout(timer);reject(signal.reason || new DOMException('Aborted','AbortError'));};const timer=setTimeout(()=>{signal?.removeEventListener('abort',aborted);resolve();},250);signal?.addEventListener('abort',aborted,{once:true});});
  const panel=()=>transcriptPanel(doc);
  const visible=e=>e && e.getClientRects().length && !e.closest('[hidden]');
  const findButton=()=>Array.from(doc.querySelectorAll('ytd-video-description-transcript-section-renderer button, ytd-video-description-transcript-section-renderer [role="button"], ytd-watch-metadata #description button, ytd-watch-metadata #description [role="button"]')).find(e=>visible(e)&&/^(顯示轉錄稿|显示文字记录|显示转录稿|Show transcript)$/i.test(normalize(e.textContent||e.getAttribute?.('aria-label'))));
  // The new watch layout mounts the description only after its side-rail tab opens.
  const descriptionTab=()=>Array.from(doc.querySelectorAll('yt-side-rail-view-model [role="tab"]')).find(e=>visible(e)&&e.getAttribute('aria-selected')!=='true'&&e.getAttribute('aria-disabled')!=='true'&&/^(?:說明|说明|Description)(?:$|[，,])/i.test(normalize(e.getAttribute('aria-label')||e.textContent)));
  guard();
  const previous=owners.get(doc),switched=previous && previous.videoId!==meta.videoId;
  let openedAt=0,openAttempts=0;
  const open=button=>{button.click();openedAt=Date.now();openAttempts++;};
  if(!panel() || switched) {
    const deadline=Date.now()+25000,expanded=new WeakSet();
    while(!findButton() && (!panel()||switched) && Date.now()<deadline){
      guard();
      const inline=doc.querySelector('ytd-watch-metadata #description-inline-expander #expand, ytd-text-inline-expander#description-inline-expander #expand');
      const expand=visible(inline)?inline:descriptionTab();
      if(expand&&visible(expand)&&!expanded.has(expand)){expand.click();expanded.add(expand);}
      await wait();
    }
    const button=findButton();if(button)open(button);else if(!panel()||switched){const e=new Error('YouTube 影片說明與轉錄稿入口尚未就緒。');e.code='TRANSCRIPT_NOT_READY';throw e;}
  }
  const deadline=Date.now()+20000;let signature='',stable=0,selected=false;
  while(Date.now()<deadline) {
    guard();const p=panel();
    // SPA hydration may replace the button or discard its first activation.
    // Retry only while no transcript is visible; never toggle a loaded panel closed.
    if(!p && openAttempts<3 && Date.now()-openedAt>=2000){const button=findButton();if(button)open(button);}
    if(p) {
      if(p.querySelector('#transcript-search-box-input, yt-search-input-view-model textarea, yt-search-input-view-model input')?.value)throw new Error('請清空 YouTube 轉錄稿搜尋欄，再產生中文字幕，以免只翻譯搜尋結果。');
      const label=normalize(p.querySelector('ytd-transcript-footer-renderer #label-text')?.textContent);
      const lang=baseLanguage(track.languageCode),name=languageName(lang);
      const rows=transcriptRows(p),expected=normalize(track.name),modern=p.matches?.(modernSelector),singleSame=meta.captionTracks?.length===1 && baseLanguage(meta.captionTracks[0].languageCode)===lang;
      const matches=label?label===expected || (!expected && LANGUAGE_LABELS[lang]?.test(label)):modern && Boolean(LANGUAGE_LABELS[lang]) && (singleSame || looksLike(rows,lang));
      if(modern&&!label&&rows.length&&!matches)throw new Error(`原生轉錄稿內容無法確認為${name}，未送出翻譯。請在 YouTube 選擇${name}字幕來源。`);
      if(label && !matches && !selected) {
        selected=true;p.querySelector('ytd-transcript-footer-renderer #label')?.click();
        const choice=Array.from(p.querySelectorAll('ytd-transcript-footer-renderer [role="option"]')).find(e=>normalize(e.textContent)===expected);
        if(!choice)throw new Error(`原生轉錄稿的語言與所選${name}字幕不符，請在轉錄稿選擇相同的${name}來源。`);
        choice.click();signature='';stable=0;
      } else if(matches) {
        const next=JSON.stringify(rows);stable=next===signature?stable+1:0;signature=next;
        if(p.querySelector('[aria-busy="true"]')){stable=0;await wait();continue;}
        if(switched && next===previous.signature){stable=0;await wait();continue;}
        if(rows.length && stable>=4){guard();const precise=segmentSource(await segments().catch(()=>null),rows,meta.duration);guard();const source=precise||transcriptSource(rows,meta.duration);if(modern&&!label&&!singleSame)source.warnings.push(`新版轉錄稿未提供來源標籤；已檢查內容為${name}，無法核對人工／自動來源軌。`);owners.set(doc,{videoId:meta.videoId,signature:next});if(openAttempts)closePanel(p);return source;}
      }
    }
    await wait();
  }
  const error=new Error('YouTube 轉錄稿暫未載入完成，尚未送出翻譯。請稍後按「產生繁中字幕」重試。');
  error.code='TRANSCRIPT_NOT_READY';throw error;
}
