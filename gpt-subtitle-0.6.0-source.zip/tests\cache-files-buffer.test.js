import test from 'node:test';
import assert from 'node:assert/strict';
import {selectCache} from '../background/cache-selection.js';
import {parseSubtitleFile,subtitleBackup} from '../export/subtitle-file.js';
import {toSRT} from '../export/srt.js';
import {toVTT} from '../export/vtt.js';
import {availableSubtitleSeconds,SubtitleBufferController} from '../content/subtitle-buffer-controller.js';
const meta={videoId:'e4NAz2TWA4I',title:'Test',duration:65},track={languageCode:'en',vssId:'a.en',kind:'asr'},cues=[{id:0,startMs:0,endMs:4000,durationMs:4000,en:'Hello.',zh:'你好。'},{id:1,startMs:60000,endMs:65000,durationMs:5000,en:'Goodbye.',zh:'再見。'}];
test('跨模型／prompt 沿用完整字幕；人工、自動、語言、影片隔離，部分與本機檔案選取',()=>{
  const base={videoId:meta.videoId,sourceTrack:track,model:'gpt-5.6-sol',key:'old-key',translatedCues:cues};
  assert.equal(selectCache([base,{...base,key:'current',partial:true}],meta,track,'current').key,'old-key');
  for(const other of [{...track,kind:'manual',vssId:'.en'},{...track,languageCode:'ja'}])assert.equal(selectCache([base],meta,other,'current'),null);
  assert.equal(selectCache([base],{videoId:'other'},track,'current'),null);assert.equal(selectCache([{...base,partial:true}],meta,track,'current').partial,true);
  assert.equal(selectCache([{...base,imported:true,key:'local-file'}],meta,null,'current').key,'local-file');
});
test('另存／再載入 SRT、VTT、助手備份；拒絕錯片、惡意 HTML、異常時間軸及超量資料',()=>{
  for(const [format,raw] of [['srt',toSRT(cues)],['vtt',toVTT(cues)],['json',subtitleBackup({translatedCues:cues},meta)]]){const result=parseSubtitleFile(raw,format,meta);assert.equal(result.length,2);assert.equal(result[1].startMs,60000);assert.equal(result[0].zh,'你好。');if(format==='json')assert.equal(result[0].en,'Hello.');}
  assert.throws(()=>parseSubtitleFile(subtitleBackup({translatedCues:cues},{...meta,videoId:'other'}),'json',meta),/另一支影片/);
  assert.equal(parseSubtitleFile('1\n00:00:00,000 --> 00:00:01,000\n<b>你好。</b>','srt',meta)[0].zh,'你好。');
  assert.throws(()=>parseSubtitleFile('1\n00:00:02,000 --> 00:00:01,000\n中文','srt',meta));assert.throws(()=>parseSubtitleFile('x'.repeat(10000001),'srt',meta));
});
test('字幕緩衝計算容許真正的無口白空檔，未翻譯範圍及快轉仍會暫停',()=>{
  const cache={partial:true,sourceCues:cues,translatedCues:cues.slice(0,1)};
  assert.equal(availableSubtitleSeconds(cache,3000,65000),57);assert.equal(availableSubtitleSeconds(cache,61000,65000),0);assert.equal(availableSubtitleSeconds({...cache,translatedCues:cues},3000,65000),62);
});
test('僅暫停正在播放的影片並依緩衝自動續播；人工暫停不擅自恢復、設定可關閉',async()=>{
  const handlers=new Map(),video={currentTime:0,duration:65,playbackRate:1,paused:false,addEventListener:(n,fn)=>handlers.set(n,fn),removeEventListener:n=>handlers.delete(n),pause(){this.paused=true;handlers.get('pause')?.();},play(){this.paused=false;handlers.get('play')?.();return Promise.resolve();}};
  const state={settings:{pauseForSubtitles:true},pref:{enabled:true,mode:'zh'},meta:{duration:65},job:{status:'translating'},cache:null};const controller=new SubtitleBufferController(video,()=>state);
  try {
  controller.check();assert(video.paused);assert(controller.held);state.cache={partial:true,sourceCues:cues,translatedCues:cues};controller.check();assert(!video.paused);assert(!controller.held);
  await new Promise(resolve=>setImmediate(resolve));
  video.pause();state.cache=null;controller.check();assert(video.paused);state.cache={partial:false};controller.check();assert(video.paused);
  video.paused=false;state.cache=null;controller.check();assert(controller.held);state.job.status='error';controller.check();assert(video.paused);assert(!controller.held);
  state.job.status='translating';video.paused=false;controller.check();assert(controller.held);state.error='字幕取得失敗';state.job.status='error';controller.check();assert(video.paused);
  state.error=null;state.job.status='translating';video.paused=false;controller.check();assert(controller.held);state.settings.pauseForSubtitles=false;controller.check();assert(!video.paused);
  await new Promise(resolve=>setImmediate(resolve));
  // 使用者在已有中文字幕的影片仍選擇 GPT 翻譯時，同樣等待中文字幕緩衝。
  state.settings.pauseForSubtitles=true;state.meta.captionTracks=[{languageCode:'zh-TW',kind:'manual'}];controller.check();assert(video.paused);assert(controller.held);
  }finally{controller.destroy();}assert.equal(handlers.size,0);
});
