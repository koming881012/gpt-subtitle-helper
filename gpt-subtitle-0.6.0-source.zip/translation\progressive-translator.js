import {TRANSLATION_CONFIG} from '../shared/constants.js';
import {parseCaptions,validateCues} from '../content/caption-parser.js';
import {fetchCaptionSource} from '../content/caption-fetcher.js';
import {getRecord,putRecord} from '../background/storage.js';
import {coveredSeconds} from '../shared/subtitle-buffer.js';
import {requestJSON} from './openai-client.js';
import {captionWords,pauseWindow,validateSentences,sentenceInput,timeSubtitles,SENTENCE_SCHEMA,sentenceInstructions} from './sentence-subtitles.js';
import {baseLanguage,detectCueLanguage,isSourceLanguage,languageName,JA_WORDS_VERSION} from '../shared/languages.js';
import {researchTerminology,termRevisionRanges} from './terminology.js';

export async function translateProgressively(job,access,signal,notify,{request=requestJSON,fetchSource=fetchCaptionSource,save=putRecord,read=getRecord,research=researchTerminology}={}) {
  const checkpoint=async patch=>{Object.assign(job,patch,{updatedAt:Date.now()});await save('jobs',job);notify({jobId:job.jobId});};
  let researchTask,researchResult,words;
  try {
    if(!job.sourceCues?.length) {
      await checkpoint({status:'fetching',phase:'正在取得原文字幕…',error:null});
      const source=job.prefetchedSource || await fetchSource(job.sourceTrack,job.videoId,signal);
      job.sourceCues=parseCaptions(source.raw,job.duration);job.rawSource=source.raw;job.sourceFormat=source.format;delete job.prefetchedSource;
      job.warnings=[...validateCues(job.sourceCues,job.duration).warnings,...(source.warnings || [])];
    }
    job.warnings ||= [];
    // 依字幕內容決定來源語言，不信 YouTube 標的語言（自動字幕可能標錯）。
    if(!job.sourceLanguage) {
      // 'other'（拉丁字母但不像英文）判斷不夠可靠，沿用標示的語言；韓文、中文這類不同文字就擋下。
      const labeled=baseLanguage(job.sourceTrack?.languageCode),detected=detectCueLanguage(job.sourceCues);
      const lang=detected&&detected!=='other'?detected:labeled;
      if(!isSourceLanguage(lang))throw new Error(`這條字幕的內容判定為${languageName(lang)}，目前只支援英文與日文來源。請在「字幕來源」改選其他字幕。`);
      if(detected&&labeled!==detected)job.warnings.push(`YouTube 把這條字幕標為${languageName(labeled)}，但內容是${languageName(detected)}，已依內容用${languageName(detected)}翻譯。`);
      job.sourceLanguage=lang;
      job.warnings.push(`${languageName(lang)}與中文依語意重新斷句；${job.sourceCues.some(c=>c.words?.length)?'時間使用 YouTube 自動字幕的逐詞時間。':'詞時間依原始字幕區間估算。'}`);
    }
    if(JSON.stringify(job.sourceCues.map(c=>({id:c.id,text:c.text}))).length>TRANSLATION_CONFIG.maxTranscriptChars)throw new Error('字幕全文超出安全上限，未送出翻譯。');
    const lang=job.sourceLanguage,scale=lang==='ja'?0.6:1;
    words=captionWords(job.sourceCues,lang);job.wordRanges ||= [];job.sentenceCues ||= [];job.termRevisionRanges ||= [];
    const wordVersion=lang==='ja'?JA_WORDS_VERSION:undefined;
    if(job.wordVersion!==wordVersion){if(job.wordRanges.length)job.warnings.push('日文斷詞方式已更新，已翻部分重新斷句翻譯。');job.wordRanges=[];job.sentenceCues=[];job.termRevisionRanges=[];job.wordVersion=wordVersion;}
    job.playheadMs=Number.isFinite(job.playheadMs)?job.playheadMs:0;
    await checkpoint({terminologyStatus:job.settings.terminologyEnabled?job.terminologyStatus:'disabled',totalCues:job.sourceCues.length,mode:'progressive',status:'translating',phase:'先翻譯目前播放位置，完成首批就可播放…'});
    if(job.settings.terminologyEnabled&&job.terminologyStatus!=='ready') {
      job.terminologyStatus='searching';
      researchTask=Promise.resolve().then(()=>research(job,access,signal,request)).then(glossary=>{researchResult={glossary};},e=>{researchResult={error:e.message};});
    }
    const publish=async partial=>{
      const cues=timeSubtitles(job.sentenceCues.slice().sort((a,b)=>a.startWord-b.startWord),{durationMs:Number(job.duration)*1000||Infinity});
      const covered=new Uint8Array(words.length);for(const range of job.wordRanges)covered.fill(1,range.start,range.end);
      const counts=new Map();for(const word of words){const entry=counts.get(word.cueId)||{total:0,done:0};entry.total++;if(covered[word.id])entry.done++;counts.set(word.cueId,entry);}
      const translatedCues=[...counts.values()].filter(x=>x.total===x.done).length;
      const bufferedSeconds=coveredSeconds(words,job.wordRanges,job.playheadMs,Number(job.duration)*1000||Infinity);
      await save('cache',{key:job.cacheKey,videoId:job.videoId,title:job.title,sourceTrack:job.sourceTrack,sourceLanguage:job.sourceLanguage,wordVersion:job.wordVersion,model:job.model,promptVersion:job.promptVersion,translatedAt:Date.now(),partial,sourceCues:job.sourceCues,translatedCues:cues,rawSource:job.rawSource,warnings:job.warnings,glossary:job.glossary || [],terminologyStatus:job.terminologyStatus,revision:(job.cacheRevision || 0)+1});
      job.cacheRevision=(job.cacheRevision || 0)+1;
      await checkpoint({translatedCues,bufferedSeconds,playableCues:cues.length,progress:Math.floor(translatedCues/job.totalCues*100),phase:partial?`已可顯示 ${cues.length} 句中文字幕 · 目前位置已準備 ${bufferedSeconds} 秒，背景繼續翻譯…`:'✓ 全部翻譯完成，字幕已開啟'});
    };
    const acceptResearch=async()=>{
      if(!researchResult)return;
      const result=researchResult;researchResult=null;
      if(result.error){job.terminologyStatus='failed';job.warnings.push(`GPT-6 術語搜尋未完成：${String(result.error).slice(0,250)}；目前使用繁中翻譯或音譯。`);}
      else {job.glossary=result.glossary;job.terminologyStatus='ready';job.termRevisionRanges=termRevisionRanges(job.wordRanges,job.sentenceCues,result.glossary);}
      await checkpoint({terminologyStatus:job.terminologyStatus});
    };
    // 同時翻譯數批：從播放位置往後，在停頓處切成互不依賴的段落；首批很小，幾秒內就能開始播放。
    const translateWindow=async window=>{
      let lastError;
      for(let attempt=0;attempt<3;attempt++) {
        try {
          const input=JSON.parse(sentenceInput(job,words,window));if(lastError)input.validationFeedback=lastError;
          const output=await request({access,accountId:job.accountId,settings:job.settings,signal:child.signal,instructions:sentenceInstructions(lang),input:JSON.stringify(input),schema:SENTENCE_SCHEMA,name:'subtitle_sentences',onRetry:(n,message)=>notify({jobId:job.jobId,retry:n,message})});
          return validateSentences(output,words,window,{lenient:attempt===2,lang});
        } catch(e){if(child.signal.aborted||e.retryable!==undefined||attempt===2)throw e;lastError=e.message;}
      }
    };
    let writes=Promise.resolve(),failure=null;
    const child=new AbortController(),abortChild=()=>child.abort(signal.reason);signal.addEventListener('abort',abortChild,{once:true});if(signal.aborted)abortChild();
    const pending=new Set(),reserved=[];
    const launch=(window,revision=false)=>{
      reserved.push(window);
      const task=translateWindow(window).then(validated=>{
        child.signal.throwIfAborted();
        if(revision)job.sentenceCues=job.sentenceCues.filter(c=>c.endWord<=window.start||c.startWord>=window.end);
        else job.wordRanges.push({start:window.start,end:validated.end});
        job.sentenceCues.push(...validated.cues);
        writes=writes.then(()=>publish(true));return writes;
      }).catch(e=>{failure||=e;child.abort(e);}).finally(()=>{reserved.splice(reserved.indexOf(window),1);pending.delete(task);});
      pending.add(task);
    };
    const nextWindow=()=>{
      const blocked=new Uint8Array(words.length);for(const r of [...job.wordRanges,...reserved])blocked.fill(1,r.start,r.end);
      // 首批小（約 15 秒）讓影片馬上能播；前方已緩衝超過 90 秒後改用大批次，減少重複送出指令的 token。
      const ahead=coveredSeconds(words,job.wordRanges,job.playheadMs,Number(job.duration)*1000||Infinity);
      // 日文詞塊約一個短語（約 1 秒），同樣秒數的詞塊數約為英文單字的 0.6 倍。
      return pauseWindow(words,blocked,job.playheadMs,Math.round(scale*(!job.wordRanges.length&&!reserved.length?40:ahead<30?70:ahead>=90?220:120)));
    };
    try {
      while(true) {
        child.signal.throwIfAborted();await acceptResearch();
        while(pending.size<3){const window=nextWindow();if(!window)break;launch(window);}
        // 新的部分都翻完後，才回頭用專有名詞表修正已翻段落；已經看過的部分不再重翻。
        if(!pending.size&&job.termRevisionRanges.length){
          const playheadWord=words.findIndex(w=>w.endMs>job.playheadMs);
          job.termRevisionRanges=job.termRevisionRanges.filter(r=>playheadWord<0||r.end>playheadWord);
          while(pending.size<3&&job.termRevisionRanges.length){const r=job.termRevisionRanges.shift();launch({...r,desiredEnd:r.end,isFinalWindow:true},true);}
        }
        if(!pending.size){
          if(researchTask){await researchTask;researchTask=null;await acceptResearch();if(job.termRevisionRanges.length)continue;}
          break;
        }
        await Promise.race([...pending]);
        if(failure){await Promise.allSettled([...pending]);throw failure;}
      }
    } finally {signal.removeEventListener('abort',abortChild);}
    await writes;signal.throwIfAborted();await publish(false);
    for(const key of ['sourceCues','rawSource','prefetchedSource','sentenceCues','wordRanges','termRevisionRanges','glossary'])delete job[key];
    await checkpoint({status:'completed',phase:'✓ 全部翻譯完成，字幕已開啟',progress:100,error:null});
  } catch(e) {
    const latest=await read('jobs',job.jobId);const cancelled=signal.aborted||latest?.status==='cancelled';
    await checkpoint({status:cancelled?'cancelled':'error',phase:cancelled?'已取消；完成的字幕仍可播放':'翻譯暫停；完成的字幕仍可播放',error:cancelled?null:String(e.message).slice(0,700)});
  }
  // Each research task has its own bounded timeout and handles rejection; no unhandled promise.
  return job;
}
