// 本插件自己的 ChatGPT 用量紀錄。OpenAI 目前不提供第三方 App 讀取方案剩餘額度與重置時間，
// 這裡只累計插件送出的請求與 token，讓使用者知道翻譯花了多少；剩餘額度需到 ChatGPT 用量頁查看。
export const USAGE_KEY='usageLog';
export const CHATGPT_USAGE_URL='https://chatgpt.com/settings/usage';
const KEEP_DAYS=35;
export const dayKey=(time=Date.now())=>{const d=new Date(time);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
const emptyDay=()=>({requests:0,inputTokens:0,outputTokens:0,cachedTokens:0});
const count=value=>Math.max(0,Math.min(1e9,Math.round(Number(value)||0)));
const slug=value=>/^[a-zA-Z0-9._:-]{1,100}$/.test(String(value||''))?String(value):'';

export function recordUsage(log={},event={},now=Date.now()) {
  const next={days:{...(log.days||{})},lastModel:log.lastModel||'',lastAt:log.lastAt||0,limit:log.limit||null};
  if(event.limit){next.limit={code:String(event.limit.code||'').slice(0,80),message:String(event.limit.message||'').slice(0,300),at:count(event.limit.at)||now};}
  else {
    const key=dayKey(event.at||now),day={...emptyDay(),...next.days[key]};
    day.requests++;day.inputTokens+=count(event.inputTokens);day.outputTokens+=count(event.outputTokens);day.cachedTokens+=count(event.cachedTokens);
    next.days[key]=day;next.lastAt=count(event.at)||now;if(slug(event.model))next.lastModel=slug(event.model);
    // 成功完成請求代表額度已恢復，清除舊的上限提示。
    if(next.limit&&next.limit.at<next.lastAt)next.limit=null;
  }
  const oldest=dayKey(now-KEEP_DAYS*86400000);
  for(const key of Object.keys(next.days))if(key<oldest)delete next.days[key];
  return next;
}
export function summarizeUsage(log={},now=Date.now()) {
  const sum=keys=>keys.reduce((total,key)=>{const d=log.days?.[key];if(d)for(const k of Object.keys(total))total[k]+=count(d[k]);return total;},emptyDay());
  const week=Array.from({length:7},(_,i)=>dayKey(now-i*86400000));
  const limit=log.limit&&now-log.limit.at<7*86400000?log.limit:null;
  return {today:sum([dayKey(now)]),week:sum(week),lastModel:log.lastModel||'',lastAt:log.lastAt||0,limit,usageUrl:CHATGPT_USAGE_URL};
}
