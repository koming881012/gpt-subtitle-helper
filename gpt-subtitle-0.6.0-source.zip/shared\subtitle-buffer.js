// 依「已翻到第幾個來源詞」計算目前位置往後有幾秒中文字幕：講話之間的空白不會被當成缺字幕。
// 原始字幕的時間窗常比講話長（日文自動字幕固定掛 3 秒），用時間窗檢查會把空白誤判為還沒翻。
export function coveredSeconds(words,ranges,playheadMs,durationMs=Infinity) {
  if(!words.length)return 0;
  const covered=new Uint8Array(words.length);for(const r of ranges)covered.fill(1,r.start,r.end);
  let i=words.findIndex(w=>w.endMs>playheadMs);
  if(i<0)i=words.length;
  while(i<words.length&&covered[i])i++;
  const end=i<words.length?words[i].startMs:Number.isFinite(durationMs)?durationMs:words.at(-1).endMs;
  return Math.max(0,Math.floor((end-playheadMs)/1000));
}
export function playableSeconds(cues,playheadMs) {
  let end=playheadMs;
  for(const cue of cues){if(cue.endMs<=end)continue;if(cue.startMs>end+1500)break;end=cue.endMs;}
  return Math.max(0,Math.floor((end-playheadMs)/1000));
}
