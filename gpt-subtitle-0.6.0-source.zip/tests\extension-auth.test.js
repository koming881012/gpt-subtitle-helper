import test from 'node:test';
import assert from 'node:assert/strict';
import {ChatGPTAuth,REDIRECT_URI,AUTH_KEY,PENDING_KEY,verifyIdentity} from '../background/chatgpt-auth.js';

function area(){const data={};return {data,get:async k=>({[k]:structuredClone(data[k])}),set:async v=>Object.assign(data,structuredClone(v)),remove:async k=>{delete data[k];}};}
const b64=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
const jwt=payload=>`${b64({alg:'RS256'})}.${b64(payload)}.sig`;
function setup(handler){const local=area(),session=area(),calls=[];const auth=new ChatGPTAuth({local,session,fetchImpl:async(url,o)=>{calls.push({url,body:Object.fromEntries(new URLSearchParams(String(o.body)))});return handler(url,o,calls);}});return {auth,local,session,calls};}
const tokenResponse=(nonce,extra={})=>Response.json({token_type:'Bearer',access_token:'access-1',refresh_token:'refresh-1',expires_in:3600,scope:'openid resource.invoke chatgpt.tokens.use.direct',id_token:jwt({iss:'https://auth.openai.com',aud:'client-1',sub:'user-1',email:'viewer@example.com',nonce,exp:Math.floor(Date.now()/1000)+600}),...extra});

test('登入網址使用官方 PKCE、loopback 與方案 scope，並把等待中的要求存在 session',async()=>{
  const {auth,session}=setup(()=>{throw new Error('no network');});
  const url=new URL(await auth.start());
  assert.equal(url.origin,'https://auth.openai.com');assert.equal(url.searchParams.get('redirect_uri'),REDIRECT_URI);
  assert.equal(url.searchParams.get('code_challenge_method'),'S256');assert.match(url.searchParams.get('scope'),/chatgpt\.tokens\.use\.direct/);
  assert.equal(url.searchParams.get('client_id'),'dynamic_agent_client');
  const pending=session.data[PENDING_KEY];assert.equal(pending.state,url.searchParams.get('state'));assert(!url.href.includes(pending.verifier));
});
test('state 不符或已逾時不換發 token；授權成功後只儲存在插件、不外送',async()=>{
  const {auth,session,local,calls}=setup((url,o,calls)=>tokenResponse(session.data[PENDING_KEY]?.nonce||calls.nonce));
  await auth.start();await assert.rejects(auth.callback(`${REDIRECT_URI}?state=wrong&code=c&client_id=client-1`),/失效/);assert.equal(calls.length,0);
  await auth.start();const p=session.data[PENDING_KEY];calls.nonce=p.nonce;
  const status=await auth.callback(`${REDIRECT_URI}?state=${p.state}&code=code-1&client_id=client-1`);
  assert(status.planEnabled);assert.equal(status.account.email,'viewer@example.com');assert(!JSON.stringify(status).includes('access-1'));
  assert.equal(calls[0].url,'https://auth.openai.com/api/accounts/oauth/token');assert.equal(calls[0].body.code_verifier,p.verifier);assert.equal(calls[0].body.redirect_uri,REDIRECT_URI);
  assert(!session.data[PENDING_KEY]);assert.equal(local.data[AUTH_KEY].accounts[0].refresh_token,'refresh-1');
  await assert.rejects(auth.callback(`${REDIRECT_URI}?state=${p.state}&code=code-1&client_id=client-1`),/失效/);
});
test('拒絕授權或 nonce 不符時保留既有帳號',async()=>{
  const {auth,session,local}=setup(()=>tokenResponse('other-nonce'));
  await auth.start();let p=session.data[PENDING_KEY];await assert.rejects(auth.callback(`${REDIRECT_URI}?state=${p.state}&error=access_denied`),/未完成/);
  await auth.start();p=session.data[PENDING_KEY];await assert.rejects(auth.callback(`${REDIRECT_URI}?state=${p.state}&code=x&client_id=client-1`),/nonce/);
  assert.equal(local.data[AUTH_KEY].accounts.length,0);
  assert.throws(()=>verifyIdentity(jwt({iss:'https://evil.example',aud:'c',sub:'s',nonce:'n',exp:Date.now()/1000+60}),{clientId:'c',nonce:'n'}));
});
test('過期前自動更新並輪替 refresh token；同時多個請求只更新一次',async()=>{
  let refreshes=0;const {auth,local}=setup(async()=>{refreshes++;await new Promise(r=>setTimeout(r,10));return Response.json({access_token:`access-${refreshes+1}`,refresh_token:`refresh-${refreshes+1}`,expires_in:3600});});
  local.data[AUTH_KEY]={hostId:'h',active:'a',accounts:[{id:'a',client_id:'client-1',email:'x',access_token:'old',refresh_token:'refresh-1',scopes:['resource.invoke','chatgpt.tokens.use.direct'],expiresAt:Date.now()+1000}]};
  const results=await Promise.all([auth.access(),auth.access(),auth.access()]);
  assert.equal(refreshes,1);assert(results.every(r=>r.token==='access-2'));assert.equal(local.data[AUTH_KEY].accounts[0].refresh_token,'refresh-2');
  assert.equal((await auth.access()).token,'access-2');assert.equal(refreshes,1);
  assert.equal((await auth.access(true)).token,'access-3');
});
test('refresh token 永久失效時清除憑證並要求重新登入；暫時錯誤保留',async()=>{
  let mode='temporary';const {auth,local}=setup(()=>mode==='temporary'?new Response('{}',{status:503}):Response.json({error:'refresh_token_reused'},{status:400}));
  local.data[AUTH_KEY]={hostId:'h',active:'a',accounts:[{id:'a',client_id:'c',email:'x',access_token:'old',refresh_token:'r',scopes:['resource.invoke','chatgpt.tokens.use.direct'],expiresAt:0}]};
  await assert.rejects(auth.access());assert.equal(local.data[AUTH_KEY].accounts[0].refresh_token,'r');
  mode='permanent';await assert.rejects(auth.access());assert(!local.data[AUTH_KEY].accounts[0].refresh_token);
  const status=await auth.status();assert.equal(status.signedIn,false);assert.match(status.error,/重新登入/);
});
test('登出撤銷 refresh token 並清除本機憑證',async()=>{
  const {auth,local,calls}=setup(()=>new Response('{}'));
  local.data[AUTH_KEY]={hostId:'h',active:'a',accounts:[{id:'a',client_id:'c',email:'x',access_token:'t',refresh_token:'r',scopes:[],expiresAt:Date.now()+9e6}]};
  assert.deepEqual(await auth.logout(),{revoked:true});assert.equal(calls[0].url,'https://auth.openai.com/api/accounts/oauth/revoke');assert.equal(calls[0].body.token,'r');
  assert(!local.data[AUTH_KEY].accounts[0].access_token);
});
