import { MSG,send } from '../shared/messages.js';
import { ACTIVE_STATUSES } from '../shared/constants.js';
import { languageName } from '../shared/languages.js';
import { videoIdFromUrl } from '../shared/utils.js';
import { platformFromUrl } from '../shared/platforms.js';
import { $,tabMessage,showError,notice,bindAction } from '../shared/ui.js';
import { fillModels } from '../shared/model-select.js';
import { modelLabel,EFFORT_LABELS,formatTokens } from '../shared/model-label.js';
import {normalizeSubtitleOffset,subtitleOffsetLabel,MAX_SUBTITLE_OFFSET_MS} from '../shared/subtitle-timing.js';
const BILINGUAL=['both-en','both-zh','split-en','split-zh'];
let tabId=null,state=null,busy=false,account=null,usage=null,models=[],modelsAccount='',lastSlowRefresh=0,slowLoading=false;
let offsetEditing=false,offsetSaving=false,offsetTimer=null,offsetSequence=0;

// ---- 連線狀態：一次只顯示一個下一步 ----
function renderConnection() {
  const box=$('#connection'),dot=$('#connectionDot'),action=$('#connectionAction'),hint=$('#connectionHint');
  let title,detail='',button='',hintText='',tone='';
  if(!account){title='正在檢查連線…';}
  else if(!account.signedIn){tone='warn';title='尚未連接 ChatGPT';detail='登入一次，之後開影片就能翻譯';button='用 ChatGPT 登入';hintText='在 OpenAI 官方頁面登入與授權，插件不會接觸你的密碼；不需安裝其他程式。';}
  else if(!account.planEnabled){tone='warn';title='還差一步：授權方案用量';detail=account.account?.email||'';button='授權使用 ChatGPT 方案';}
  else {tone='ok';title='ChatGPT 已連接';detail=account.account?.email||'';}
  if(account?.error&&tone==='warn')hintText=account.error;
  box.className=`connection ${tone}`;dot.className=`status-dot ${tone==='ok'?'connected':tone}`;
  $('#connectionTitle').textContent=title;$('#connectionDetail').textContent=detail;
  action.hidden=!button;action.textContent=button;action.disabled=false;hint.hidden=!hintText;hint.textContent=hintText;
}
async function connectionAction() {
  $('#connectionAction').disabled=true;notice('正在開啟 OpenAI 登入…');
  await send(MSG.SIGN_IN,{enablePlan:Boolean(account?.signedIn&&!account.planEnabled)});
  notice('請在新分頁完成登入與授權，完成後回到影片即可。');
}

// ---- 目前影片 ----
function videoStatus() {
  const job=state.job,active=state.starting||ACTIVE_STATUSES.includes(job?.status);
  if(state.error)return ['error','!',state.error];
  if(job?.error&&!active)return ['error','!',job.error];
  if(state.playbackError)return ['error','!',state.playbackError];
  if(!state.ready)return ['busy','◌','正在偵測影片與字幕…'];
  if(state.live)return ['warn','!','直播目前不支援翻譯。'];
  if(state.waitingForSubtitles)return ['busy','◌','中文字幕準備中，好了會自動繼續播放…'];
  if(active&&state.partial&&state.hasPlayable)return ['busy','◌',`中文字幕已可播放，目前位置已準備 ${state.bufferedSeconds} 秒。\n其餘部分在背景翻譯，不用等整片完成。`];
  if(active)return ['busy','◌',job?.phase||'正在取得原文字幕…'];
  if(state.hasCache)return ['ok','✓',`中文字幕已就緒${state.pref.enabled?'，正在顯示':'（目前隱藏）'}`];
  if(job?.status==='cancelled')return ['warn','‖','翻譯已暫停，可從目前進度繼續。'];
  if(!state.track)return ['warn','!','這支影片沒有可翻譯的英文或日文字幕。'];
  if(state.nativeChinese)return ['info','i','這支影片已有中文字幕，可在播放器 CC 直接選用；\n想要台灣用語版本，可按「仍用 GPT 翻譯」。'];
  if(state.autoTranslateBlockedReason)return ['info','i',state.autoTranslateBlockedReason];
  return ['info','i',`偵測到${state.track.kind==='asr'||/^a\./.test(state.track.vssId||'')?'自動產生的':'人工'}${languageName(state.track.languageCode)}字幕，可以開始翻譯。`];
}
function primaryLabel(active) {
  const job=state.job;
  if(active)return [`翻譯中… ${job?.progress||0}%`,true];
  if(state.hasCache)return state.pref.enabled?['',true]:['顯示中文字幕',false];
  if(!state.track||state.live)return ['無法翻譯',true];
  if(!account?.planEnabled)return ['請先用 ChatGPT 登入',true];
  if(['error','cancelled'].includes(job?.status))return ['繼續翻譯',false];
  return [state.nativeChinese?'仍用 GPT 翻譯':'開始翻譯',false];
}
function render() {
  if(!state){$('#controls').hidden=true;$('#progressWrap').hidden=true;return;}
  $('#title').textContent=state.title||'正在偵測影片…';
  $('#platform').textContent=state.platform==='primevideo'||platformFromUrl(state.url)==='primevideo'?'Prime Video':'YouTube';
  const job=state.job,active=state.starting||ACTIVE_STATUSES.includes(job?.status);
  const [tone,icon,text]=videoStatus();$('#statusBox').className=`status-box ${tone}`;$('#statusIcon').textContent=icon;$('#status').textContent=text;
  $('#progressWrap').hidden=!active;$('#progress').value=job?.progress||0;
  $('#counts').textContent=job?.totalCues?`${job.translatedCues} / ${job.totalCues} 段 · ${job.progress}%`:'';
  const terms=state.diagnostics?.terminologyStatus;
  $('#terminology').textContent=terms==='searching'?'正在搜尋中文專有名詞…':terms==='ready'?'已套用中文專有名詞表。':terms==='failed'?'專有名詞搜尋未完成，字幕使用一般譯名。':'';
  $('#controls').hidden=state.live||(!state.tracks?.length&&!state.hasPlayable&&!state.hasCache);
  const [label,disabled]=primaryLabel(active);$('#start').hidden=!label;$('#start').textContent=label;$('#start').disabled=disabled||busy;
  $('#cancel').hidden=!active;
  const bilingual=BILINGUAL.includes(state.pref.mode);
  // 記住使用者在設定頁選的雙語版面，下次按「雙語」沿用。
  if(bilingual)try{localStorage.setItem('bilingualMode',state.pref.mode);}catch{}
  for(const b of document.querySelectorAll('.segmented button')){const on=b.dataset.mode==='both'?bilingual:b.dataset.mode===state.pref.mode;b.setAttribute('aria-checked',String(on));b.disabled=busy;}
  $('#toggle').checked=Boolean(state.pref.enabled);$('#toggle').disabled=busy;
  const select=$('#track'),signature=state.tracks.map(t=>t.sourceTrackId).join('|');
  if(select.dataset.signature!==signature){select.replaceChildren(...state.tracks.map(t=>new Option(`${t.name||t.languageCode}（${t.kind==='asr'||/^a\./.test(t.vssId)?'自動':'人工'}）`,t.sourceTrackId)));select.dataset.signature=signature;}
  select.value=state.track?.sourceTrackId||'';select.disabled=active||busy;
  $('#exports').hidden=!state.hasCache;
  if(!offsetEditing)showOffset(state.pref.subtitleOffsetMs);
}
async function refresh() {if(!tabId)return;try{state=await send(MSG.STATE,{tabId});render();}catch(e){showError(e.message);}}
async function action(type,payload={}) {busy=true;render();try{await tabMessage(tabId,type,payload);notice('');}finally{busy=false;await refresh();}}
bindAction($('#start'),()=>action(MSG.CONTENT_START));
bindAction($('#cancel'),()=>action(MSG.CANCEL));
$('#toggle').addEventListener('change',()=>action(MSG.CONTENT_PREF,{pref:{enabled:$('#toggle').checked}}).catch(e=>showError(e.message)));
for(const b of document.querySelectorAll('.segmented button'))b.addEventListener('click',()=>{
  let mode=b.dataset.mode;
  if(mode==='both'){let saved='';try{saved=localStorage.getItem('bilingualMode')||'';}catch{}mode=BILINGUAL.includes(state?.pref.mode)?state.pref.mode:BILINGUAL.includes(saved)?saved:'both-en';}
  action(MSG.CONTENT_PREF,{pref:{mode,enabled:true}}).catch(e=>showError(e.message));
});
$('#track').addEventListener('change',()=>action(MSG.CONTENT_PREF,{sourceTrackId:$('#track').value}).catch(e=>showError(e.message)));
for(const format of ['srt','vtt','json'])bindAction($(`#${format}`),()=>action(MSG.EXPORT,{format,language:$('#language').value}));
$('#loadFile').addEventListener('click',()=>$('#subtitleFile').click());
$('#subtitleFile').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;if(file.size>10000000)throw new Error('字幕檔不可超過 10 MB。');await action(MSG.IMPORT_FILE,{filename:file.name,raw:await file.text()});notice('已載入字幕檔，不使用 GPT 額度。');}catch(err){showError(err.message);}finally{e.target.value='';}});

// ---- 字幕時間 ----
function showOffset(value,keepInput=false){const offset=normalizeSubtitleOffset(value);$('#subtitleOffset').value=String(offset/1000);if(!keepInput)$('#offsetSeconds').value=String(offset/1000);$('#offsetLabel').textContent=subtitleOffsetLabel(offset);$('#subtitleOffset').setAttribute('aria-valuetext',subtitleOffsetLabel(offset));}
function adjustOffset(seconds,immediate=false,keepInput=false){
  if(!state?.videoId)return;
  clearTimeout(offsetTimer);const sequence=++offsetSequence,videoId=state.videoId,value=Number(seconds)*1000;
  if(seconds===''||!Number.isFinite(value)||Math.abs(value)>MAX_SUBTITLE_OFFSET_MS){offsetEditing=false;offsetSaving=false;showError('請輸入 -600 至 600 秒，可使用小數。');return;}
  const subtitleOffsetMs=normalizeSubtitleOffset(value);offsetEditing=true;offsetSaving=true;showOffset(subtitleOffsetMs,keepInput);
  const save=async()=>{try{await tabMessage(tabId,MSG.CONTENT_PREF,{videoId,pref:{subtitleOffsetMs}});if(sequence===offsetSequence)notice('');}catch(e){if(sequence===offsetSequence)showError(e.message);}finally{if(sequence===offsetSequence){offsetSaving=false;offsetEditing=document.activeElement===$('#offsetSeconds');await refresh();}}};
  if(immediate)save();else offsetTimer=setTimeout(save,200);
}
$('#subtitleOffset').addEventListener('input',e=>adjustOffset(e.target.value));
$('#subtitleOffset').addEventListener('change',e=>adjustOffset(e.target.value,true));
$('#offsetSeconds').addEventListener('focus',()=>{offsetEditing=true;});
$('#offsetSeconds').addEventListener('input',e=>{offsetEditing=true;if(e.target.value!==''&&e.target.validity.valid)adjustOffset(e.target.value,false,true);else{clearTimeout(offsetTimer);offsetSequence++;offsetSaving=false;}});
$('#offsetSeconds').addEventListener('change',e=>adjustOffset(e.target.value,true));
$('#offsetSeconds').addEventListener('blur',()=>{if(!offsetSaving){offsetEditing=false;render();}});
bindAction($('#resetOffset'),()=>adjustOffset(0,true));

// ---- 模型與用量 ----
function renderUsage() {
  if(!usage)return;
  $('#modelName').textContent=modelLabel(usage.model,models)||'—';
  $('#effortName').textContent=EFFORT_LABELS[usage.reasoningEffort]||'';
  const line=d=>d.requests?`${d.requests} 次 · ${formatTokens(d.inputTokens+d.outputTokens)} tokens`:'尚未使用';
  $('#usageToday').textContent=line(usage.today);$('#usageWeek').textContent=line(usage.week);
  const limit=usage.limit;$('#limitNotice').hidden=!limit;
  if(limit)$('#limitNotice').textContent=`⚠ ${new Date(limit.at).toLocaleString('zh-TW',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})} 已達 ChatGPT 用量上限，翻譯已暫停並保留進度。重置後按「繼續翻譯」即可接續；重置時間請看下方用量頁。`;
  if(usage.usageUrl)$('#usageLink').href=usage.usageUrl;
}
async function loadModels(force=false) {
  if(!account?.planEnabled){models=[];modelsAccount='';return;}
  const id=account.account?.id||'';if(!force&&modelsAccount===id&&models.length)return;
  try{models=await send(MSG.MODELS);modelsAccount=id;}catch(e){$('#modelStatus').textContent=e.message;}
}
$('#changeModel').addEventListener('click',async()=>{
  const picker=$('#modelPicker');if(!picker.hidden){picker.hidden=true;return;}
  if(!account?.planEnabled){showError('請先完成上方的 ChatGPT 連線。');return;}
  picker.hidden=false;await loadModels(true);const s=await send(MSG.SETTINGS);
  const valid=fillModels($('#model'),models,s.model);$('#reasoningEffort').value=s.reasoningEffort;
  $('#modelStatus').textContent=valid?'改用其他模型後，尚未翻譯的部分會用新設定繼續。':'目前模型帳號不可用，請選擇一個。';
});
bindAction($('#closeModel'),()=>{$('#modelPicker').hidden=true;});
bindAction($('#saveModel'),async()=>{
  if(ACTIVE_STATUSES.includes(state?.job?.status)||state?.starting)throw new Error('請先停止目前的翻譯，再更換模型。');
  if(!$('#model').value)throw new Error('請選擇模型。');
  const s=await send(MSG.SETTINGS);delete s.hasConnection;
  await send(MSG.SAVE,{settings:{...s,model:$('#model').value,reasoningEffort:$('#reasoningEffort').value}});
  $('#modelPicker').hidden=true;await slowRefresh(true);await refresh();notice(`已改用 ${modelLabel($('#model').value,models)}。`);
});
async function slowRefresh(force=false) {
  if(slowLoading&&!force)return;slowLoading=true;lastSlowRefresh=Date.now();
  try{[account,usage]=await Promise.all([send(MSG.AUTH_STATUS),send(MSG.USAGE_SUMMARY)]);await loadModels();renderConnection();renderUsage();render();}
  catch(e){showError(e.message);}finally{slowLoading=false;}
}
bindAction($('#connectionAction'),connectionAction);
bindAction($('#options'),()=>send(MSG.OPTIONS));
chrome.runtime.onMessage.addListener(m=>{if(m.target==='ui'&&m.type===MSG.UPDATE){refresh();slowRefresh();}});
(async()=>{
  try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(videoIdFromUrl(tab?.url)||platformFromUrl(tab?.url)==='primevideo'){tabId=tab.id;await refresh();}
    await slowRefresh(true);
  }catch(e){showError(e.message);}
})();
const timer=setInterval(()=>{refresh();if(Date.now()-lastSlowRefresh>=4000)slowRefresh();},1000);window.addEventListener('pagehide',()=>clearInterval(timer));
