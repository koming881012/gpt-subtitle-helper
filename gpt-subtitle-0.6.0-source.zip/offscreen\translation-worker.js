import { translateJob } from '../translation/translator.js';
import { requestJSON,setUsageReporter } from '../translation/openai-client.js';
setUsageReporter(usage=>self.postMessage({type:'usage',usage}));
let controller,activeJob;
// Worker 沒有 chrome API；ChatGPT 憑證每次向背景頁索取，更新與輪替只在背景頁進行。
const waiting=new Map();
function access(force=false) {
  return new Promise((resolve,reject)=>{const id=crypto.randomUUID();waiting.set(id,{resolve,reject});self.postMessage({type:'access',id,force:Boolean(force)});});
}
self.onmessage=async({data})=>{
  if(data.type==='access-result'){const w=waiting.get(data.id);if(!w)return;waiting.delete(data.id);data.ok?w.resolve({token:data.token,accountId:data.accountId}):w.reject(Object.assign(new Error(data.error||'ChatGPT 登入已失效，請重新登入。'),{name:'AuthError',status:401,code:data.code||''}));return;}
  if(data.type==='test') {
    try {const result=await requestJSON({access,settings:data.settings,instructions:'Reply with ok true.',input:'Connection test.',schema:{type:'object',properties:{ok:{type:'boolean'}},required:['ok'],additionalProperties:false},name:'connection_test',signal:AbortSignal.timeout(60000),config:{maxRetries:0,timeoutMs:60000}});if(result.ok!==true)throw new Error('ChatGPT 回應不符合測試格式。');self.postMessage({type:'test-done',ok:true});}
    catch(e){self.postMessage({type:'test-done',ok:false,error:String(e.message).slice(0,700)});}return;
  }
  if(data.type==='abort'){controller?.abort();return;}
  if(data.type==='priority'){if(activeJob&&Number.isFinite(data.playheadMs))activeJob.playheadMs=data.playheadMs;return;}
  if(data.type!=='run' || controller)return;
  controller=new AbortController();activeJob=data.job;
  try {await translateJob(data.job,access,controller.signal,p=>self.postMessage({type:'checkpoint',...p}));}
  finally {self.postMessage({type:'done',jobId:data.job.jobId});}
};
