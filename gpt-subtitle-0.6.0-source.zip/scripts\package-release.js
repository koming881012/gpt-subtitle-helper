import {cp,mkdir,readFile,rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildContent} from './build-content.js';
const root=fileURLToPath(new URL('../',import.meta.url));
await buildContent({check:true});
const {version}=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));
const out=path.join(root,'release',version),extension=path.join(out,'extension');
await rm(extension,{recursive:true,force:true});await mkdir(extension,{recursive:true});
// Explicit allowlists keep local credentials, caches, reports and development dependencies out.
for(const name of ['manifest.json','auth','background','content','export','icons','offscreen','options','popup','shared','translation','LICENSE','PRIVACY.md'])await cp(path.join(root,name),path.join(extension,name),{recursive:true});
// Chrome 商店上傳用 ZIP：manifest.json 必須位於壓縮檔根目錄。
const destination=path.join(out,`GPT字幕助手-${version}-Chrome.zip`);
const ps="$ErrorActionPreference='Stop'; [Console]::InputEncoding=[Text.UTF8Encoding]::new($false); Add-Type -AssemblyName System.IO.Compression; Add-Type -AssemblyName System.IO.Compression.FileSystem; $item=[Console]::In.ReadToEnd()|ConvertFrom-Json; if([IO.File]::Exists($item.destination)){[IO.File]::Delete($item.destination)}; $archive=[IO.Compression.ZipFile]::Open($item.destination,[IO.Compression.ZipArchiveMode]::Create); try { foreach($file in Get-ChildItem -LiteralPath $item.source -Recurse -File){ $entry=$file.FullName.Substring($item.source.Length+1).Replace('\\','/'); [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null } } finally {$archive.Dispose()}";
const zip=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',ps],{input:JSON.stringify({source:extension,destination}),encoding:'utf8',windowsHide:true});
if(zip.status!==0)throw new Error(zip.stderr||'ZIP 壓縮失敗。');
console.log(`已產生 ${version} Chrome 擴充功能：${extension}\n商店上傳檔：${destination}`);
